const crypto = require('crypto');
const pass = 'admin1234';
const hash = crypto.createHash('sha256').update(pass).digest('hex');
console.log(hash);
