/**
 * Google Apps Script for Archery Scoring System (TNSU Chonburi)
 * Compatible with RBAC and Expanded Profile
 */

const SPREADSHEET_ID = "19n1c1H9sg1XTekSpsRQ_EHg_6PyV86lNlb4GT5BGQzY";

function doGet(e) {
  const action = e.parameter.action;
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);

  // Logging for GET write actions
  if (["deleteUser", "deleteScore", "deleteSchedule"].includes(action)) {
    try {
      const logSheet = getOrCreateSheet(ss, "Logs");
      const logHeaders = logSheet.getDataRange().getValues()[0];
      const logID = "L" + Utilities.getUuid().split('-')[0].toUpperCase();
      const logEntry = {
        logID,
        userID: e.parameter.currentUserID || "SYSTEM",
        username: e.parameter.currentUsername || "System",
        action: action,
        details: JSON.stringify(e.parameter),
        timestamp: new Date().toISOString()
      };
      appendObjectToSheet(logSheet, logHeaders, logEntry);
    } catch(err) {
      console.error("GET Logging error", err);
    }
  }
  
  if (action === "login") {
    const { username, password } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Users");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    
    const ADMIN_HASH = "9b6a15e96f1362e49c95d909b0b4a7dca52d3a6d250d4f6ff63d64c2ec33f81e"; // admin1234
    
    const cleanUsername = (username || "").toString().trim().toLowerCase();
    const cleanPassword = (password || "").toString().trim();

    // Emergency/Initial Admin Check
    if (cleanUsername === "admin" && cleanPassword === ADMIN_HASH) {
       return respond({ 
         success: true, 
         user: { 
           userID: "U-ADMIN-001", 
           username: "admin", 
           firstName: "System", 
           lastName: "Admin", 
           role: "admin",
           title: "นาย"
         } 
       });
    }

    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      const user = rowToObject(headers, row);
      if (user.username === username && user.password === password) {
        delete user.password;
        return respond({ success: true, user });
      }
    }
    return respond({ success: false, message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
  }

  if (action === "getScores") {
    const { userID, role } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Scores");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const scores = [];
    
    for (let i = 1; i < data.length; i++) {
        const row = data[i];
        const score = rowToObject(headers, row);
        // RBAC: Athletes see only own, Coach/Admin see all
        if (role === 'athlete') {
            if (score.UserID === userID) scores.push(score);
        } else {
            scores.push(score);
        }
    }
    return respond({ success: true, scores: scores.reverse() });
  }

  if (action === "getUsers") {
    const sheet = getOrCreateSheet(ss, "Users");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const users = [];
    for (let i = 1; i < data.length; i++) {
        const user = rowToObject(headers, data[i]);
        delete user.password;
        users.push(user);
    }
    return respond({ success: true, users });
  }

  if (action === "deleteScore") {
    const { scoreID } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Scores");
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
        if (data[i][0] === scoreID) {
            sheet.deleteRow(i + 1);
            return respond({ success: true });
        }
    }
    return respond({ success: false });
  }

  if (action === "deleteUser") {
    const { userID } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Users");
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
        if (data[i][0] === userID) {
            sheet.deleteRow(i + 1);
            return respond({ success: true });
        }
    }
    return respond({ success: false });
  }

  if (action === "getSchedules") {
    const sheet = getOrCreateSheet(ss, "Schedules");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const schedules = [];
    for (let i = 1; i < data.length; i++) {
        schedules.push(rowToObject(headers, data[i]));
    }
    return respond({ success: true, schedules: schedules.reverse() });
  }

  if (action === "deleteSchedule") {
    const { scheduleID } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Schedules");
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
        if (data[i][0] === scheduleID) {
            sheet.deleteRow(i + 1);
            return respond({ success: true });
        }
    }
    return respond({ success: false });
  }

  if (action === "forgotPassword") {
    const { email } = e.parameter;
    const sheet = getOrCreateSheet(ss, "Users");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const emailIndex = headers.indexOf("email");
    
    for (let i = 1; i < data.length; i++) {
        if (data[i][emailIndex] === email) {
            const user = rowToObject(headers, data[i]);
            const tempCode = Math.floor(100000 + Math.random() * 900000).toString();
            
            // In a real production app, we would store this code and verify it.
            // For this applet, since we can't easily manage temporary state without a new sheet,
            // we will send the code via email and return success.
            try {
              MailApp.sendEmail({
                to: email,
                subject: "Archery Scoring System - รหัสสำหรับตั้งรหัสผ่านใหม่",
                htmlBody: `
                  <div style="font-family: sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
                    <h2 style="color: #2563eb;">รหัสรีเซ็ตรหัสผ่าน</h2>
                    <p>สวัสดีคุณ ${user.firstName},</p>
                    <p>คุณได้ส่งคำขอรีเซ็ตรหัสผ่านสำหรับระบบ Archery Scoring System (TNSU Chonburi)</p>
                    <div style="background: #f0f7ff; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; color: #1e40af; border-radius: 8px; margin: 20px 0;">
                      ${tempCode}
                    </div>
                    <p>รหัสนี้ใช้สำหรับยืนยันตัวตนในระบบเพื่อตั้งรหัสผ่านใหม่</p>
                    <p style="font-size: 12px; color: #94a3b8; margin-top: 30px;">หากคุณไม่ได้ส่งคำขอนี้ โปรดเริ่มระบุการรักษาความปลอดภัยของบัญชีของคุณ</p>
                  </div>
                `
              });
              return respond({ success: true, code: tempCode, userID: user.userID });
            } catch (err) {
              return respond({ success: false, message: "ไม่สามารถส่งอีเมลได้ในขณะนี้" });
            }
        }
    }
    return respond({ success: false, message: "ไม่พบอีเมลนี้ในระบบ" });
  }

  if (action === "getLogs") {
    const sheet = getOrCreateSheet(ss, "Logs");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const logs = [];
    for (let i = 1; i < data.length; i++) {
        logs.push(rowToObject(headers, data[i]));
    }
    return respond({ success: true, logs: logs.reverse().slice(0, 100) });
  }

  return respond({ success: false, message: "Invalid action" });
}

function doPost(e) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const body = JSON.parse(e.postData.contents);
  const action = body.action;

  // Middleware to log all write actions
  if (["register", "updateProfile", "saveScore", "saveSchedule", "deleteUser", "deleteScore", "deleteSchedule"].includes(action)) {
    try {
      const logSheet = getOrCreateSheet(ss, "Logs");
      const logHeaders = logSheet.getDataRange().getValues()[0];
      const logID = "L" + Utilities.getUuid().split('-')[0].toUpperCase();
      const logEntry = {
        logID,
        userID: body.userID || body.currentUserID || "SYSTEM",
        username: body.username || body.currentUsername || "System",
        action: action,
        details: JSON.stringify(body),
        timestamp: new Date().toISOString()
      };
      appendObjectToSheet(logSheet, logHeaders, logEntry);
    } catch(err) {
      console.error("Logging error", err);
    }
  }

  if (action === "register") {
    const sheet = getOrCreateSheet(ss, "Users");
    const headers = sheet.getDataRange().getValues()[0];
    const userID = "U" + Utilities.getUuid().split('-')[0].toUpperCase();
    const newUser = {
        userID,
        ...body,
        createdAt: new Date().toISOString()
    };
    delete newUser.action;
    
    // Check duplicate username
    const currentData = sheet.getDataRange().getValues();
    for(let i=1; i<currentData.length; i++) {
        if(currentData[i][headers.indexOf("username")] === body.username) {
            return respond({ success: false, message: "ชื่อผู้ใช้นี้มีอยู่ในระบบแล้ว" });
        }
    }

    appendObjectToSheet(sheet, headers, newUser);
    return respond({ success: true, userID });
  }

  if (action === "saveSchedule") {
    const sheet = getOrCreateSheet(ss, "Schedules");
    const headers = sheet.getDataRange().getValues()[0];
    const { scheduleID } = body;
    
    if (scheduleID) {
        // Update existing
        const data = sheet.getDataRange().getValues();
        for (let i = 1; i < data.length; i++) {
            if (data[i][0] === scheduleID) {
                const rowIndex = i + 1;
                Object.keys(body).forEach(key => {
                    if (key === "action") return;
                    const colIndex = headers.indexOf(key);
                    if (colIndex > -1) {
                        sheet.getRange(rowIndex, colIndex + 1).setValue(body[key]);
                    }
                });
                return respond({ success: true });
            }
        }
    } else {
        // Create new
        const newID = "SCH" + Utilities.getUuid().split('-')[0].toUpperCase();
        const newSchedule = {
            scheduleID: newID,
            ...body,
            createdAt: new Date().toISOString()
        };
        delete newSchedule.action;
        appendObjectToSheet(sheet, headers, newSchedule);
        return respond({ success: true, scheduleID: newID });
    }
    return respond({ success: false });
  }

  if (action === "saveScore") {
    const sheet = getOrCreateSheet(ss, "Scores");
    const headers = sheet.getDataRange().getValues()[0];
    const { scoreID } = body;
    
    if (scoreID) {
        // Update existing score
        const data = sheet.getDataRange().getValues();
        for (let i = 1; i < data.length; i++) {
            if (data[i][0] === scoreID) {
                const rowIndex = i + 1;
                Object.keys(body).forEach(key => {
                    if (key === "action") return;
                    const colIndex = headers.indexOf(key);
                    if (colIndex > -1) {
                        let val = body[key];
                        if (key === "arrows" || key === "endTotals") {
                            val = JSON.stringify(val);
                        }
                        sheet.getRange(rowIndex, colIndex + 1).setValue(val);
                    }
                });
                return respond({ success: true });
            }
        }
        return respond({ success: false, message: "Score ID not found" });
    } else {
        // Create new score
        const newID = "S" + Utilities.getUuid().split('-')[0].toUpperCase();
        const newScore = {
            ScoreID: newID,
            ...body,
            Arrows: JSON.stringify(body.arrows),
            EndTotals: JSON.stringify(body.endTotals),
            CreatedAt: new Date().toISOString()
        };
        delete newScore.action;
        appendObjectToSheet(sheet, headers, newScore);
        return respond({ success: true, scoreID: newID });
    }
  }

  if (action === "updateProfile") {
    const sheet = getOrCreateSheet(ss, "Users");
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const { userID } = body;
    
    for (let i = 1; i < data.length; i++) {
        if (data[i][0] === userID) {
            const rowIndex = i + 1;
            Object.keys(body).forEach(key => {
                if (key === "action") return;
                const colIndex = headers.indexOf(key);
                if (colIndex > -1) {
                    sheet.getRange(rowIndex, colIndex + 1).setValue(body[key]);
                }
            });
            return respond({ success: true });
        }
    }
    return respond({ success: false });
  }

  if (action === "saveImage") {
      const { imageData, fileName, folderId } = body;
      const folder = folderId ? DriveApp.getFolderById(folderId) : getOrCreateFolder("Archery_Uploads");
      const bytes = Utilities.base64Decode(imageData.split(",")[1]);
      const contentBuffer = Utilities.newBlob(bytes, "image/jpeg", fileName);
      const file = folder.createFile(contentBuffer);
      file.setSharing(SpreadsheetApp.Sharing.ALLOW_ANYONE, SpreadsheetApp.Access.VIEW);
      return respond({ success: true, url: file.getDownloadUrl() });
  }

  if (action === "savePdf") {
      const { pdfData, fileName, folderId } = body;
      const folder = folderId ? DriveApp.getFolderById(folderId) : getOrCreateFolder("Archery_PDFs");
      const bytes = Utilities.base64Decode(pdfData.split(",")[1] || pdfData);
      const contentBuffer = Utilities.newBlob(bytes, "application/pdf", fileName);
      const file = folder.createFile(contentBuffer);
      file.setSharing(SpreadsheetApp.Sharing.ALLOW_ANYONE, SpreadsheetApp.Access.VIEW);
      return respond({ success: true, url: file.getDownloadUrl() });
  }

  return respond({ success: false });
}

// Helpers
function getOrCreateSheet(ss, name) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    const headers = name === "Users" 
      ? ["userID", "role", "title", "firstName", "lastName", "dateOfBirth", "age", "phone", "email", "lineID", "username", "password", "PasswordHash", "profileImageURL", "createdAt"]
      : name === "Scores"
      ? ["ScoreID", "UserID", "Username", "FullName", "BowType", "Distance", "FaceType", "DateTime", "TotalScore", "Count9", "Count10", "CountX", "Count10X", "Arrows", "EndTotals", "ScoreImageURL", "ScorePDFURL", "CreatedAt"]
      : name === "Schedules"
      ? ["ScheduleID", "Drill", "Date", "CoachID", "AthleteID", "Completed", "CreatedAt"]
      : ["logID", "userID", "username", "action", "details", "timestamp"];
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold").setBackground("#f3f3f3");
  }

  // Ensure default admin exists in Users sheet
  if (name === "Users") {
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    const usernameIdx = headers.indexOf("username");
    
    let adminExists = false;
    for (let i = 1; i < data.length; i++) {
      if (data[i][usernameIdx] === "admin") {
        adminExists = true;
        break;
      }
    }
    
    if (!adminExists) {
      const adminRow = headers.map(h => {
        if (h === "userID") return "U-ADMIN-001";
        if (h === "role") return "admin";
        if (h === "title") return "นาย";
        if (h === "firstName") return "System";
        if (h === "lastName") return "Administrator";
        if (h === "username") return "admin";
        if (h === "password") return "9b6a15e96f1362e49c95d909b0b4a7dca52d3a6d250d4f6ff63d64c2ec33f81e"; // admin1234
        if (h === "PasswordHash") return "admin1234";
        if (h === "createdAt") return new Date().toISOString();
        return "";
      });
      sheet.appendRow(adminRow);
    }
  }
  return sheet;
}

function getOrCreateFolder(name) {
    const folders = DriveApp.getFoldersByName(name);
    return folders.hasNext() ? folders.next() : DriveApp.createFolder(name);
}

function respond(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function rowToObject(headers, row) {
  const obj = {};
  headers.forEach((h, i) => {
      let val = row[i];
      try {
          if (typeof val === "string") {
            const trimmed = val.trim();
            if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
              val = JSON.parse(trimmed);
            }
          }
      } catch(e) {}
      obj[h] = val;
  });
  return obj;
}

function appendObjectToSheet(sheet, headers, obj) {
  const row = headers.map(h => {
    // Try exact match first
    if (obj[h] !== undefined) return obj[h];
    // Try lower case match
    const lowerH = h.toLowerCase();
    const foundKey = Object.keys(obj).find(k => k.toLowerCase() === lowerH);
    return foundKey ? obj[foundKey] : "";
  });
  sheet.appendRow(row);
}
