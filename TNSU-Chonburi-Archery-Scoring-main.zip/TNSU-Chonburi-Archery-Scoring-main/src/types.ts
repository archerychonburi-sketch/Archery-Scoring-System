export type Role = "admin" | "coach" | "athlete";

export interface User {
  userID: string;
  role: Role;
  title: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  age?: number;
  phone?: string;
  email?: string;
  lineID?: string;
  username: string;
  profileImageURL?: string;
  createdAt?: string;
}

export interface Score {
  ScoreID: string;
  UserID: string;
  Username: string;
  FullName: string;
  BowType: string;
  Distance: string;
  FaceType: string;
  DateTime: string;
  TotalScore: number;
  Count9: number;
  Count10: number;
  CountX: number;
  Count10X: number;
  Arrows: string[];
  EndTotals: number[];
  ScoreImageURL?: string;
  ScorePDFURL?: string;
  Notes?: string;
}

export interface PracticePlan {
  scheduleID: string;
  drill: string;
  date: string;
  coachID?: string;
  athleteID?: string;
  completed: boolean;
  createdAt: string;
}

export interface ActivityLog {
  logID: string;
  userID: string;
  username: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface GASResponse<T> {
  success: boolean;
  message?: string;
  user?: User;
  users?: User[];
  scores?: Score[];
  schedules?: PracticePlan[];
  logs?: ActivityLog[];
  scoreID?: string;
  scheduleID?: string;
  url?: string;
}
