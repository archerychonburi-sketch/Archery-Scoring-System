import { GoogleGenAI, Type } from "@google/genai";
import { Score } from "../types";

export interface AIPerformanceInsights {
  summary: string;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  trendAnalysis: string;
  metrics: {
    stamina: number;
    precision: number;
    consistency: number;
  };
  suggestedDrills: string[];
}

export async function analyzeScoreHistory(scores: Score[]): Promise<AIPerformanceInsights | null> {
  if (!scores || scores.length === 0) return null;

  // In AI Studio, process.env.GEMINI_API_KEY is available in the environment
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.error("GEMINI_API_KEY is not defined");
    return null;
  }

  const ai = new GoogleGenAI({ apiKey });

  // Prepare score data for the prompt
  const dataForAI = scores.map(s => ({
    date: s.DateTime,
    total: s.TotalScore,
    bow: s.BowType,
    distance: s.Distance,
    counts: { 9: s.Count9, 10: s.Count10, X: s.CountX },
    endTotals: s.EndTotals,
    notes: s.Notes
  })).slice(0, 30); // Limit to last 30 for better context

  const prompt = `Analyze the following archery score history and provide performance insights and recommendations in Thai.
  
  Score History:
  ${JSON.stringify(dataForAI, null, 2)}
  
  Please provide a very detailed analysis including performance metrics (0-100 scale) for Stamina, Precision, and Consistency based on the scores and set patterns.
  Also suggest specific training drills.
  
  Please return the analysis in JSON format with these fields:
  - summary: A brief summary of overall performance.
  - strengths: A list of key strengths identified.
  - weaknesses: A list of areas for improvement (e.g. mental focus, physical stability).
  - recommendations: Concrete actionable recommendations.
  - trendAnalysis: Detailed analysis of scores over time and patterns (e.g. fatigue in later ends).
  - metrics: { stamina: number, precision: number, consistency: number }
  - suggestedDrills: A list of specific archery drills based on the weaknesses.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            trendAnalysis: { type: Type.STRING },
            metrics: {
              type: Type.OBJECT,
              properties: {
                stamina: { type: Type.NUMBER },
                precision: { type: Type.NUMBER },
                consistency: { type: Type.NUMBER },
              },
              required: ["stamina", "precision", "consistency"]
            },
            suggestedDrills: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["summary", "strengths", "weaknesses", "recommendations", "trendAnalysis", "metrics", "suggestedDrills"]
        }
      }
    });

    if (!response.text) {
      throw new Error("No response from Gemini");
    }

    return JSON.parse(response.text) as AIPerformanceInsights;
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return null;
  }
}
