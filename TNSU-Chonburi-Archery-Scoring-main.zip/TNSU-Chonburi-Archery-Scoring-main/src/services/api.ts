import { User, Score, Role } from "../types";

const API_URL = "https://script.google.com/macros/s/AKfycbwmHGvt8tVuzxErl_nb7xRA-7hRs3EdUsOkiXZpwnljj2TL1UsPNI8xWsxdFjUtHHeEgA/exec";

export const CONFIG = {
  SHEET_ID: "19n1c1H9sg1XTekSpsRQ_EHg_6PyV86lNlb4GT5BGQzY",
  PROFILE_FOLDER_ID: "1Oa3cA2SzfDbKzTde8Zxr_lFX4DBZueND",
  SCORE_IMAGE_FOLDER_ID: "1Z10zhqRkAv3fn1ccR-t2XTrANsMiJLWf",
  SCORE_PDF_FOLDER_ID: "1NuQhT-juHjMSshFPWqe7hjqhoLVjX3Tl"
};

export const getApiUrl = () => API_URL;

async function request(action: string, method: "GET" | "POST", data?: any) {
  const url = new URL(API_URL);
  
  const options: RequestInit = {
    method,
    headers: {
      "Content-Type": "text/plain;charset=utf-8",
    },
    redirect: "follow"
  };

  const payload = { 
    action, 
    ...data,
    sheetId: CONFIG.SHEET_ID // Always send the target sheet ID
  };

  if (method === "GET") {
    url.searchParams.append("action", action);
    url.searchParams.append("sheetId", CONFIG.SHEET_ID);
    if (data) {
      Object.keys(data).forEach(key => url.searchParams.append(key, data[key]));
    }
  } else {
    options.body = JSON.stringify(payload);
  }

  try {
    const response = await fetch(url.toString(), options);
    
    // For GAS, sometimes no-cors is used, but here we want the JSON result.
    // If we're hitting CORS issues, fetch might throw.
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result = await response.json();
    return result;
  } catch (err: any) {
    console.error("API Request Error:", err);
    throw err;
  }
}

export async function login(username: string, password: string) {
  return request("login", "GET", { username, password });
}

export async function register(data: any) {
  return request("register", "POST", data);
}

export async function getScores(userID: string, role: Role) {
  return request("getScores", "GET", { userID, role });
}

export async function saveScore(data: any) {
  return request("saveScore", "POST", data);
}

export async function getUsers() {
  return request("getUsers", "GET");
}

export async function getLogs() {
  return request("getLogs", "GET");
}

export async function updateProfile(data: any) {
  return request("updateProfile", "POST", data);
}

export async function saveImage(imageData: string, fileName: string, scoreID?: string, folderId?: string) {
  return request("saveImage", "POST", { imageData, fileName, scoreID, folderId });
}

export async function savePdf(pdfData: string, fileName: string, scoreID?: string) {
  return request("savePdf", "POST", { pdfData, fileName, scoreID, folderId: CONFIG.SCORE_PDF_FOLDER_ID });
}

export async function deleteScore(scoreID: string) {
  return request("deleteScore", "GET", { scoreID });
}

export async function deleteUser(userID: string) {
  return request("deleteUser", "GET", { userID });
}

export async function forgotPassword(email: string) {
  return request("forgotPassword", "GET", { email });
}

export async function getSchedules() {
  return request("getSchedules", "GET");
}

export async function saveSchedule(data: any) {
  return request("saveSchedule", "POST", data);
}

export async function deleteSchedule(scheduleID: string) {
  return request("deleteSchedule", "GET", { scheduleID });
}
