import React, { useState, useEffect } from "react";
import { User } from "../types";
import { login, register, saveImage, forgotPassword, updateProfile, CONFIG } from "../services/api";
import { hashPassword } from "../lib/security";
import { LogIn, UserPlus, Eye, EyeOff, Loader2, Camera, Link2, Mail, Phone, Calendar, ArrowLeft, Key, ShieldCheck, Upload } from "lucide-react";
import { cn } from "../lib/utils";

interface AuthProps {
  onLoginSuccess: (user: User) => void;
}

type AuthMode = "login" | "register" | "forgot";

export default function Auth({ onLoginSuccess }: AuthProps) {
  const [mode, setMode] = useState<AuthMode>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isStaffMode, setIsStaffMode] = useState(false);
  const [error, setError] = useState("");

  // Forgot Password state
  const [resetEmail, setResetEmail] = useState("");
  const [resetStep, setResetStep] = useState<"request" | "verify">("request");
  const [sentCode, setSentCode] = useState("");
  const [inputCode, setInputCode] = useState("");
  const [resetUserId, setResetUserId] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // Register state
  const [regData, setRegData] = useState({
    title: "นาย",
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    age: 0,
    phone: "",
    email: "",
    lineID: "",
    username: "",
    password: "",
    confirmPassword: "",
    profileImageURL: ""
  });

  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Auto calculate age
  useEffect(() => {
    if (regData.dateOfBirth) {
      const birthDate = new Date(regData.dateOfBirth);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      setRegData(prev => ({ ...prev, age: Math.max(0, age) }));
    }
  }, [regData.dateOfBirth]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    setIsLoading(true);
    setError("");
    try {
      const hashedPassword = await hashPassword(password);
      const res = await login(username, hashedPassword);
      if (res.success) {
        onLoginSuccess(res.user);
      } else {
        setError(res.message || "Invalid credentials");
      }
    } catch (err: any) {
      setError(`Connection error: ${err.message || 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (regData.password.length < 6) {
        setError("Password must be at least 6 characters");
        return;
    }
    if (regData.password !== regData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (regData.email && !emailRegex.test(regData.email)) {
        setError("Invalid email format");
        return;
    }

    setIsLoading(true);
    setError("กำลังดำเนินการ...");
    try {
      let finalImageUrl = "";
      if (previewImage) {
        setError("กำลังอัปโหลดรูปภาพโปรไฟล์...");
        const uploadRes = await saveImage(previewImage, `member_${Date.now()}.jpg`, "", CONFIG.PROFILE_FOLDER_ID);
        if (uploadRes.success) {
          finalImageUrl = uploadRes.url;
          setError("อัปโหลดรูปภาพสำเร็จ กำลังบันทึกข้อมูล...");
        }
      }

      const hashedPassword = await hashPassword(regData.password);
      const finalData = { 
        ...regData, 
        password: hashedPassword, 
        PasswordHash: regData.password,
        profileImageURL: finalImageUrl,
        role: 'athlete' // Only athletes can self-register
      };
      delete (finalData as any).confirmPassword;

      const res = await register(finalData);
      if (res.success) {
        setMode("login");
        setError("Registration successful! Please login.");
      } else {
        setError(res.message || "Registration failed");
      }
    } catch (err: any) {
      setError(`Connection error: ${err.message || 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPasswordRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) return;
    setIsLoading(true);
    setError("");
    try {
      const res = await forgotPassword(resetEmail);
      if (res.success) {
        setSentCode(res.code);
        setResetUserId(res.userID);
        setResetStep("verify");
        setError("We've sent a verification code to your email.");
      } else {
        setError(res.message || "Failed to initiate password reset");
      }
    } catch (err: any) {
      setError(`Error: ${err.message || "Could not reach server"}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputCode !== sentCode) {
      setError("รหัสยืนยันไม่ถูกต้อง");
      return;
    }
    if (newPassword.length < 6) {
      setError("รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร");
      return;
    }

    setIsLoading(true);
    try {
      const hashedPassword = await hashPassword(newPassword);
      const res = await updateProfile({
        userID: resetUserId,
        password: hashedPassword,
        PasswordHash: newPassword
      });
      if (res.success) {
        setError("รีเซ็ตรหัสผ่านสำเร็จแล้ว! กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่");
        setMode("login");
        setResetStep("request");
        setResetEmail("");
        setNewPassword("");
      } else {
        setError("ไม่สามารถอัปเดตรหัสผ่านได้ โปรดลองอีกครั้ง");
      }
    } catch (err) {
      setError("เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F0F7FF] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <img 
            src="https://img1.pic.in.th/images/-7a612e314a2c945e.png" 
            alt="Logo" 
            className="h-24 mx-auto mb-4 drop-shadow-xl"
            referrerPolicy="no-referrer"
          />
          <h1 className="kanit text-2xl font-bold text-blue-900 uppercase">TNSU Chonburi</h1>
          <p className="text-sm text-blue-600 font-medium">{isStaffMode ? "Central Management Portal" : "Archery Scoring System"}</p>
        </div>

        <div className={cn(
          "bg-white rounded-3xl shadow-2xl overflow-hidden border border-blue-100/50 backdrop-blur-sm transition-all duration-500",
          isStaffMode ? "ring-2 ring-slate-900 shadow-2xl shadow-slate-200" : ""
        )}>
          {mode !== 'forgot' && (
            <div className="flex border-b border-blue-50">
              <button
                onClick={() => { setMode("login"); setError(""); }}
                className={cn(
                  "flex-1 py-4 kanit font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2",
                  mode === "login" ? "bg-blue-600 text-white shadow-inner" : "bg-blue-50 text-blue-400 hover:bg-blue-100"
                )}
              >
                <LogIn size={14} /> เข้าสู่ระบบ
              </button>
              <button
                onClick={() => { setMode("register"); setError(""); }}
                className={cn(
                  "flex-1 py-4 kanit font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2",
                  mode === "register" ? "bg-blue-600 text-white shadow-inner" : "bg-blue-50 text-blue-400 hover:bg-blue-100"
                )}
              >
                <UserPlus size={14} /> สมัครสมาชิก
              </button>
            </div>
          )}

          <div className="p-8">
            {mode === 'forgot' && (
              <div className="flex items-center gap-3 mb-6 font-black uppercase text-xs tracking-widest text-blue-600">
                <button 
                  onClick={() => { setMode("login"); setError(""); setResetStep("request"); }}
                  className="p-2 hover:bg-blue-50 rounded-xl transition-all"
                >
                  <ArrowLeft size={16} />
                </button>
                <span>ลืมรหัสผ่าน</span>
              </div>
            )}

            {mode === 'login' && isStaffMode && (
              <div className="mb-6 animate-in slide-in-from-top-4 duration-500">
                <div className="bg-slate-900 rounded-2xl p-4 flex items-center gap-4 text-white shadow-lg overflow-hidden relative">
                   <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/5 rounded-full blur-2xl" />
                   <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center shrink-0">
                      <ShieldCheck size={24} className="text-blue-400" />
                   </div>
                   <div>
                      <h3 className="text-xs font-black uppercase tracking-widest leading-none mb-1">Staff Portal</h3>
                      <p className="text-[10px] text-slate-400 font-medium leading-tight">โปรดเข้าสู่ระบบด้วยบัญชีแอดมินหรือผู้ฝึกสอนที่ได้รับอนุญาต</p>
                   </div>
                </div>
              </div>
            )}

            {error && (
              <div className={cn(
                "mb-6 p-4 rounded-2xl text-xs font-black uppercase tracking-widest border text-center animate-in fade-in slide-in-from-top-2",
                error.includes("successful") || error.includes("sent") || error.includes("สำเร็จ") ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-rose-50 text-rose-600 border-rose-100 shadow-lg shadow-rose-100/20"
              )}>
                {error}
              </div>
            )}

            {mode === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-blue-900 uppercase tracking-widest ml-1">Username</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="กรอกชื่อผู้ใช้"
                    className="w-full px-4 py-3 bg-blue-50/50 border border-blue-100 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Password</label>
                    <button 
                      type="button"
                      onClick={() => { setMode("forgot"); setError(""); }}
                      className="text-[9px] font-black text-blue-500 uppercase tracking-tighter hover:text-blue-700"
                    >
                      ลืมรหัสผ่าน?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="กรอกรหัสผ่าน"
                      className="w-full px-4 py-3 bg-blue-50/50 border border-blue-100 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-300 hover:text-blue-600 transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className={cn(
                    "w-full font-black uppercase tracking-[0.2em] py-4 px-6 rounded-2xl shadow-xl transition-all active:scale-[0.98] flex items-center justify-center gap-3 mt-4",
                    isStaffMode ? "bg-slate-900 hover:bg-black text-white shadow-slate-900/20" : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20"
                  )}
                >
                  {isLoading ? <Loader2 className="animate-spin" size={18} /> : <LogIn size={18} />}
                  {isStaffMode ? "เข้าสู่ระบบแอดมิน" : "เข้าสู่ระบบ"}
                </button>

                <div className="relative py-4">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-blue-50"></div></div>
                  <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest px-2 bg-white text-blue-300">
                    {isStaffMode ? "Switch to Normal" : "Staff & Admin"}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setIsStaffMode(!isStaffMode);
                    setError("");
                  }}
                  className={cn(
                    "w-full border font-black uppercase tracking-[0.15em] py-3.5 rounded-2xl transition-all flex items-center justify-center gap-2 text-[11px]",
                    isStaffMode 
                      ? "bg-blue-50 border-blue-100 text-blue-600 hover:bg-blue-100" 
                      : "bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100"
                  )}
                >
                  {isStaffMode ? (
                    <>
                      <UserPlus size={16} /> กลับไปหน้าล็อกอินนักกีฬา
                    </>
                  ) : (
                    <>
                      <ShieldCheck size={16} className="text-slate-400" /> ฝ่ายผู้ฝึกสอนและแอดมิน
                    </>
                  )}
                </button>
              </form>
            ) : mode === 'register' ? (
              <form onSubmit={handleRegister} className="space-y-4 max-h-[60vh] overflow-y-auto px-1 custom-scrollbar">
                <div className="flex flex-col items-center mb-4">
                  <div className="relative group">
                    <div className="w-24 h-24 rounded-[2rem] overflow-hidden border-2 border-dashed border-blue-200 bg-blue-50/50 flex items-center justify-center text-blue-300 shadow-inner group-hover:border-blue-400 transition-colors">
                      {previewImage ? (
                        <img src={previewImage} className="w-full h-full object-cover" />
                      ) : (
                        <Camera size={32} />
                      )}
                    </div>
                    <label className="absolute inset-0 cursor-pointer flex items-center justify-center bg-blue-600/0 hover:bg-blue-600/10 text-transparent hover:text-blue-600 transition-all rounded-[2rem]">
                       <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                       <Upload className="hidden group-hover:block" size={24} />
                    </label>
                  </div>
                  <p className="text-[10px] text-blue-400 font-black uppercase tracking-widest mt-3">Upload Profile</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-blue-900 uppercase tracking-widest ml-1">คำนำหน้า</label>
                    <select
                      value={regData.title}
                      onChange={(e) => setRegData({ ...regData, title: e.target.value })}
                      className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 font-bold"
                    >
                      <option>นาย</option><option>นาง</option><option>นางสาว</option><option>เด็กชาย</option><option>เด็กหญิง</option>
                    </select>
                  </div>
                   <div className="space-y-1">
                    <label className="text-[10px] font-black text-blue-900 uppercase tracking-widest ml-1">วันเกิด</label>
                    <input
                      type="date"
                      required
                      value={regData.dateOfBirth}
                      onChange={(e) => setRegData({ ...regData, dateOfBirth: e.target.value })}
                      className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl text-sm font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    required
                    placeholder="ชื่อ (Name)"
                    className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl font-bold placeholder:text-blue-200"
                    value={regData.firstName}
                    onChange={(e) => setRegData({ ...regData, firstName: e.target.value })}
                  />
                  <input
                    type="text"
                    required
                    placeholder="นามสกุล (Last)"
                    className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl font-bold placeholder:text-blue-200"
                    value={regData.lastName}
                    onChange={(e) => setRegData({ ...regData, lastName: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="tel"
                    required
                    placeholder="เบอร์โทร"
                    className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl font-bold"
                    value={regData.phone}
                    onChange={(e) => setRegData({ ...regData, phone: e.target.value })}
                  />
                  <input
                    type="email"
                    required
                    placeholder="อีเมล"
                    className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl font-bold"
                    value={regData.email}
                    onChange={(e) => setRegData({ ...regData, email: e.target.value })}
                  />
                </div>

                <input
                    type="text"
                    placeholder="LINE ID (ถ้ามี)"
                    className="w-full px-3 py-2.5 bg-blue-50/50 border border-blue-100 rounded-xl font-bold"
                    value={regData.lineID}
                    onChange={(e) => setRegData({ ...regData, lineID: e.target.value })}
                />

                <div className="border-t border-blue-100/50 pt-4 mt-2">
                  <label className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] block mb-3">Security Setup</label>
                  <input
                    type="text"
                    required
                    placeholder="Username"
                    className="w-full px-3 py-2.5 bg-white border-2 border-blue-50 rounded-xl mb-3 font-bold"
                    value={regData.username}
                    onChange={(e) => setRegData({ ...regData, username: e.target.value })}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="password"
                      required
                      placeholder="รหัสผ่าน"
                      className="w-full px-3 py-2.5 bg-white border-2 border-blue-50 rounded-xl font-bold"
                      value={regData.password}
                      onChange={(e) => setRegData({ ...regData, password: e.target.value })}
                    />
                    <input
                      type="password"
                      required
                      placeholder="ยืนยันรหัส"
                      className="w-full px-3 py-2.5 bg-white border-2 border-blue-50 rounded-xl font-bold"
                      value={regData.confirmPassword}
                      onChange={(e) => setRegData({ ...regData, confirmPassword: e.target.value })}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-[0.2em] py-4 px-6 rounded-2xl transition-all shadow-lg shadow-blue-200 mt-4 h-14"
                >
                  {isLoading ? <Loader2 className="animate-spin mx-auto" size={24} /> : "ยืนยันการสมัคร"}
                </button>
              </form>
            ) : (
              <div className="animate-in fade-in zoom-in-95 duration-300">
                {resetStep === 'request' ? (
                  <form onSubmit={handleForgotPasswordRequest} className="space-y-6">
                    <div className="text-center p-6 bg-blue-50/50 rounded-3xl mb-4">
                       <Mail className="mx-auto text-blue-600 mb-3" size={32} />
                       <h3 className="kanit font-black text-slate-800">ส่งรหัสกู้คืน</h3>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight mt-1">เราจะส่งรหัส 6 หลักไปที่อีเมลของคุณ</p>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-blue-900 uppercase tracking-widest ml-1">อีเมลที่ลงทะเบียน</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-300" size={18} />
                        <input
                          type="email"
                          required
                          value={resetEmail}
                          onChange={(e) => setResetEmail(e.target.value)}
                          placeholder="example@mail.com"
                          className="w-full pl-12 pr-4 py-3.5 bg-blue-50/50 border border-blue-100 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all font-bold"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-[0.2em] py-4 px-6 rounded-2xl shadow-xl shadow-blue-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-3"
                    >
                      {isLoading ? <Loader2 className="animate-spin" size={18} /> : <Key size={18} />}
                      ส่งรหัสรีเซ็ต
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleResetPassword} className="space-y-5">
                    <div className="text-center p-6 bg-emerald-50/50 rounded-3xl mb-4 border border-emerald-100">
                       <ShieldCheck className="mx-auto text-emerald-600 mb-2" size={32} />
                       <h3 className="kanit font-black text-emerald-900">ระบุรหัสรีเซ็ต</h3>
                       <div className="mt-2 p-2 bg-white rounded-xl inline-block shadow-sm border border-emerald-100">
                          <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest">{resetEmail}</p>
                       </div>
                    </div>
                    
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-800 uppercase tracking-widest ml-1">รหัส 6 หลักจากอีเมล</label>
                       <input
                        type="text"
                        required
                        maxLength={6}
                        value={inputCode}
                        onChange={(e) => setInputCode(e.target.value)}
                        placeholder="000000"
                        className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-center text-3xl font-black tracking-[0.5em] focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all placeholder:opacity-20 placeholder:tracking-normal"
                      />
                    </div>

                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-800 uppercase tracking-widest ml-1">กำหนดรหัสผ่านใหม่</label>
                       <div className="relative">
                          <input
                            type={showPassword ? "text" : "password"}
                            required
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="อย่างน้อย 6 ตัวอักษร"
                            className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-black focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300"
                          >
                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                       </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-slate-900 hover:bg-black text-white font-black uppercase tracking-[0.2em] py-4 px-6 rounded-2xl shadow-xl shadow-slate-900/10 transition-all flex items-center justify-center gap-3"
                    >
                      {isLoading ? <Loader2 className="animate-spin" size={18} /> : null}
                      รีเซ็ตรหัสผ่านใหม่
                    </button>
                  </form>
                )}
              </div>
            )}
          </div>
        </div>

        <p className="mt-8 text-center text-[9px] text-blue-400 font-black uppercase tracking-[0.5em] opacity-40">
          &copy; TNSU CHONBURI ARCHERY CLUB
        </p>
      </div>
    </div>
  );
}
