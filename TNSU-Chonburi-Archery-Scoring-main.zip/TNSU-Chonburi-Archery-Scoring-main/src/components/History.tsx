import { useState, useEffect, useRef } from "react";
import { User, Score } from "../types";
import { getScores, deleteScore, getUsers } from "../services/api";
import { History as HistoryIcon, Search, Eye, Trash2, Loader2, Target, Calendar, ShieldAlert, ExternalLink, Camera, FileText, Download, Image as ImageIcon, X, RotateCcw, Pencil } from "lucide-react";
import { cn } from "../lib/utils";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

import AIInsights from "./AIInsights";
import ScoreRecord from "./ScoreRecord";

interface HistoryProps {
  user: User;
  initialFilterUser?: string;
}

export default function History({ user, initialFilterUser = "all" }: HistoryProps) {
  const [history, setHistory] = useState<Score[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filterBow, setFilterBow] = useState("all");
  const [filterDistance, setFilterDistance] = useState("all");
  const [filterUser, setFilterUser] = useState(initialFilterUser);
  const [selectedScore, setSelectedScore] = useState<Score | null >(null);
  const [editingScore, setEditingScore] = useState<Score | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);
  const [athletes, setAthletes] = useState<User[]>([]);

  useEffect(() => {
    fetchHistory();
    if (user.role !== 'athlete') {
      fetchAthletes();
    }
  }, [filterUser]);

  const fetchAthletes = async () => {
    try {
      const res = await getUsers();
      if (res.success) {
        setAthletes(res.users?.filter(u => u.role === 'athlete') || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchHistory = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const targetUid = user.role === 'athlete' ? user.userID : filterUser === 'all' ? "" : filterUser;
      const res = await getScores(targetUid || "", user.role);
      if (res.success) {
        setHistory(res.scores || []);
      } else {
        throw new Error(res.message || "ไม่สามารถโหลดข้อมูลได้");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "เกิดข้อผิดพลาดในการเชื่อมต่อ");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (scoreID: string) => {
    if (!confirm("Are you sure you want to delete this score?")) return;
    try {
      const res = await deleteScore(scoreID);
      if (res.success) {
        setHistory(prev => prev.filter(s => s.ScoreID !== scoreID));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleString("th-TH", { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateStr;
    }
  };

  const getScoreVal = (s: string) => (s === "M" ? 0 : s === "X" ? 10 : parseInt(s) || 0);

  const getEndStats = (endArrows: string[]) => {
    const vals = endArrows.map(a => getScoreVal(a));
    if (vals.length === 0) return { stdDev: 0, consistency: 0 };
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    const stdDev = Math.sqrt(vals.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / vals.length);
    const consistency = Math.max(0, 100 - (stdDev * 20)); 
    return { stdDev, consistency };
  };

  const handleExport = async (type: 'png' | 'pdf') => {
    if (!reportRef.current || !selectedScore) return;
    setIsExporting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 100));

      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        scrollX: 0,
        scrollY: 0,
        logging: false
      });
      
      const fileName = `ScoreReport-${selectedScore.FullName}-${new Date(selectedScore.DateTime).getTime()}`;
      
      if (type === 'png') {
        const link = document.createElement("a");
        link.download = `${fileName}.png`;
        link.href = canvas.toDataURL("image/png", 1.0);
        link.click();
      } else {
        const imgData = canvas.toDataURL("image/png", 1.0);
        const pdf = new jsPDF("p", "mm", "a4");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const imgWidth = pdfWidth - 20;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, "PNG", 10, 10, imgWidth, imgHeight);
        pdf.save(`${fileName}.pdf`);
      }
    } catch (err) {
      console.error("Export failed", err);
      alert("ไม่สามารถสร้างไฟล์ได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsExporting(false);
    }
  };

  const filteredHistory = history.filter(s => {
    const matchSearch = String(s.FullName || "").toLowerCase().includes(search.toLowerCase()) || 
                      String(s.DateTime || "").includes(search);
    const matchBow = filterBow === "all" || s.BowType === filterBow;
    const matchDist = filterDistance === "all" || s.Distance === filterDistance;
    return matchSearch && matchBow && matchDist;
  });

  return (
    <div className="space-y-6">
      {error && (
        <div className="bento-card border-rose-100 bg-rose-50 p-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-rose-700">
             <ShieldAlert size={24} />
             <div>
               <p className="font-black kanit uppercase tracking-widest text-sm">Connection Error</p>
               <p className="text-xs opacity-80">{error}</p>
             </div>
          </div>
          <button 
            onClick={fetchHistory}
            className="px-6 py-2 bg-rose-600 text-white rounded-xl font-bold text-sm transition-all hover:bg-rose-700 active:scale-95 flex items-center gap-2"
          >
            <RotateCcw size={16} /> Retry Connection
          </button>
        </div>
      )}
      <div className="flex flex-col gap-1 border-l-4 border-blue-600 pl-4 mb-4">
        <h2 className="kanit text-2xl font-black text-blue-900 leading-none flex items-center gap-2">
          <HistoryIcon className="text-blue-600" /> ประวัติข้อมูล และประวัติการบันทึกคะแนน
        </h2>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-8">Comprehensive Scoring and Activity Logs</p>
      </div>
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          {user.role !== 'athlete' && (
            <select 
              value={filterUser}
              onChange={(e) => setFilterUser(e.target.value)}
              className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
            >
              <option value="all">นักกีฬาทุกคน</option>
              {athletes.map(a => (
                <option key={a.userID} value={a.userID}>{a.firstName} {a.lastName}</option>
              ))}
            </select>
          )}
          <AIInsights scores={history} user={user} />
          <button 
            onClick={fetchHistory}
            disabled={isLoading}
            className="text-slate-400 hover:text-blue-600 p-3 bg-white shadow-sm border border-slate-100 rounded-2xl transition-all active:scale-95"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : <RotateCcw size={20} />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bento-card md:col-span-2 !p-5">
          <label className="bento-label">ค้นหาข้อมูล</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
            <input 
              type="text" 
              placeholder="ค้นหาชื่อหรือวันเวลา..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="bento-card !p-5">
          <label className="bento-label">คันธนู</label>
          <select 
            value={filterBow}
            onChange={(e) => setFilterBow(e.target.value)}
            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
          >
            <option value="all">ทั้งหมด</option>
            <option value="Recurve">Recurve</option>
            <option value="Compound">Compound</option>
          </select>
        </div>
        <div className="bento-card !p-5">
          <label className="bento-label">ระยะยิง</label>
          <select 
            value={filterDistance}
            onChange={(e) => setFilterDistance(e.target.value)}
            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
          >
            <option value="all">ทั้งหมด</option>
            <option value="18M">18 เมตร</option>
            <option value="30M">30 เมตร</option>
            <option value="50M">50 เมตร</option>
            <option value="70M">70 เมตร</option>
          </select>
        </div>
        <div className="bento-card !p-5 bg-slate-800 border-none shadow-lg shadow-slate-200 flex flex-col justify-center">
             <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-1">ผลการบันทึก</span>
             <span className="text-3xl font-black text-white">{filteredHistory.length} <span className="text-xs opacity-40">รายการ</span></span>
        </div>
      </div>

      <div className="bento-card !p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">
                <th className="py-5 px-8">วันเวลา / Date</th>
                {user.role !== 'athlete' && <th className="py-5 px-6">นักกีฬา / Athlete</th>}
                <th className="py-5 px-6 whitespace-nowrap">ประเภทธนู / ระยะ (Bow / Dist)</th>
                <th className="py-5 px-6 text-right font-black">คะแนน / Score</th>
                <th className="py-5 px-6 text-center">X / 10 / 9</th>
                <th className="py-5 px-8 text-center">จัดการ / Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-20 text-center text-slate-400 font-medium">
                    {isLoading ? "กำลังโหลดข้อมูล..." : "ไม่พบประวัติข้อมูล"}
                  </td>
                </tr>
              ) : (
                filteredHistory.map((s) => (
                  <tr 
                    key={s.ScoreID} 
                    className="hover:bg-blue-50/50 group transition-colors cursor-pointer"
                    onClick={() => setSelectedScore(s)}
                  >
                    <td className="py-4 px-6 border-b border-blue-50 font-mono text-xs text-slate-500">
                      <div className="flex items-center gap-2">
                        <Calendar size={14} className="text-blue-300" />
                        {formatDate(s.DateTime)}
                      </div>
                    </td>
                    {user.role !== 'athlete' && (
                      <td className="py-4 px-6 border-b border-blue-50">
                        <div className="flex items-center gap-3">
                          <img 
                            src={s.UserID ? `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${s.FullName}` : ""} // This is a placeholder logic, usually we'd need UserID to fetch ProfileImageURL, but let's see if Score object has it
                            alt="Avatar" 
                            className="w-8 h-8 rounded-full object-cover border border-slate-100 shadow-sm"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${s.FullName}`;
                            }}
                          />
                          <span className="font-semibold text-slate-700">{s.FullName}</span>
                        </div>
                      </td>
                    )}
                    <td className="py-4 px-6 border-b border-blue-50">
                      <div className="flex items-center gap-2">
                         <span className={cn(
                           "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase",
                           s.BowType === 'Recurve' ? "bg-blue-100 text-blue-700" : "bg-orange-100 text-orange-700"
                         )}>{s.BowType}</span>
                         <span className="text-slate-400 font-mono text-xs">{s.Distance}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 border-b border-blue-50 text-right">
                      <span className="kanit text-xl font-bold text-blue-900">{s.TotalScore}</span>
                    </td>
                    <td className="py-4 px-6 border-b border-blue-50 text-center">
                      <div className="inline-flex divide-x divide-slate-100 rounded-lg border border-slate-100 bg-slate-50 text-xs font-mono">
                        <span className="px-2 py-1 text-red-600 font-bold">{s.CountX}</span>
                        <span className="px-2 py-1 text-slate-700 font-bold">{s.Count10}</span>
                        <span className="px-2 py-1 text-slate-500">{s.Count9}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 border-b border-blue-50 text-center">
                      <div className="flex items-center justify-center gap-1" onClick={e => e.stopPropagation()}>
                        <button 
                          onClick={() => setSelectedScore(s)}
                          className="p-2 text-blue-400 hover:text-blue-600 hover:bg-blue-100 rounded-full transition-all"
                          title="ดูรายละเอียด"
                        >
                          <Eye size={18} />
                        </button>
                        {(user.role === 'admin' || user.role === 'coach' || user.userID === s.UserID) && (
                          <button 
                            onClick={() => setEditingScore(s)}
                            className="p-2 text-amber-400 hover:text-amber-600 hover:bg-amber-100 rounded-full transition-all"
                            title="แก้ไขข้อมูลย้อนหลัง"
                          >
                            <Pencil size={18} />
                          </button>
                        )}
                        {s.ScorePDFURL && (
                          <a 
                            href={s.ScorePDFURL} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-100 rounded-full transition-all"
                            title="ดาวน์โหลด PDF"
                          >
                            <FileText size={18} />
                          </a>
                        )}
                        {(user.role === 'admin' || user.role === 'coach' || user.userID === s.UserID) && (
                          <button 
                            onClick={() => handleDelete(s.ScoreID)}
                            className="p-2 text-red-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all"
                            title="ลบข้อมูล"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selectedScore && (
        <div className="fixed inset-0 bg-blue-950/40 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-y-auto" onClick={() => setSelectedScore(null)}>
          <div className="bg-white rounded-[2.5rem] shadow-2xl max-w-2xl w-full my-auto overflow-hidden animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()}>
            {/* Action Header */}
            <div className="bg-slate-50 px-8 py-4 border-b border-slate-100 flex items-center justify-between">
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Score Report Detail</span>
               </div>
               <div className="flex items-center gap-2">
                  <button 
                    disabled={isExporting}
                    onClick={() => handleExport('png')}
                    className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-200 rounded-xl transition-all active:scale-95 flex items-center gap-2 group disabled:opacity-50"
                  >
                    {isExporting ? <Loader2 size={16} className="animate-spin" /> : <ImageIcon size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-wider hidden sm:block">PNG</span>
                  </button>
                  <button 
                    disabled={isExporting}
                    onClick={() => handleExport('pdf')}
                    className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-red-600 hover:border-red-200 rounded-xl transition-all active:scale-95 flex items-center gap-2 group disabled:opacity-50"
                  >
                    {isExporting ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-wider hidden sm:block">PDF</span>
                  </button>
                  <button 
                    onClick={() => setSelectedScore(null)}
                    className="p-2.5 bg-slate-200 text-slate-600 hover:bg-slate-300 rounded-xl transition-all"
                  >
                    <X size={16} />
                  </button>
               </div>
            </div>

            <div className="p-8" ref={reportRef}>
               <div className="flex justify-between items-start mb-8">
                  <div className="flex items-center gap-4">
                     <div className="w-16 h-16 bg-blue-700 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-blue-200">
                        {selectedScore.FullName?.charAt(0) || "T"}
                     </div>
                     <div>
                        <h3 className="kanit text-2xl font-black text-slate-800 uppercase leading-none mb-2">ใบบันทึกคะแนน</h3>
                        <div className="flex items-center gap-2">
                           <Calendar size={12} className="text-blue-400" />
                           <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">{formatDate(selectedScore.DateTime)}</p>
                        </div>
                     </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Total Score</div>
                    <div className="kanit text-5xl font-black text-blue-600 leading-none">{selectedScore.TotalScore}</div>
                  </div>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  <DetailItem label="นักกีฬา" value={selectedScore.FullName} />
                  <DetailItem label="คันธนู" value={selectedScore.BowType} />
                  <DetailItem label="ระยะ" value={selectedScore.Distance} />
                  <DetailItem label="ตำแหน่ง" value={selectedScore.FaceType || "Target Face"} />
               </div>

               <div className="flex gap-2 mb-8 overflow-x-auto pb-4 no-scrollbar">
                  {[
                    { label: 'X', value: selectedScore.CountX, bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100' },
                    { label: '10', value: selectedScore.Count10, bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-100' },
                    { label: '9', value: selectedScore.Count9, bg: 'bg-slate-50', text: 'text-slate-700', border: 'border-slate-200' },
                    { label: '8-1', value: (() => {
                        const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                        const validArrows = Array.isArray(rawArrows) ? rawArrows : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                        return validArrows.filter((a: string) => !["X", "10", "9", "M"].includes(a)).length;
                    })(), bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-100' },
                    { label: 'M', value: (() => {
                        const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                        const validArrows = Array.isArray(rawArrows) ? rawArrows : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                        return validArrows.filter((a: string) => a === "M").length;
                    })(), bg: 'bg-slate-100', text: 'text-slate-500', border: 'border-slate-200' }
                  ].map((hit, i) => (
                    <div key={i} className={cn("min-w-[70px] flex-1 border rounded-2xl p-3 flex flex-col items-center", hit.bg, hit.border)}>
                        <span className="text-[9px] font-black uppercase tracking-widest mb-1 opacity-60">{hit.label}</span>
                        <span className={cn("kanit text-lg font-black", hit.text)}>{hit.value}</span>
                    </div>
                  ))}
               </div>

               {selectedScore.ScoreImageURL && (
                 <div className="mb-8 p-1 bg-white border border-slate-100 rounded-3xl shadow-sm overflow-hidden group relative">
                   <div className="absolute top-4 left-4 z-10 bg-slate-900/80 backdrop-blur-md text-white text-[9px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                     Attached Score Image / ภาพใบคะแนนที่แนบมา
                   </div>
                   <img 
                     src={selectedScore.ScoreImageURL} 
                     alt="Score Sheet" 
                     className="w-full h-auto max-h-[400px] object-contain rounded-[1.4rem] transition-transform duration-700 group-hover:scale-[1.02]"
                     referrerPolicy="no-referrer"
                   />
                 </div>
               )}

               <div className="bg-slate-900 text-white p-4 rounded-t-3xl flex justify-between items-center px-8 mt-8">
                  <span className="text-[11px] font-black uppercase tracking-[0.2em]">Detailed Score Sheet / ใบบันทึกคะแนนรายชุด</span>
                  <span className="text-[10px] font-bold opacity-40">Performance Breakdown</span>
               </div>
               <div className="border border-slate-200 rounded-b-3xl overflow-hidden mb-8">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-200">
                        <th className="py-4 px-6 text-center w-16">End / ชุดที่</th>
                        <th className="py-4 text-center">Arrow Scores / คะแนนแต่ละลูก</th>
                        <th className="py-4 px-6 text-center w-32 border-x border-slate-200">End Info / ข้อมูลชุด</th>
                        <th className="py-4 px-6 text-right w-24">Sum / รวมชุด</th>
                        <th className="py-4 px-6 text-right w-24 bg-blue-50/50">Total / คะแนนรวม</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">

                    {(() => {
                        const rawEndTotals = selectedScore.EndTotals ?? (selectedScore as any).endTotals;
                        const validEndTotals = Array.isArray(rawEndTotals) 
                          ? rawEndTotals 
                          : (typeof rawEndTotals === "string" ? JSON.parse(rawEndTotals) : []);

                        let runningTotal = 0;

                        return validEndTotals.map((total: number, endIdx: number) => {
                          const arrowsPerEnd = selectedScore.Distance === "18M" ? 3 : 6;
                          runningTotal += total;
                          
                          const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                          const validArrows = Array.isArray(rawArrows) 
                            ? rawArrows 
                            : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                          
                          const endArrows = validArrows.slice(endIdx * arrowsPerEnd, (endIdx + 1) * arrowsPerEnd) || [];
                          const { stdDev, consistency } = getEndStats(endArrows);
                          
                          return (
                            <tr key={endIdx} className="hover:bg-blue-50/30 transition-colors">
                              <td className="py-4 text-[10px] text-slate-300 font-black text-center">{endIdx + 1}</td>
                              <td className="py-4">
                                 <div className="flex justify-center gap-1.5 md:gap-2">
                                    {endArrows.map((arrow: string, arrowIdx: number) => (
                                      <div 
                                        key={arrowIdx} 
                                        className={cn(
                                          "w-8 h-8 rounded-lg flex items-center justify-center font-mono font-black text-[10px] border shadow-sm",
                                          arrow === "X" || arrow === "10" || arrow === "9" ? "bg-yellow-50 border-yellow-200 text-yellow-700" :
                                          arrow === "8" || arrow === "7" ? "bg-red-50 border-red-200 text-red-600" :
                                          arrow === "6" || arrow === "5" ? "bg-blue-50 border-blue-200 text-blue-600" :
                                          arrow === "M" ? "bg-slate-50 border-slate-200 text-slate-400" : "bg-white border-slate-100 text-slate-700"
                                        )}
                                      >
                                        {arrow}
                                      </div>
                                    ))}
                                 </div>
                              </td>
                              <td className="py-4 px-4 border-x border-slate-100">
                                 <div className="flex flex-col gap-1 items-center">
                                    <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                                        <div 
                                          className={cn("h-full", consistency > 80 ? "bg-emerald-500" : "bg-amber-500")}
                                          style={{ width: `${consistency}%` }}
                                        />
                                    </div>
                                    <span className="text-[7px] font-black text-slate-300 uppercase tracking-widest">{Math.round(consistency)}% Analysis</span>
                                 </div>
                              </td>
                              <td className="py-4 px-6 text-right font-mono font-black text-slate-400 text-[11px] font-mono">{total}</td>
                              <td className="py-4 px-6 text-right font-mono font-black text-blue-900 bg-blue-50/30 text-xs">{runningTotal}</td>
                            </tr>
                          );
                        });
                    })()}
                  </tbody>
                </table>
             </div>

               <div className="border-t border-slate-100 pt-6 mt-6 flex justify-between items-center opacity-40 grayscale">
                  <div className="flex items-center gap-2">
                     <div className="w-6 h-6 bg-blue-700 rounded-lg flex items-center justify-center text-white font-black text-[10px]">T</div>
                     <span className="text-[9px] font-black uppercase tracking-widest">TNSU Chonburi Archery</span>
                  </div>
                  <span className="text-[9px] font-bold">Official Scoring Record Report</span>
               </div>
            </div>

            <div className="p-8 bg-slate-50 border-t border-slate-100">
                <button 
                  onClick={() => setSelectedScore(null)}
                  className="w-full py-4 bg-slate-900 text-white font-black uppercase tracking-[0.2em] rounded-2xl transition-all hover:bg-black active:scale-95 shadow-xl shadow-slate-200"
                >
                  เรียบร้อย
                </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Score Modal */}
      {editingScore && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 lg:p-12 overflow-hidden print:hidden">
          <div 
             className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" 
             onClick={() => setEditingScore(null)} 
          />
          <div className="relative w-full max-w-5xl h-full max-h-[95vh] bg-white rounded-[40px] shadow-2xl overflow-hidden flex flex-col">
             <div className="flex items-center justify-between p-6 px-10 border-b border-slate-100 bg-white z-10 shrink-0">
                <div className="flex flex-col">
                  <h3 className="kanit text-xl font-bold text-slate-800 leading-none">แก้ไขข้อมูลคะแนนย้อนหลัง</h3>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Edit Historical Score Record</span>
                </div>
                <button 
                  onClick={() => setEditingScore(null)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X size={24} className="text-slate-400" />
                </button>
             </div>
             
             <div className="flex-1 overflow-y-auto bg-slate-50/30">
               <div className="p-4 lg:p-8">
                 <ScoreRecord 
                   user={user} 
                   initialScore={editingScore} 
                   onSuccess={() => {
                     setEditingScore(null);
                     fetchHistory();
                   }}
                   onCancel={() => setEditingScore(null)}
                 />
               </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailItem({ label, value }: { label: string, value: string }) {
  return (
    <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
      <div className="text-[9px] text-slate-400 font-bold uppercase mb-1">{label}</div>
      <div className="text-sm font-semibold text-slate-700">{value}</div>
    </div>
  );
}

