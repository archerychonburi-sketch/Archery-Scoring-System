import { useState, useEffect, useMemo, useRef } from "react";
import { User, Score } from "../types";
import { getScores, getUsers } from "../services/api";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { LayoutDashboard, TrendingUp, Target, BarChart3, Loader2, ArrowUpRight, ArrowDownRight, Minus, ShieldAlert, Download, Edit3, X, Check, RotateCcw, Sparkles, Eye, Calendar, FileText, Image as ImageIcon } from "lucide-react";
import { cn } from "../lib/utils";
import AIInsights from "./AIInsights";
import PracticeSchedule from "./PracticeSchedule";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

interface DashboardProps {
  user: User;
}

export default function Dashboard({ user }: DashboardProps) {
  const [history, setHistory] = useState<Score[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [goalScore, setGoalScore] = useState<number>(() => {
    const saved = localStorage.getItem("archeryGoal");
    return saved ? parseInt(saved) : 320;
  });
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempGoal, setTempGoal] = useState(goalScore.toString());

  // Export report state
  const [selectedScore, setSelectedScore] = useState<Score | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  // Filters
  const [filterBow, setFilterBow] = useState("all");
  const [filterDistance, setFilterDistance] = useState("all");
  const [filterUser, setFilterUser] = useState(user.role === 'athlete' ? user.userID : "all");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [scoresRes, usersRes] = await Promise.all([
        getScores(user.userID || "", user.role),
        (user.role !== 'athlete') ? getUsers() : Promise.resolve({ success: true, users: [] })
      ]);
      
      if (scoresRes.success) {
        setHistory(scoresRes.scores || []);
      } else {
        throw new Error(scoresRes.message || "Failed to fetch scores");
      }

      if (usersRes.success) {
          const uList = Array.isArray(usersRes.users) ? usersRes.users : [];
          setUsers(uList);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Connection error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  const filteredHistory = useMemo(() => {
    return history.filter(s => {
      if (filterBow !== "all" && s.BowType !== filterBow) return false;
      if (filterDistance !== "all" && s.Distance !== filterDistance) return false;
      if (user.role !== 'athlete' && filterUser !== "all" && s.UserID !== filterUser) return false;
      return true;
    }).sort((a, b) => new Date(a.DateTime).getTime() - new Date(b.DateTime).getTime());
  }, [history, filterBow, filterDistance, filterUser, user.role]);

  const stats = useMemo(() => {
    if (filteredHistory.length === 0) return null;
    const scores = filteredHistory.map(h => h.TotalScore);
    const max = Math.max(...scores);
    const min = Math.min(...scores);
    const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
    
    // Improvement trend
    const recent = scores.slice(-3).reduce((a, b) => a + b, 0) / Math.min(3, scores.length);
    const older = scores.slice(0, 3).reduce((a, b) => a + b, 0) / Math.min(3, scores.length);
    const trendValue = Math.round(recent - older);

    const goalProgress = Math.min(100, Math.round((max / goalScore) * 100));

    return { max, min, avg, trendValue, goalProgress };
  }, [filteredHistory, goalScore]);

  const exportCSV = () => {
    if (filteredHistory.length === 0) return;
    
    const headers = ["Date", "BowType", "Distance", "TotalScore", "10s", "Xs", "9s"];
    const rows = filteredHistory.map(s => [
      new Date(s.DateTime).toLocaleDateString(),
      s.BowType,
      s.Distance,
      s.TotalScore,
      s.Count10,
      s.CountX,
      s.Count9
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `archery_report_${new Date().getTime()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveGoal = () => {
    const val = parseInt(tempGoal);
    if (!isNaN(val) && val > 0) {
      setGoalScore(val);
      localStorage.setItem("archeryGoal", val.toString());
      setIsEditingGoal(false);
    }
  };

  const getScoreVal = (s: string) => (s === "M" ? 0 : s === "X" ? 10 : parseInt(s) || 0);

  const getEndStats = (endArrows: string[]) => {
    const vals = endArrows.map(a => getScoreVal(a));
    if (vals.length === 0) return { stdDev: 0, consistency: 0 };
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    const stdDev = Math.sqrt(vals.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / vals.length);
    const consistency = Math.max(0, 100 - (stdDev * 20)); 
    return { stdDev, consistency };
  };

  const handleExport = async (type: 'png' | 'pdf') => {
    if (!reportRef.current || !selectedScore) return;
    setIsExporting(true);
    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 3,
        useCORS: true,
        backgroundColor: "#ffffff",
        scrollX: 0,
        scrollY: -window.scrollY,
        windowWidth: document.documentElement.offsetWidth,
        windowHeight: document.documentElement.offsetHeight,
      });
      
      const fileName = `Archery-Score-${selectedScore.FullName}-${new Date(selectedScore.DateTime).getTime()}`;
      
      if (type === 'png') {
        const link = document.createElement("a");
        link.download = `${fileName}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
      } else {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
        pdf.save(`${fileName}.pdf`);
      }
    } catch (err) {
      console.error("Export failed", err);
      alert("ไม่สามารถสร้างไฟล์ได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsExporting(false);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleString("th-TH", { 
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
      });
    } catch { return dateStr; }
  };

  const recentHistory = useMemo(() => {
    return [...filteredHistory].reverse().slice(0, 5);
  }, [filteredHistory]);

  const chartData = useMemo(() => {
    return filteredHistory.map(s => {
        const d = new Date(s.DateTime);
        return {
            date: `${d.getDate()}/${d.getMonth()+1}`,
            score: s.TotalScore,
            nines: s.Count9,
            tens: s.Count10,
            xs: s.CountX
        };
    });
  }, [filteredHistory]);

  return (
    <div className="space-y-6">
      {error && (
        <div className="bento-card border-rose-100 bg-rose-50 p-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-rose-700">
             <ShieldAlert size={24} />
             <div>
               <p className="font-black kanit uppercase tracking-widest text-sm">Connection Error</p>
               <p className="text-xs opacity-80">{error}</p>
             </div>
          </div>
          <button 
            onClick={fetchData}
            className="px-6 py-2 bg-rose-600 text-white rounded-xl font-bold text-sm transition-all hover:bg-rose-700 active:scale-95 flex items-center gap-2"
          >
            <RotateCcw size={16} /> Retry Connection
          </button>
        </div>
      )}
      <div className="flex items-center justify-between border-l-4 border-blue-600 pl-4">
        <h2 className="bento-title flex items-center gap-2">
          <LayoutDashboard className="text-blue-600" /> แดชบอร์ดสถิติ
        </h2>
        <div className="flex items-center gap-2">
          <button 
            onClick={exportCSV}
            title="Export to CSV"
            className="bg-white border border-slate-200 p-2.5 rounded-xl text-slate-400 shadow-sm hover:text-emerald-600 hover:bg-emerald-50 transition-all active:scale-95"
          >
            <Download size={18} />
          </button>
          <button 
            onClick={fetchData}
            className="bg-white border border-slate-200 p-2.5 rounded-xl text-slate-400 shadow-sm hover:text-blue-600 hover:bg-blue-50 transition-all active:scale-95"
          >
            {isLoading ? <Loader2 className="animate-spin" size={18} /> : <RotateCcw size={18} />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {user.role !== 'athlete' && (
          <div className="bento-card !p-5">
            <label className="bento-label">นักกีฬา</label>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border border-slate-100 overflow-hidden shrink-0">
                 <img 
                   src={users.find(u => u.userID === filterUser)?.profileImageURL || `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=A`} 
                   alt="Athlete" 
                   className="w-full h-full object-cover"
                   referrerPolicy="no-referrer"
                 />
              </div>
              <select value={filterUser} onChange={(e) => setFilterUser(e.target.value)} className="flex-grow px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 transition-all outline-none">
                <optgroup label="Select Athlete">
                  <option value="all">ทุกคนในระบบ</option>
                  {users.map(u => <option key={u.userID} value={u.userID}>{u.firstName} {u.lastName}</option>)}
                </optgroup>
              </select>
            </div>
          </div>
        )}
        <div className="bento-card !p-5">
          <label className="bento-label">ประเภทคันธนู</label>
          <select value={filterBow} onChange={(e) => setFilterBow(e.target.value)} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 transition-all outline-none">
            <option value="all">ทั้งหมด</option>
            <option value="Recurve">Recurve</option>
            <option value="Compound">Compound</option>
          </select>
        </div>
        <div className="bento-card !p-5">
          <label className="bento-label">ระยะ</label>
          <select value={filterDistance} onChange={(e) => setFilterDistance(e.target.value)} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 transition-all outline-none">
            <option value="all">ทุกระยะ</option>
            <option value="18M">18M</option>
            <option value="30M">30M</option>
            <option value="50M">50M</option>
            <option value="70M">70M</option>
          </select>
        </div>
      </div>

      {stats ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Max Score" value={stats.max} icon={Target} color="bg-blue-600" />
            <StatCard label="Avg Score" value={stats.avg} icon={BarChart3} color="bg-cyan-500" />
            <StatCard label="Total Sets" value={filteredHistory.length} icon={LayoutDashboard} color="bg-slate-800" />
            <div className="bento-card border-none bg-blue-50 hover:bg-blue-100 transition-colors relative overflow-hidden group p-4 md:p-6 min-h-[110px]">
               <div className="flex items-center justify-between mb-2">
                  <div className="bento-label text-[10px] md:text-xs">Target Progress</div>
                  <button onClick={() => { setIsEditingGoal(true); setTempGoal(goalScore.toString()); }} className="text-blue-400 hover:text-blue-600">
                      <Edit3 size={14} />
                  </button>
               </div>
               
               {isEditingGoal ? (
                   <div className="flex items-center gap-1 animate-in zoom-in-95 duration-200">
                      <input 
                          type="number"
                          autoFocus
                          value={tempGoal}
                          onChange={(e) => setTempGoal(e.target.value)}
                          className="w-20 px-2 py-1 bg-white border border-blue-200 rounded-lg text-sm font-black text-blue-900 focus:outline-none"
                      />
                      <button onClick={handleSaveGoal} className="p-1 bg-blue-600 text-white rounded-lg"><Check size={14} /></button>
                      <button onClick={() => setIsEditingGoal(false)} className="p-1 bg-slate-300 text-white rounded-lg"><X size={14} /></button>
                   </div>
               ) : (
                  <div className="flex items-end justify-between">
                      <div>
                          <div className="kanit text-4xl font-black text-blue-900 leading-none">{stats.goalProgress}%</div>
                          <div className="text-[9px] font-black uppercase text-blue-400 tracking-wider mt-1">{stats.max} / {goalScore} PTS</div>
                      </div>
                      <div className="w-16 h-16 relative">
                          <svg className="w-full h-full transform -rotate-90">
                             <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-blue-100" />
                             <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="6" fill="transparent" strokeDasharray={175.9} strokeDashoffset={175.9 - (175.9 * stats.goalProgress) / 100} className="text-blue-600 transition-all duration-1000" />
                          </svg>
                      </div>
                  </div>
               )}
            </div>
          </div>

          <div className="bento-card">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="kanit font-black text-slate-800 uppercase tracking-widest text-sm">Score History Evolution</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Timeline of performance scores</p>
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-700 text-[10px] font-black rounded-full uppercase tracking-widest">Growth Trend</div>
              </div>
              <div className="h-[350px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                      <XAxis dataKey="date" stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} domain={[0, 360]} />
                      <Tooltip 
                          contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 20px 40px rgba(0,0,0,0.1)', padding: '12px 16px' }}
                      />
                      <Line type="monotone" dataKey="score" stroke="#2563EB" strokeWidth={4} dot={{ r: 6, fill: "#2563EB", strokeWidth: 2, stroke: "#fff" }} activeDot={{ r: 8, strokeWidth: 0 }} />
                    </LineChart>
                  </ResponsiveContainer>
              </div>
          </div>
        </div>
      ) : null}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <div className="bento-card">
             <div className="flex items-center justify-between mb-8">
               <h3 className="kanit font-black text-slate-800 uppercase tracking-widest text-sm">Hit Distribution</h3>
               <div className="flex gap-4 text-[9px] font-black uppercase tracking-wider">
                  <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-yellow-400 rounded-full" /> 9s</div>
                  <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-green-500 rounded-full" /> 10s</div>
                  <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-red-500 rounded-full" /> Xs</div>
               </div>
             </div>
             <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="date" stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} />
                    <Tooltip 
                         contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 20px 40px rgba(0,0,0,0.1)', padding: '12px 16px' }}
                    />
                    <Bar dataKey="nines" stackId="a" fill="#FACC15" />
                    <Bar dataKey="tens" stackId="a" fill="#22C55E" />
                    <Bar dataKey="xs" stackId="a" fill="#EF4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
             </div>
          </div>

          <div className="bento-card !p-0 overflow-hidden">
             <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="kanit font-black text-slate-800 uppercase tracking-widest text-[10px] md:text-sm">Recent Performance</h3>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Last 5 Sessions</span>
             </div>
             <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <tbody className="divide-y divide-slate-50">
                    {recentHistory.length === 0 ? (
                      <tr><td className="p-10 text-center text-slate-400 text-[10px] font-black uppercase tracking-widest leading-none">No history found</td></tr>
                    ) : (
                      recentHistory.map((s) => (
                        <tr key={s.ScoreID} className="group hover:bg-blue-50/50 transition-colors">
                          <td className="py-4 px-6 whitespace-nowrap">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                                <Target size={16} />
                              </div>
                              <div>
                                <div className="text-[10px] font-black text-slate-800">{s.BowType} @ {s.Distance}</div>
                                <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">{formatDate(s.DateTime)}</div>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-6 text-right whitespace-nowrap">
                             <div className="kanit text-xl font-black text-blue-600">{s.TotalScore}</div>
                             <div className="text-[9px] font-bold text-slate-300 uppercase tracking-tighter">PTS</div>
                          </td>
                          <td className="py-4 px-6 text-right">
                            <button 
                              onClick={() => setSelectedScore(s)}
                              className="p-2 text-slate-300 hover:text-blue-600 hover:bg-blue-100 rounded-xl transition-all"
                            >
                              <Eye size={18} />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
             </div>
          </div>
        </div>

        <div className="space-y-6">
           <AIInsights scores={filteredHistory} user={user} />
           <PracticeSchedule user={user} />
        </div>
      </div>

      {selectedScore && (
        <div className="fixed inset-0 bg-blue-950/40 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-y-auto" onClick={() => setSelectedScore(null)}>
          <div className="bg-white rounded-[2.5rem] shadow-2xl max-w-2xl w-full my-auto overflow-hidden animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()}>
            <div className="bg-slate-50 px-8 py-4 border-b border-slate-100 flex items-center justify-between">
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Score Report Detail</span>
               </div>
               <div className="flex items-center gap-2">
                  <button 
                    disabled={isExporting}
                    onClick={() => handleExport('png')}
                    className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-200 rounded-xl transition-all active:scale-95 flex items-center gap-2 group disabled:opacity-50"
                  >
                    {isExporting ? <Loader2 size={16} className="animate-spin" /> : <ImageIcon size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-wider hidden sm:block">PNG</span>
                  </button>
                  <button 
                    disabled={isExporting}
                    onClick={() => handleExport('pdf')}
                    className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-red-600 hover:border-red-200 rounded-xl transition-all active:scale-95 flex items-center gap-2 group disabled:opacity-50"
                  >
                    {isExporting ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />}
                    <span className="text-[10px] font-black uppercase tracking-wider hidden sm:block">PDF</span>
                  </button>
                  <button onClick={() => setSelectedScore(null)} className="p-2.5 bg-slate-200 text-slate-600 hover:bg-slate-300 rounded-xl transition-all">
                    <X size={16} />
                  </button>
               </div>
            </div>

            <div className="p-8" ref={reportRef}>
               <div className="flex justify-between items-start mb-8">
                  <div className="flex items-center gap-4">
                     <div className="w-16 h-16 bg-blue-700 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-blue-200">
                        {selectedScore.FullName?.charAt(0) || "T"}
                     </div>
                     <div>
                        <h3 className="kanit text-2xl font-black text-slate-800 uppercase leading-none mb-2">ใบบันทึกคะแนน</h3>
                        <div className="flex items-center gap-2">
                           <Calendar size={12} className="text-blue-400" />
                           <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">{formatDate(selectedScore.DateTime)}</p>
                        </div>
                     </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Total Score</div>
                    <div className="kanit text-5xl font-black text-blue-600 leading-none">{selectedScore.TotalScore}</div>
                  </div>
               </div>

               <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                  <DetailItem label="นักกีฬา" value={selectedScore.FullName} />
                  <DetailItem label="คันธนู" value={selectedScore.BowType} />
                  <DetailItem label="ระยะ" value={selectedScore.Distance} />
                  <DetailItem label="ตำแหน่ง" value={selectedScore.FaceType || "Target Face"} />
               </div>

               <div className="flex gap-2 mb-8 overflow-x-auto pb-4 no-scrollbar">
                  {[
                    { label: 'X', value: selectedScore.CountX, bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100' },
                    { label: '10', value: selectedScore.Count10, bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-100' },
                    { label: '9', value: selectedScore.Count9, bg: 'bg-slate-50', text: 'text-slate-700', border: 'border-slate-200' },
                    { label: '8-1', value: (() => {
                        const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                        const validArrows = Array.isArray(rawArrows) ? rawArrows : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                        return validArrows.filter((a: string) => !["X", "10", "9", "M"].includes(a)).length;
                    })(), bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-100' },
                    { label: 'M', value: (() => {
                        const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                        const validArrows = Array.isArray(rawArrows) ? rawArrows : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                        return validArrows.filter((a: string) => a === "M").length;
                    })(), bg: 'bg-slate-100', text: 'text-slate-500', border: 'border-slate-200' }
                  ].map((hit, i) => (
                    <div key={i} className={cn("min-w-[70px] flex-1 border rounded-2xl p-3 flex flex-col items-center", hit.bg, hit.border)}>
                        <span className="text-[9px] font-black uppercase tracking-widest mb-1 opacity-60">{hit.label}</span>
                        <span className={cn("kanit text-lg font-black", hit.text)}>{hit.value}</span>
                    </div>
                  ))}
               </div>

               <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 mb-8">
                  <div className="flex items-center justify-between mb-5 border-b border-slate-200 pb-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block">Detailed Score Sheet / ตารางคะแนนรายชุด</label>
                  </div>
                   <div className="space-y-2">
                    <div className="grid grid-cols-[3rem_1fr_4.5rem_3.5rem_4.5rem] gap-2 px-3 text-[9px] font-black text-slate-300 uppercase tracking-widest">
                        <div className="text-center">End</div>
                        <div className="text-center">Arrows Breakdown</div>
                        <div className="text-center">Consistency</div>
                        <div className="text-right">Sum</div>
                        <div className="text-right">Total</div>
                    </div>
                    {(() => {
                        const rawEndTotals = selectedScore.EndTotals ?? (selectedScore as any).endTotals;
                        const validEndTotals = Array.isArray(rawEndTotals) 
                          ? rawEndTotals 
                          : (typeof rawEndTotals === "string" ? JSON.parse(rawEndTotals) : []);

                        let runningTotal = 0;

                        return validEndTotals.map((total: number, endIdx: number) => {
                          const arrowsPerEnd = selectedScore.Distance === "18M" ? 3 : 6;
                          runningTotal += total;
                          
                          const rawArrows = selectedScore.Arrows ?? (selectedScore as any).arrows;
                          const validArrows = Array.isArray(rawArrows) 
                            ? rawArrows 
                            : (typeof rawArrows === "string" ? JSON.parse(rawArrows) : []);
                          
                          const endArrows = validArrows.slice(endIdx * arrowsPerEnd, (endIdx + 1) * arrowsPerEnd) || [];
                          const { stdDev, consistency } = getEndStats(endArrows);
                          
                          return (
                            <div key={endIdx} className="grid grid-cols-[3rem_1fr_4.5rem_3.5rem_4.5rem] gap-2 items-center bg-white p-2.5 rounded-2xl border border-slate-100 shadow-sm transition-all hover:border-blue-200 hover:shadow-md">
                              <div className="text-[10px] text-slate-300 font-black text-center">{endIdx + 1}</div>
                              <div className="flex justify-center gap-1.5">
                                 {endArrows.map((arrow: string, arrowIdx: number) => (
                                   <div key={arrowIdx} className={cn(
                                     "w-7 h-7 rounded-lg flex items-center justify-center font-mono font-black text-[10px] border shadow-sm",
                                     arrow === "X" || arrow === "10" || arrow === "9" ? "bg-yellow-50 border-yellow-200 text-yellow-700" :
                                     arrow === "8" || arrow === "7" ? "bg-red-50 border-red-200 text-red-600" :
                                     arrow === "6" || arrow === "5" ? "bg-blue-50 border-blue-200 text-blue-600" :
                                     arrow === "M" ? "bg-slate-50 border-slate-200 text-slate-400" : "bg-white border-slate-100 text-slate-700"
                                   )}>{arrow}</div>
                                 ))}
                              </div>
                              <div className="flex flex-col gap-0.5">
                                 <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                                    <div 
                                      className={cn("h-full", consistency > 80 ? "bg-emerald-500" : "bg-amber-500")}
                                      style={{ width: `${consistency}%` }}
                                    />
                                 </div>
                                 <span className="text-[7px] font-black text-slate-300 text-right">{Math.round(consistency)}%</span>
                              </div>
                              <div className="font-mono font-black text-slate-400 text-right pr-2 text-[11px]">{total}</div>
                              <div className="font-mono font-black text-blue-900 text-right pr-2 text-xs">{runningTotal}</div>
                            </div>
                          );
                        });
                    })()}
                  </div>
               </div>

               <div className="border-t border-slate-100 pt-6 mt-6 flex justify-between items-center opacity-40 grayscale">
                  <div className="flex items-center gap-2">
                     <div className="w-6 h-6 bg-blue-700 rounded-lg flex items-center justify-center text-white font-black text-[10px]">T</div>
                     <span className="text-[9px] font-black uppercase tracking-widest">TNSU Chonburi Archery</span>
                  </div>
                  <span className="text-[9px] font-bold">Official Score Report</span>
               </div>
            </div>

            <div className="p-8 bg-slate-50 border-t border-slate-100">
                <button onClick={() => setSelectedScore(null)} className="w-full py-4 bg-slate-900 text-white font-black uppercase tracking-[0.2em] rounded-2xl transition-all hover:bg-black active:scale-95 shadow-xl shadow-slate-200">
                  เรียบร้อย
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color }: { label: string, value: any, icon: any, color: string }) {
  return (
    <div className="bento-card group flex items-center justify-between p-4 md:p-6">
      <div className="space-y-1">
        <label className="bento-label !mb-0 text-[10px] md:text-xs">{label}</label>
        <div className="kanit text-2xl md:text-3xl lg:text-4xl font-black text-slate-800 transition-transform group-hover:scale-105 origin-left">
          {value}
        </div>
      </div>
      <div className={cn("p-3 md:p-4 rounded-xl md:rounded-2xl text-white shadow-lg", color)}>
        <Icon size={20} className="md:w-6 md:h-6" />
      </div>
    </div>
  );
}

function MetricBar({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-[9px] font-black uppercase tracking-[0.2em] text-cyan-400/60">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="h-2.5 bg-white/5 rounded-full overflow-hidden border border-white/5 shadow-inner">
         <div 
          className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-1000 ease-out", color)}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function DetailItem({ label, value }: { label: string, value: string }) {
  return (
    <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
      <div className="text-[9px] text-slate-400 font-bold uppercase mb-1">{label}</div>
      <div className="text-xs font-semibold text-slate-700">{value}</div>
    </div>
  );
}
