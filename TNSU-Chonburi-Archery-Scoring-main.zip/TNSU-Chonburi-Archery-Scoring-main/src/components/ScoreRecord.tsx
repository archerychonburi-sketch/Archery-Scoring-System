import React, { useState, useEffect, useRef } from "react";
import { User, Score } from "../types";
import { saveScore, getUsers, saveImage, savePdf, CONFIG } from "../services/api";
import { GoogleGenAI } from "@google/genai";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Target, Save, RotateCcw, AlertCircle, CheckCircle2, Sparkles, Loader2, Users, Camera, FileText, Upload, Image as ImageIcon, Download, ShieldAlert } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";

interface ScoreRecordProps {
  user: User;
  initialScore?: Score | null;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function ScoreRecord({ user, initialScore, onSuccess, onCancel }: ScoreRecordProps) {
  const [bowType, setBowType] = useState<string>(initialScore?.BowType || "");
  const [distance, setDistance] = useState<string>(initialScore?.Distance || "");
  const [faceType, setFaceType] = useState<string>(initialScore?.FaceType || "");
  const [dateTime, setDateTime] = useState<string>(initialScore?.DateTime || "");
  
  // RBAC Athlete selection
  const [targetAthlete, setTargetAthlete] = useState<User | null>(user.role === 'athlete' ? user : null);
  const [athletes, setAthletes] = useState<User[]>([]);
  
  // Scoring state
  const [scores, setScores] = useState<string[][]>([]); // [ends][arrows]
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);
  const [aiTip, setAiTip] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [scoreImage, setScoreImage] = useState<{data: string, name: string} | null>(initialScore?.ScoreImageURL ? { data: initialScore.ScoreImageURL, name: "existing" } : null);
  const [scorePdf, setScorePdf] = useState<{data: string, name: string} | null>(initialScore?.ScorePDFURL ? { data: initialScore.ScorePDFURL, name: "existing" } : null);
  const [isUploadingFiles, setIsUploadingFiles] = useState(false);
  // Export report state
  const [selectedScoreForReport, setSelectedScoreForReport] = useState<Score | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const scoreOptions = ["M", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "X"];

  useEffect(() => {
    if (initialScore) {
       try {
         const parsedArrows = typeof initialScore.Arrows === 'string' ? JSON.parse(initialScore.Arrows) : initialScore.Arrows;
         setScores(parsedArrows);
       } catch (e) {
         console.error("Failed to parse arrows", e);
       }
    }
  }, [initialScore]);

  useEffect(() => {
    if (!initialScore) {
      setDateTime(new Date().toISOString());
      const itv = setInterval(() => {
        setDateTime(new Date().toISOString());
      }, 5000); 
      return () => clearInterval(itv);
    }
  }, [initialScore]);

  const fetchAthletes = async () => {
    try {
      const res = await getUsers();
      if (res.success) {
        const fetchedAthletes = res.users?.filter(u => u.role === 'athlete') || [];
        setAthletes(fetchedAthletes);
        if (initialScore) {
           const found = fetchedAthletes.find(a => a.userID === initialScore.UserID);
           if (found) setTargetAthlete(found);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (user.role !== 'athlete') {
      fetchAthletes();
    }
  }, [user]);

  useEffect(() => {
    if (!distance || initialScore) return;
    const is18m = distance === "18M";
    const endsCount = is18m ? 10 : 6;
    const arrowsPerEnd = is18m ? 3 : 6;
    
    setScores(Array(endsCount).fill(null).map(() => Array(arrowsPerEnd).fill("M")));
  }, [distance]);

  const handleArrowChange = (endIdx: number, arrowIdx: number, val: string) => {
    const newScores = [...scores];
    newScores[endIdx] = [...newScores[endIdx]];
    newScores[endIdx][arrowIdx] = val;
    setScores(newScores);
  };

  const getScoreVal = (s: string) => (s === "M" ? 0 : s === "X" ? 10 : parseInt(s) || 0);

  const endTotals = scores.map(end => end.reduce((sum, s) => sum + getScoreVal(s), 0));
  const totalScore = endTotals.reduce((sum, endSum) => sum + endSum, 0);

  const flatArrows = scores.flat();
  const count9 = flatArrows.filter(a => a === "9").length;
  const count10 = flatArrows.filter(a => a === "10").length;
  const countX = flatArrows.filter(a => a === "X").length;

  const generateAiTip = async (finalScore: number) => {
    if (!targetAthlete) return;
    setIsAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      const prompt = `ในฐานะโค้ชยิงธนูอาชีพ ช่วยให้คำแนะนำสั้นๆ (2 ประโยค) สำหรับนักกีฬาชื่อ ${targetAthlete.firstName} ที่เพิ่งยิงได้คะแนน ${finalScore} เต็ม ${scores.flat().length * 10} ในระยะ ${distance} ด้วยธนูแบบ ${bowType} โดยมีจำนวน X: ${countX}, 10: ${count10}, 9: ${count9} ตอบเป็นภาษาไทยและให้กำลังใจ`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      setAiTip(response.text);
    } catch (err) {
      console.error("AI Tip Error:", err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSave = async () => {
    if (!bowType || !distance || !targetAthlete) {
        setStatus({ type: 'error', msg: 'กรุณาเลือกข้อมูลให้ครบถ้วน รวมถึงนักกีฬา' });
        return;
    }
    setIsLoading(true);
    setStatus(null);
    setAiTip(null);
    try {
      let imageURL = "";
      let pdfURL = "";

      // Step 1: Upload Files if present
      if ((scoreImage && scoreImage.name !== "existing") || (scorePdf && scorePdf.name !== "existing")) {
        setIsUploadingFiles(true);
        setStatus({ type: 'success', msg: 'กำลังอัปโหลดไฟล์...' });
        
        if (scoreImage && scoreImage.name !== "existing") {
          const res = await saveImage(scoreImage.data, scoreImage.name, initialScore?.ScoreID || "", CONFIG.SCORE_IMAGE_FOLDER_ID);
          if (res.success) imageURL = res.url;
        }
        
        if (scorePdf && scorePdf.name !== "existing") {
          const res = await savePdf(scorePdf.data, scorePdf.name, initialScore?.ScoreID || "");
          if (res.success) pdfURL = res.url;
        }
        setIsUploadingFiles(false);
      }

      // Step 2: Save Score with URLs
      setStatus({ type: 'success', msg: initialScore ? 'กำลังอัปเดตข้อมูลคะแนน...' : 'กำลังบันทึกข้อมูลคะแนน...' });
      const res = await saveScore({
        scoreID: initialScore?.ScoreID,
        UserID: targetAthlete.userID,
        Username: targetAthlete.username,
        FullName: `${targetAthlete.title}${targetAthlete.firstName} ${targetAthlete.lastName}`,
        BowType: bowType,
        Distance: distance,
        FaceType: faceType,
        DateTime: dateTime,
        TotalScore: totalScore,
        Count9: count9,
        Count10: count10,
        CountX: countX,
        Count10X: count10 + countX,
        arrows: scores, // Pass structured scores
        endTotals: endTotals,
        ScoreImageURL: imageURL || initialScore?.ScoreImageURL || "",
        ScorePDFURL: pdfURL || initialScore?.ScorePDFURL || ""
      });
      if (res.success) {
        setStatus({ type: 'success', msg: initialScore ? 'อัปเดตคะแนนเรียบร้อยแล้ว' : 'บันทึกคะแนนเรียบร้อยแล้ว' });
        setIsSaved(true);
        
        if (onSuccess) {
           setTimeout(() => onSuccess(), 1500);
        }

        // Set selected score for the report view
        setSelectedScoreForReport({
          ScoreID: res.scoreID || initialScore?.ScoreID || "",
          UserID: targetAthlete.userID,
          BowType: bowType,
          Distance: distance,
          FaceType: faceType,
          DateTime: dateTime,
          TotalScore: totalScore,
          Count9: count9,
          Count10: count10,
          CountX: countX,
          Count10X: count10 + countX,
          Arrows: flatArrows,
          EndTotals: endTotals,
          ScoreImageURL: imageURL,
          ScorePDFURL: pdfURL,
          FullName: `${targetAthlete.title}${targetAthlete.firstName} ${targetAthlete.lastName}`,
          Username: targetAthlete.username
        });
        generateAiTip(totalScore);
      } else {
        setStatus({ type: 'error', msg: res.message || 'บันทึกไม่สำเร็จ' });
      }
    } catch (err: any) {
      console.error(err);
      setStatus({ type: 'error', msg: `เกิดข้อผิดพลาดในการเชื่อมต่อ: ${err.message || 'ไม่ทราบสาเหตุ'}` });
    } finally {
      setIsLoading(false);
    }
  };

  // Helper for End Statistics
  const getEndStats = (endArrows: string[]) => {
    const vals = endArrows.map(a => getScoreVal(a));
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    const stdDev = Math.sqrt(vals.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / vals.length);
    // Consistency score: 100% means all same, decreases with spread
    const consistency = Math.max(0, 100 - (stdDev * 20)); 
    return { stdDev, consistency };
  };

  const handleExport = async (type: 'png' | 'pdf') => {
    if (!reportRef.current || !targetAthlete) return;
    setIsExporting(true);
    try {
      // Small delay to ensure any transient states or high-res images are ready
      await new Promise(resolve => setTimeout(resolve, 100));

      const canvas = await html2canvas(reportRef.current, {
        scale: 2, // Scale 2 is usually enough and more stable than 3 on some mobile devices
        useCORS: true,
        backgroundColor: "#ffffff",
        scrollX: 0,
        scrollY: 0,
        logging: false,
        onclone: (clonedDoc) => {
          // You can modify the clone here if needed to fix rendering issues
          const el = clonedDoc.querySelector('[ref="reportRef"]') as HTMLElement;
          if (el) el.style.padding = '40px';
        }
      });
      
      const fileName = `ScoreSheet-${targetAthlete.firstName}-${new Date().getTime()}`;
      
      if (type === 'png') {
        const link = document.createElement("a");
        link.download = `${fileName}.png`;
        link.href = canvas.toDataURL("image/png", 1.0);
        link.click();
      } else {
        const imgData = canvas.toDataURL("image/png", 1.0);
        const pdf = new jsPDF("p", "mm", "a4");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const imgWidth = pdfWidth - 20; // 10mm margins
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, "PNG", 10, 10, imgWidth, imgHeight);
        pdf.save(`${fileName}.pdf`);
      }
    } catch (err) {
      console.error("Export failed", err);
      alert("ไม่สามารถสร้างไฟล์ได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsExporting(false);
    }
  };

  const faceOptions: Record<string, Record<string, string[]>> = {
    "Recurve": {
      "18M": ["วงเดียว", "3 วงแนวตั้ง"],
      "30M": ["วงเดียว"], "50M": ["วงเดียว"], "70M": ["วงเดียว"]
    },
    "Compound": {
      "18M": ["วงเดียว", "3 วงแนวตั้ง"],
      "30M": ["วงเดียว"], "50M": ["วงเดียว"]
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'pdf') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (type === 'image') {
        setScoreImage({ data: base64, name: `score_${Date.now()}.jpg` });
      } else {
        setScorePdf({ data: base64, name: `score_${Date.now()}.pdf` });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between print:hidden">
        <h2 className="bento-title flex items-center gap-2 border-l-4 border-blue-600 pl-4">
          <Target className="text-blue-600" /> {isSaved ? "ใบบันทึกคะแนน (บันทึกแล้ว)" : "บันทึกคะแนนฝึกซ้อม"}
        </h2>
        <button 
          onClick={() => { 
            setBowType(""); 
            setDistance(""); 
            setFaceType(""); 
            setStatus(null); 
            setAiTip(null);
            setScoreImage(null);
            setScorePdf(null);
            setIsSaved(false);
            setSelectedScoreForReport(null);
          }}
          className="text-slate-400 hover:text-blue-600 p-2 hover:bg-white rounded-xl shadow-sm border border-slate-100 transition-all active:scale-95"
          title="Reset"
        >
          <RotateCcw size={20} />
        </button>
      </div>

      {!isSaved && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {user.role !== 'athlete' && (
            <div className="bento-card !p-5">
              <label className="bento-label flex items-center gap-1.5"><Users size={12} /> เลือกนักกีฬา</label>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full border border-slate-100 overflow-hidden shrink-0">
                   <img 
                     src={targetAthlete?.profileImageURL || `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${targetAthlete?.firstName || 'A'}`} 
                     alt="Athlete" 
                     className="w-full h-full object-cover"
                     referrerPolicy="no-referrer"
                     crossOrigin="anonymous"
                   />
                </div>
                <select 
                    value={targetAthlete?.userID || ""}
                    onChange={(e) => setTargetAthlete(athletes.find(a => a.userID === e.target.value) || null)}
                    className="flex-grow bg-blue-50 border border-blue-100 rounded-xl px-3 py-2.5 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                >
                    <option value="">-- เลือกนักกีฬา --</option>
                    {athletes.map(a => <option key={a.userID} value={a.userID}>{a.firstName} {a.lastName}</option>)}
                </select>
              </div>
            </div>
          )}
          <div className="bento-card !p-5">
            <label className="bento-label">ประเภทคันธนู</label>
            <select 
              value={bowType}
              onChange={(e) => setBowType(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
            >
              <option value="">-- เลือกประเภท --</option>
              <option value="Recurve">Recurve (โค้งกลับ)</option>
              <option value="Compound">Compound (ทดกำลัง)</option>
            </select>
          </div>

          <div className="bento-card !p-5">
            <label className="bento-label">ระยะยิง</label>
            <select 
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
            >
              <option value="">-- เลือกระยะ --</option>
              <option value="18M">18 เมตร</option>
              <option value="30M">30 เมตร</option>
              <option value="50M">50 เมตร</option>
              <option value="70M">70 เมตร</option>
            </select>
          </div>

          <div className="bento-card !p-5">
            <label className="bento-label">หน้าเป้า</label>
            <select 
              value={faceType}
              onChange={(e) => setFaceType(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
            >
              <option value="">-- เลือกหน้าเป้า --</option>
              {distance && bowType && faceOptions[bowType]?.[distance]?.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>
        </div>
      )}

      {aiTip && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-900 opacity-95 group-hover:scale-105 transition-transform duration-700" />
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 blur-[60px] rounded-full -mr-20 -mt-20 animate-pulse" />
          
          <div className="relative z-10 p-8 flex flex-col md:flex-row items-center gap-6 md:gap-8">
            <div className="shrink-0 w-20 h-20 bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl flex items-center justify-center shadow-2xl">
               <Sparkles className="text-blue-200 animate-pulse" size={40} />
            </div>
            
            <div className="flex-grow text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2 mb-3">
                 <div className="h-[1px] w-8 bg-blue-400" />
                 <h4 className="kanit font-black text-[10px] uppercase tracking-[0.4em] text-blue-200">Coach's AI Analysis</h4>
              </div>
              <blockquote className="kanit text-xl md:text-2xl font-black leading-tight text-white italic drop-shadow-sm">
                "{aiTip}"
              </blockquote>
              <div className="mt-4 flex items-center justify-center md:justify-start gap-4">
                 <span className="text-[10px] font-black uppercase tracking-widest text-blue-300/60 transition-colors group-hover:text-blue-300">Generated by Gemini Pro</span>
                 <button 
                  onClick={() => setAiTip(null)}
                  className="text-white/40 hover:text-white transition-colors text-[10px] font-black uppercase tracking-widest flex items-center gap-1"
                >
                  <RotateCcw size={10} /> Dismiss
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {isSaved && selectedScoreForReport ? (
        <div className="space-y-6">
          {/* Action Buttons for Export */}
          <div className="flex justify-end gap-3 print:hidden">
              <button
                  disabled={isExporting}
                  onClick={() => handleExport('png')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase tracking-[0.1em] px-8 py-3 rounded-2xl shadow-lg transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50"
              >
                  {isExporting ? <Loader2 size={18} className="animate-spin" /> : <ImageIcon size={18} />}
                  Export PNG
              </button>
              <button
                  disabled={isExporting}
                  onClick={() => handleExport('pdf')}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-black uppercase tracking-[0.1em] px-8 py-3 rounded-2xl shadow-lg transition-all active:scale-95 flex items-center gap-2 disabled:opacity-50"
              >
                  {isExporting ? <Loader2 size={18} className="animate-spin" /> : <FileText size={18} />}
                  Export PDF
              </button>
              <button
                  onClick={() => {
                    setIsSaved(false);
                    setBowType("");
                    setDistance("");
                    setScores([]);
                  }}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-black uppercase tracking-[0.1em] px-8 py-3 rounded-2xl transition-all active:scale-95 flex items-center gap-2"
              >
                  <RotateCcw size={18} /> New Record
              </button>
          </div>

          <div ref={reportRef} className="bg-white rounded-[2.5rem] shadow-2xl p-10 border border-slate-100 max-w-4xl mx-auto overflow-hidden">
             <div className="flex justify-between items-start mb-10">
                <div className="flex items-center gap-6">
                   <div className="w-20 h-20 bg-blue-700 rounded-3xl flex items-center justify-center text-white font-black text-3xl shadow-xl shadow-blue-100">
                      {selectedScoreForReport.FullName?.charAt(0) || "T"}
                   </div>
                   <div>
                      <h3 className="kanit text-3xl font-black text-slate-800 uppercase leading-none mb-3">ใบบันทึกคะแนน</h3>
                      <div className="flex items-center gap-2 text-blue-500">
                         <Target size={16} />
                         <p className="text-xs font-black uppercase tracking-widest leading-none">Practice Session</p>
                      </div>
                   </div>
                </div>
                <div className="text-right">
                   <div className="flex items-center justify-end gap-2 text-slate-400 mb-2">
                      <ImageIcon size={14} />
                      <span className="text-[10px] font-black uppercase tracking-widest italic">{new Date(selectedScoreForReport.DateTime).toLocaleString('th-TH')}</span>
                   </div>
                   <div className="text-[11px] font-black text-blue-400 uppercase tracking-widest mb-1 opacity-70">Total Score</div>
                   <div className="kanit text-7xl font-black text-blue-600 leading-none">{selectedScoreForReport.TotalScore}</div>
                </div>
             </div>

             <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Athlete</span>
                   <span className="text-base font-bold text-slate-800">{selectedScoreForReport.FullName}</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Bow Type</span>
                   <span className="text-base font-bold text-slate-800">{selectedScoreForReport.BowType}</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Distance</span>
                   <span className="text-base font-bold text-slate-800">{selectedScoreForReport.Distance}</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Face Type</span>
                   <span className="text-base font-bold text-slate-800">{selectedScoreForReport.FaceType || "Standard"}</span>
                </div>
             </div>

             {/* Arrow Distribution */}
             <div className="flex gap-3 mb-10">
                {[
                  { label: 'X', value: selectedScoreForReport.CountX, color: 'text-yellow-600', bg: 'bg-yellow-50', b: 'border-yellow-200' },
                  { label: '10', value: selectedScoreForReport.Count10, color: 'text-emerald-600', bg: 'bg-emerald-50', b: 'border-emerald-200' },
                  { label: '9', value: selectedScoreForReport.Count9, color: 'text-slate-600', bg: 'bg-slate-50', b: 'border-slate-200' },
                  { label: 'M', value: selectedScoreForReport.Arrows.filter(a => a === "M").length, color: 'text-rose-600', bg: 'bg-rose-50', b: 'border-rose-200' }
                ].map((stat, i) => (
                  <div key={i} className={cn("flex-1 p-4 rounded-2xl border flex flex-col items-center justify-center", stat.bg, stat.b)}>
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-40 mb-1">{stat.label}</span>
                    <span className={cn("kanit text-2xl font-black", stat.color)}>{stat.value}</span>
                  </div>
                ))}
             </div>

             {/* Detailed Table */}
             <div className="space-y-4">
               <div className="bg-slate-900 text-white p-4 rounded-t-3xl flex justify-between items-center px-8">
                  <span className="text-[11px] font-black uppercase tracking-[0.2em]">Detailed Score Sheet / ใบบันทึกคะแนนรายชุด</span>
                  <span className="text-[10px] font-bold opacity-40">Performance Breakdown</span>
               </div>
               <div className="border border-slate-200 rounded-b-3xl overflow-hidden">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-200">
                        <th className="py-4 px-6 text-center w-16">End / ชุดที่</th>
                        <th className="py-4 text-center">Arrow Scores / คะแนนแต่ละลูก</th>
                        <th className="py-4 px-6 text-center w-32 border-x border-slate-200">End Info / ข้อมูลชุด</th>
                        <th className="py-4 px-6 text-right w-24">Sum / รวมชุด</th>
                        <th className="py-4 px-6 text-right w-24 bg-blue-50/50">Total / คะแนนรวม</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedScoreForReport.EndTotals.map((endSum, endIdx) => {
                        const arrowsPerEnd = selectedScoreForReport.Distance === "18M" ? 3 : 6;
                        const endArrows = selectedScoreForReport.Arrows.slice(endIdx * arrowsPerEnd, (endIdx + 1) * arrowsPerEnd);
                        const { stdDev, consistency } = getEndStats(endArrows);
                        const runningTotal = selectedScoreForReport.EndTotals.slice(0, endIdx + 1).reduce((a, b) => a + b, 0);

                        return (
                          <tr key={endIdx} className={cn(
                            "hover:bg-slate-50/50 transition-colors",
                            endIdx % 2 === 1 ? "bg-slate-50/20" : "bg-white"
                          )}>
                            <td className="py-5 text-center font-black text-slate-300 text-xs">{endIdx + 1}</td>
                            <td className="py-5">
                               <div className="flex justify-center gap-2">
                                  {endArrows.map((arrow, aIdx) => (
                                    <div key={aIdx} className={cn(
                                      "w-10 h-10 rounded-xl border flex items-center justify-center font-mono font-black text-sm shadow-sm transition-transform hover:scale-110",
                                      arrow === "X" || arrow === "10" || arrow === "9" ? "bg-yellow-100 border-yellow-300 text-yellow-800" :
                                      arrow === "8" || arrow === "7" ? "bg-red-100 border-red-300 text-red-800" :
                                      arrow === "6" || arrow === "5" ? "bg-blue-100 border-blue-300 text-blue-800" :
                                      arrow === "M" ? "bg-slate-100 border-slate-300 text-slate-400" : "bg-white border-slate-200 text-slate-700"
                                    )}>
                                      {arrow}
                                    </div>
                                  ))}
                               </div>
                            </td>
                            <td className="py-5 px-4 border-x border-slate-200">
                               <div className="flex flex-col gap-1">
                                  <div className="flex justify-between items-center text-[8px] font-black uppercase text-slate-400">
                                     <span>Consist.</span>
                                     <span className="text-blue-600">{Math.round(consistency)}%</span>
                                  </div>
                                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                     <div 
                                        className={cn(
                                          "h-full transition-all duration-500",
                                          consistency > 90 ? "bg-emerald-500" : consistency > 70 ? "bg-blue-500" : "bg-amber-500"
                                        )} 
                                        style={{ width: `${consistency}%` }}
                                     />
                                  </div>
                                  <div className="text-[8px] font-bold text-slate-300 text-right">SD: {stdDev.toFixed(1)}</div>
                               </div>
                            </td>
                            <td className="py-5 px-6 text-right font-mono font-black text-slate-500 text-sm">{endSum}</td>
                            <td className="py-5 px-6 text-right font-mono font-black text-blue-700 bg-blue-50/30 text-base">{runningTotal}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
               </div>
             </div>

             <div className="mt-12 pt-8 border-t border-slate-100 flex justify-between items-end opacity-40">
                <div className="space-y-1">
                   <div className="flex items-center gap-2">
                       <ShieldAlert size={14} className="text-blue-600" />
                       <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-900">Official Performance Report</span>
                   </div>
                   <p className="text-[9px] font-medium text-slate-500">TNSU Chonburi Archery Training Center - Digital Score Verification System</p>
                </div>
                <div className="text-right">
                   <p className="text-[9px] font-black text-slate-900 uppercase tracking-widest mb-1">Generated By</p>
                   <p className="text-[10px] font-bold text-blue-700">Archery Coach Pro System</p>
                </div>
             </div>
          </div>
        </div>
      ) : scores.length > 0 && (
        <div className="bento-card !p-0 overflow-hidden bg-white">
          <div className="bg-slate-900 px-6 py-5 flex items-center justify-between text-white print:text-black print:bg-white border-b border-white/5">
            <div className="flex items-center gap-4">
                <span className="kanit font-black uppercase tracking-widest text-sm">Target Scoring Board</span>
                {targetAthlete && targetAthlete.userID !== user.userID && (
                    <div className="px-3 py-0.5 bg-cyan-500 text-slate-900 text-[10px] font-black rounded-full uppercase">Recording for: {targetAthlete.firstName}</div>
                )}
            </div>
            <div className="hidden sm:flex gap-4 text-[10px] font-black uppercase tracking-wider opacity-30 font-mono">
              <span>{distance}</span>
              <span className="w-1 h-1 rounded-full bg-white/20 my-auto" />
              <span>{bowType}</span>
            </div>
          </div>

          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-center border-collapse min-w-[600px] md:min-w-full">
              <thead>
                <tr className="bg-blue-50 text-[10px] font-bold text-blue-900 uppercase tracking-widest">
                  <th className="py-4 px-4 border-b border-blue-100 w-12 md:w-16">SET</th>
                  {scores[0].map((_, i) => (
                    <th key={i} className="py-4 border-b border-blue-100"># {i + 1}</th>
                  ))}
                  <th className="py-4 px-4 border-b border-blue-100 w-16 md:w-20">TOTAL</th>
                </tr>
              </thead>
              <tbody className="font-mono">
                {scores.map((end, endIdx) => (
                  <tr key={endIdx} className="hover:bg-blue-50 transition-colors">
                    <td className="py-4 px-2 text-blue-400 font-bold border-r border-blue-50 text-xs">{endIdx + 1}</td>
                    {end.map((val, arrowIdx) => (
                      <td key={arrowIdx} className="p-1.5 md:p-2">
                        <select
                          value={val}
                          onChange={(e) => handleArrowChange(endIdx, arrowIdx, e.target.value)}
                          className={cn(
                            "w-full h-12 md:h-14 rounded-xl border-2 text-center transition-all cursor-pointer font-black appearance-none text-sm md:text-base ring-offset-2 focus:ring-4",
                            `score-${val}`
                          )}
                        >
                          {scoreOptions.map(opt => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </td>
                    ))}
                    <td className="py-4 px-2 kanit font-black text-blue-700 bg-blue-50/40 text-lg">
                      {endTotals[endIdx]}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-8 bg-slate-50/50 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-6">
                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-2xl border border-slate-100 text-center shadow-sm">
                    <div className="text-2xl font-black text-slate-800">{count9}</div>
                    <div className="bento-label !mb-0 mt-1">9s</div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-100 text-center shadow-sm">
                    <div className="text-2xl font-black text-slate-800">{count10}</div>
                    <div className="bento-label !mb-0 mt-1">10s</div>
                  </div>
                  <div className="bg-white p-4 rounded-2xl border border-slate-100 text-center shadow-sm">
                    <div className="text-2xl font-black text-slate-800">{countX}</div>
                    <div className="bento-label !mb-0 mt-1">Xs</div>
                  </div>
                  <div className="bg-blue-600 p-4 rounded-2xl text-white text-center shadow-lg shadow-blue-100">
                    <div className="text-2xl font-black">{count10 + countX}</div>
                    <div className="text-[9px] font-black uppercase opacity-60 tracking-widest mt-1">10+X</div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-4 pt-4 border-t border-slate-100">
                   <div className="relative group">
                      <input type="file" accept="image/*" className="hidden" id="score-image-upload" onChange={(e) => handleFileChange(e, 'image')} />
                      <label htmlFor="score-image-upload" className={cn(
                        "flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 border-dashed transition-all cursor-pointer text-xs font-bold uppercase tracking-widest",
                        scoreImage ? "bg-emerald-50 border-emerald-500 text-emerald-600" : "bg-white border-slate-200 text-slate-400 hover:border-blue-400 hover:text-blue-500"
                      )}>
                        {scoreImage ? <CheckCircle2 size={16} /> : <Camera size={16} />}
                        {scoreImage ? "รูปภาพพร้อมแล้ว" : "แนบรูปถ่ายใบคะแนน"}
                      </label>
                   </div>

                   <div className="relative group">
                      <input type="file" accept="application/pdf" className="hidden" id="score-pdf-upload" onChange={(e) => handleFileChange(e, 'pdf')} />
                      <label htmlFor="score-pdf-upload" className={cn(
                        "flex items-center gap-2 px-4 py-2.5 rounded-xl border-2 border-dashed transition-all cursor-pointer text-xs font-bold uppercase tracking-widest",
                        scorePdf ? "bg-emerald-50 border-emerald-500 text-emerald-600" : "bg-white border-slate-200 text-slate-400 hover:border-blue-400 hover:text-blue-500"
                      )}>
                        {scorePdf ? <CheckCircle2 size={16} /> : <FileText size={16} />}
                        {scorePdf ? "PDF พร้อมแล้ว" : "แนบไฟล์ PDF คะแนน"}
                      </label>
                   </div>
                </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-8 justify-end">
              <div className="text-center sm:text-right">
                <div className="bento-label !mb-1">Total Score</div>
                <div className="kanit text-6xl font-black text-slate-900 leading-none tracking-tighter">{totalScore}</div>
              </div>
              
              {!isSaved ? (
                <button
                  disabled={isLoading || isUploadingFiles}
                  onClick={handleSave}
                  className="w-full sm:w-auto bg-blue-700 hover:bg-blue-800 text-white font-black uppercase tracking-[0.2em] px-12 py-5 rounded-[2rem] shadow-2xl shadow-blue-200 transition-all active:scale-95 flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  {isLoading || isUploadingFiles ? (
                    <span className="animate-spin h-5 w-5 border-2 border-white/30 border-t-white rounded-full" />
                  ) : (
                    <Save size={20} />
                  )}
                  {isUploadingFiles ? "UPLOADING FILES..." : isLoading ? "SAVING..." : "SAVE RECORD"}
                </button>
              ) : (
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                    <button
                        disabled={isExporting}
                        onClick={() => handleExport('png')}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-black uppercase tracking-[0.1em] px-6 py-4 rounded-2xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        {isExporting ? <Loader2 size={18} className="animate-spin" /> : <ImageIcon size={18} />}
                        PNG
                    </button>
                    <button
                        disabled={isExporting}
                        onClick={() => handleExport('pdf')}
                        className="flex-1 bg-rose-600 hover:bg-rose-700 text-white font-black uppercase tracking-[0.1em] px-6 py-4 rounded-2xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        {isExporting ? <Loader2 size={18} className="animate-spin" /> : <FileText size={18} />}
                        PDF
                    </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {status && (
        <div className={cn(
          "fixed bottom-6 right-6 p-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom border max-w-sm z-[100]",
          status.type === 'success' ? "bg-green-600 text-white border-green-500" : "bg-red-600 text-white border-red-500"
        )}>
          {status.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
          <div className="flex-grow font-medium">{status.msg}</div>
          <button onClick={() => setStatus(null)} className="text-white/50 hover:text-white">✕</button>
        </div>
      )}

    </div>
  );
}
