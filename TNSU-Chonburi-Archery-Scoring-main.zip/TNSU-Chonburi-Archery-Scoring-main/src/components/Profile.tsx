import React, { useState, useEffect } from "react";
import { User, Score } from "../types";
import { updateProfile, saveImage, getScores, CONFIG } from "../services/api";
import { hashPassword } from "../lib/security";
import { User as UserIcon, Camera, Save, Loader2, Link2, Mail, Phone, ShieldCheck, Calendar, TrendingUp, Target, ChevronRight } from "lucide-react";
import { cn } from "../lib/utils";

interface ProfileProps {
  user: User;
  onUpdate: (user: User) => void;
}

export default function Profile({ user, onUpdate }: ProfileProps) {
  const [formData, setFormData] = useState<Partial<User>>({});
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [recentScores, setRecentScores] = useState<Score[]>([]);
  const [status, setStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      setFormData({
        title: user.title,
        firstName: user.firstName,
        lastName: user.lastName,
        dateOfBirth: user.dateOfBirth,
        age: user.age,
        phone: user.phone,
        email: user.email,
        lineID: user.lineID,
        username: user.username,
      });
      setPreviewImage(user.profileImageURL || null);
      fetchRecentScores();
    }
  }, [user]);

  const fetchRecentScores = async () => {
    try {
      const res = await getScores(user.userID || "", user.role);
      if (res.success) {
        setRecentScores(res.scores.sort((a, b) => new Date(b.DateTime).getTime() - new Date(a.DateTime).getTime()).slice(0, 3));
      }
    } catch (err) {
      console.error("Failed to fetch recent scores", err);
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      setPreviewImage(base64);
      
      setIsLoading(true);
      setStatus({ type: 'success', msg: 'กำลังอัปโหลดรูปโปรไฟล์...' });
      try {
        const res = await saveImage(base64, `profile_${user.userID}.jpg`, "", CONFIG.PROFILE_FOLDER_ID);
        if (res.success) {
           const updatedUser = { ...user, profileImageURL: res.url };
           onUpdate(updatedUser);
           localStorage.setItem("archeryUser", JSON.stringify(updatedUser));
           setStatus({ type: 'success', msg: 'อัปเดตรูปโปรไฟล์สำเร็จ' });
        }
      } catch (err) {
        setStatus({ type: 'error', msg: 'อัปโหลดรูปภาพผิดพลาด' });
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password && password !== confirmPassword) {
      setStatus({ type: 'error', msg: 'รหัสผ่านไม่ตรงกัน' });
      return;
    }

    setIsLoading(true);
    setStatus(null);
    try {
      let hashedPassword;
      if (password) {
        hashedPassword = await hashPassword(password);
      }

      const res = await updateProfile({
        userID: user.userID,
        ...formData,
        password: hashedPassword
      });

      if (res.success) {
        const updatedUser = { ...user, ...formData };
        if (hashedPassword) {
          // Password updated, but we don't store it in local user object usually
        }
        onUpdate(updatedUser);
        localStorage.setItem("archeryUser", JSON.stringify(updatedUser));
        setStatus({ type: 'success', msg: 'อัปเดตข้อมูลสำเร็จ' });
        setPassword("");
        setConfirmPassword("");
      } else {
        setStatus({ type: 'error', msg: res.message || 'อัปเดตล้มเหลว' });
      }
    } catch (err) {
      setStatus({ type: 'error', msg: 'เกิดข้อผิดพลาดในการเชื่อมต่อ' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-2 border-l-4 border-blue-600 pl-4 mb-8">
        <h2 className="kanit text-2xl font-bold text-blue-900">โปรไฟล์ของฉัน</h2>
      </div>

      <div className="bg-white rounded-[40px] shadow-sm border border-blue-50 p-8">
        <div className="flex flex-col md:flex-row gap-10">
          <div className="flex flex-col items-center gap-4">
            <div className="relative group">
              <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-blue-100 shadow-xl relative">
                <img 
                  src={previewImage || `https://ui-avatars.com/api/?background=0D47A1&color=fff&name=${user.firstName}&size=160`} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <label className="absolute inset-0 bg-black/40 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                  <Camera size={32} />
                  <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                </label>
              </div>
              {isLoading && <div className="absolute inset-0 flex items-center justify-center bg-white/50 rounded-full"><Loader2 className="animate-spin text-blue-600" /></div>}
            </div>
            
            <div className="text-center">
               <div className="kanit text-xl font-bold text-blue-900">{user.title}{user.firstName} {user.lastName}</div>
               <div className="flex items-center justify-center gap-2 mt-1">
                 <ShieldCheck size={14} className="text-blue-500" />
                 <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400">{user.role}</span>
                 {user.age && <span className="text-[10px] font-bold text-slate-400">| อายุ {user.age} ปี</span>}
               </div>
            </div>
          </div>

          <form onSubmit={handleSave} className="flex-1 space-y-8">
             {status && (
               <div className={cn(
                 "p-4 rounded-2xl text-sm font-medium border",
                 status.type === 'success' ? "bg-green-50 text-green-700 border-green-100" : "bg-red-50 text-red-700 border-red-100"
               )}>
                 {status.msg}
               </div>
             )}

             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <InputGroup label="คำนำหน้า" value={formData.title || ""} onChange={v => setFormData({...formData, title: v})} type="select" options={["นาย","นาง","นางสาว","เด็กชาย","เด็กหญิง"]} />
                <InputGroup label="วันเกิด" value={formData.dateOfBirth || ""} onChange={v => setFormData({...formData, dateOfBirth: v})} type="date" icon={Calendar} />
                <InputGroup label="ชื่อ" value={formData.firstName || ""} onChange={v => setFormData({...formData, firstName: v})} />
                <InputGroup label="นามสกุล" value={formData.lastName || ""} onChange={v => setFormData({...formData, lastName: v})} />
                <InputGroup label="เบอร์โทร" value={formData.phone || ""} onChange={v => setFormData({...formData, phone: v})} icon={Phone} />
                <InputGroup label="อีเมล" value={formData.email || ""} onChange={v => setFormData({...formData, email: v})} icon={Mail} />
                <InputGroup label="LINE ID" value={formData.lineID || ""} onChange={v => setFormData({...formData, lineID: v})} icon={Link2} />
                <InputGroup label="Username" value={formData.username || ""} onChange={v => setFormData({...formData, username: v})} />
             </div>

             <div className="pt-6 border-t border-blue-50">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-4">ความปลอดภัย (Security)</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <InputGroup label="รหัสผ่านใหม่" value={password} onChange={setPassword} type="password" placeholder="เว้นว่างถ้าไม่เปลี่ยน" />
                  <InputGroup label="ยืนยันรหัสผ่านใหม่" value={confirmPassword} onChange={setConfirmPassword} type="password" placeholder="กรอกรหัสผ่านอีกครั้ง" />
                </div>
             </div>

             <button 
              type="submit" 
              disabled={isLoading}
              className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold px-12 py-4 rounded-2xl shadow-xl shadow-blue-200 transition-all flex items-center justify-center gap-2 active:scale-95"
             >
                {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                บันทึกการเปลี่ยนแปลง
             </button>
          </form>
        </div>
      </div>

      {recentScores.length > 0 && (
        <div className="bg-white rounded-[40px] shadow-sm border border-blue-50 p-8">
           <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2">
                 <TrendingUp size={20} className="text-blue-600" />
                 <h3 className="kanit text-lg font-bold text-slate-800 uppercase tracking-widest leading-none">ประวัติการบันทึกคะแนนล่าสุด</h3>
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Latest 3 Sessions</span>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {recentScores.map((s) => (
                <div key={s.ScoreID} className="bg-slate-50 border border-slate-100 rounded-3xl p-6 hover:border-blue-200 transition-all group">
                   <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-white rounded-xl shadow-sm text-blue-600">
                         <Target size={18} />
                      </div>
                      <div className="text-right">
                         <div className="text-[8px] font-black text-slate-300 uppercase tracking-widest mb-1">{new Date(s.DateTime).toLocaleDateString("th-TH")}</div>
                         <div className="kanit text-2xl font-black text-blue-600 leading-none">{s.TotalScore}</div>
                      </div>
                   </div>
                   <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{s.BowType} @ {s.Distance}</span>
                      <div className="flex gap-1">
                         <span className="w-1.5 h-1.5 rounded-full bg-red-500" title="Xs" />
                         <span className="w-1.5 h-1.5 rounded-full bg-slate-900" title="10s" />
                         <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" title="9s" />
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
}

function InputGroup({ label, value, onChange, type = "text", icon: Icon, options, placeholder }: any) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] font-bold text-blue-900 uppercase tracking-widest ml-1">{label}</label>
      <div className="relative">
        {Icon && <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-300" size={18} />}
        {type === "select" ? (
          <select 
            value={value} 
            onChange={e => onChange(e.target.value)}
            className="w-full pl-4 pr-10 py-3 bg-blue-50/50 border border-blue-100 rounded-xl focus:ring-2 focus:ring-blue-500/10 transition-all outline-none"
          >
            {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        ) : (
          <input
            type={type}
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder={placeholder}
            className={cn(
              "w-full pr-4 py-3 bg-blue-50/50 border border-blue-100 rounded-xl focus:ring-2 focus:ring-blue-500/10 transition-all outline-none",
              Icon ? "pl-12" : "pl-4"
            )}
          />
        )}
      </div>
    </div>
  );
}
