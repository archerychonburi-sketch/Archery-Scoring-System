import React, { useState, useEffect } from "react";
import { User, Role, ActivityLog } from "../types";
import { getUsers, register, deleteUser, updateProfile, getLogs, saveImage, CONFIG } from "../services/api";
import { hashPassword } from "../lib/security";
import { 
  Users, 
  UserPlus, 
  Trash2, 
  Edit2, 
  ShieldAlert, 
  BadgeCheck, 
  Search, 
  Loader2, 
  X, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  ChevronRight,
  Filter,
  Activity,
  History,
  Info,
  ExternalLink,
  Camera,
  Upload,
  Eye,
  Phone,
  MessageCircle,
  User as UserIcon,
  MapPin
} from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";

interface AdminProps {
  user: User;
  onViewHistory?: (userId: string) => void;
}

type NotificationType = "success" | "error";

interface Notification {
  id: number;
  message: string;
  type: NotificationType;
}

export default function Admin({ user, onViewHistory }: AdminProps) {
  const [activeTab, setActiveTab] = useState<"members" | "logs">("members");
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [isAdding, setIsAdding] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [viewingUser, setViewingUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const isFullAdmin = user.role === 'admin';
  const canManage = user.role === 'admin' || user.role === 'coach';

  useEffect(() => {
    if (activeTab === "members") {
      fetchUsers();
    } else {
      fetchLogs();
    }
  }, [activeTab]);

  const addNotification = (message: string, type: NotificationType = "success") => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const res = await getUsers();
      if (res.success) {
        setUsers(Array.isArray(res.users) ? res.users : []);
      } else {
        addNotification(res.message || "ไม่สามารถโหลดข้อมูลผู้ใช้ได้", "error");
      }
    } catch (err) {
      console.error(err);
      addNotification("เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchLogs = async () => {
    setIsLoading(true);
    try {
      const res = await getLogs();
      if (res.success) {
        setLogs(Array.isArray(res.logs) ? res.logs : []);
      } else {
        addNotification("ไม่สามารถโหลดบันทึกกิจกรรมได้ (ตรวจสอบการตั้งค่า GAS)", "error");
      }
    } catch (err) {
      console.error("Logs fetch error", err);
      addNotification("ไม่สามารถเชื่อมต่อข้อมูลบันทึกกิจกรรม", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (userID: string, fullName: string) => {
    if (userID === user.userID) {
        addNotification("คุณไม่สามารถลบตัวเองได้", "error");
        return;
    }
    
    if (!window.confirm(`คุณแน่ใจหรือไม่ว่าต้องการลบข้อมูลของ "${fullName}"?`)) return;
    
    try {
      const res = await deleteUser({ 
        userID,
        currentUserID: user.userID,
        currentUsername: user.username
      } as any);
      if (res.success) {
          setUsers(prev => prev.filter(u => u.userID !== userID));
          addNotification(`ลบผู้ใช้งาน "${fullName}" สำเร็จ`);
      } else {
          addNotification(res.message || "ลบข้อมูลล้มเหลว", "error");
      }
    } catch (err) {
      addNotification("เกิดข้อผิดพลาดในการลบข้อมูล", "error");
    }
  };

  const handleQuickRoleChange = async (targetUser: User, newRole: Role) => {
    if (targetUser.userID === user.userID) {
      addNotification("คุณไม่สามารถเปลี่ยนบทบาทของตัวเองผ่านหน้านี้ได้", "error");
      return;
    }
    
    if (!window.confirm(`ยืนยันการเปลี่ยนบทบาทของ "${targetUser.firstName}" เป็น "${newRole}"?`)) return;
    
    try {
      const res = await updateProfile({ 
        userID: targetUser.userID, 
        role: newRole,
        currentUserID: user.userID,
        currentUsername: user.username
      });
      if (res.success) {
        setUsers(prev => prev.map(u => u.userID === targetUser.userID ? { ...u, role: newRole } : u));
        addNotification(`เปลี่ยนบทบาทเป็น ${newRole} สำเร็จ`);
      } else {
        addNotification(res.message || "เปลี่ยนบทบาทล้มเหลว", "error");
      }
    } catch (err) {
      addNotification("เกิดข้อผิดพลาดในการเปลี่ยนบทบาท", "error");
    }
  };

  const filteredUsers = users.filter(u => {
    const fullName = `${u.firstName} ${u.lastName}`.toLowerCase();
    const matchesSearch = fullName.includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      (u.email || "").toLowerCase().includes(search.toLowerCase()) ||
      (u.phone || "").includes(search);
    
    const matchesRole = roleFilter === "all" || u.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6 relative">
      {/* Notifications */}
      <div className="fixed top-6 right-6 z-[999] flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={cn(
                "min-w-[300px] p-4 rounded-2xl shadow-2xl flex items-center gap-3 border pointer-events-auto backdrop-blur-md",
                n.type === 'success' ? "bg-emerald-500/90 text-white border-emerald-400" : "bg-red-500/90 text-white border-red-400"
              )}
            >
              {n.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
              <span className="font-bold text-sm kanit">{n.message}</span>
              <button onClick={() => setNotifications(prev => prev.filter(nn => nn.id !== n.id))} className="ml-auto p-1 hover:bg-white/20 rounded-lg"><X size={16} /></button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-l-4 border-blue-600 pl-6 py-2">
        <div>
          <h2 className="bento-title text-3xl font-black flex items-center gap-3">
            <Users className="text-blue-600 w-8 h-8" /> แผงควบคุมผู้ดูแลระบบ
          </h2>
          <p className="text-slate-400 text-sm font-medium kanit mt-1">จัดการสโมสร ยืนยันสิทธิ์ และตรวจสอบกิจกรรมในระบบ</p>
        </div>
        {activeTab === "members" && canManage && (
            <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setIsAdding(true)}
                className="bg-slate-900 text-white font-black uppercase tracking-[0.15em] text-xs px-8 py-4 rounded-2xl flex items-center justify-center gap-3 shadow-xl hover:bg-slate-800"
            >
                <UserPlus size={18} /> Add New Athlete
            </motion.button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-white p-1.5 rounded-3xl border border-slate-200 w-fit">
        <button 
          onClick={() => setActiveTab("members")}
          className={cn(
            "px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all",
            activeTab === "members" ? "bg-blue-600 text-white shadow-lg" : "text-slate-400 hover:text-slate-700 hover:bg-slate-50"
          )}
        >
          <Users size={16} /> Members
        </button>
        <button 
          onClick={() => setActiveTab("logs")}
          className={cn(
            "px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all",
            activeTab === "logs" ? "bg-blue-600 text-white shadow-lg" : "text-slate-400 hover:text-slate-700 hover:bg-slate-50"
          )}
        >
          <Activity size={16} /> Activity Logs
        </button>
      </div>

      {activeTab === "members" ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="bento-card md:col-span-7 !p-6">
              <label className="bento-label flex items-center gap-2">Search Members</label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="text" 
                  placeholder="ค้นหานักกีฬา..."
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold outline-none focus:ring-8 focus:ring-blue-500/5 transition-all placeholder:text-slate-300"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
            <div className="bento-card md:col-span-3 !p-6 font-bold">
               <label className="bento-label">Filter by Role</label>
               <select 
                 value={roleFilter}
                 onChange={(e) => setRoleFilter(e.target.value)}
                 className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black uppercase appearance-none cursor-pointer outline-none"
               >
                 <option value="all">ALL ROLES</option>
                 <option value="athlete">ATHLETES</option>
                 <option value="coach">COACHES</option>
                 <option value="admin">ADMINS</option>
               </select>
            </div>
            <div className="bento-card md:col-span-2 !p-6 flex flex-col justify-center items-center text-center bg-blue-600 border-none">
                 <span className="text-[10px] font-black uppercase text-blue-100 tracking-[0.2em] mb-1">Found</span>
                 <span className="text-5xl font-black text-white">{filteredUsers.length}</span>
            </div>
          </div>

          <div className="bento-card !p-0 overflow-hidden shadow-xl border-slate-200">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-900 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">
                    <th className="py-6 px-8">User Role</th>
                    <th className="py-6 px-6">Profile Info</th>
                    <th className="py-6 px-6">Access ID</th>
                    <th className="py-6 px-8 text-right">Settings</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {isLoading ? (
                    <tr><td colSpan={4} className="py-32 text-center text-slate-400">Loading Members...</td></tr>
                  ) : filteredUsers.length === 0 ? (
                    <tr><td colSpan={4} className="py-32 text-center text-slate-400">ไม่พบสมาชิก</td></tr>
                  ) : (
                    filteredUsers.map((u) => (
                      <tr key={u.userID} className="group hover:bg-slate-50 border-b border-slate-100 last:border-0 transition-colors">
                        <td className="py-6 px-8">
                            {isFullAdmin && u.userID !== user.userID ? (
                                <select 
                                  value={u.role}
                                  onChange={(e) => handleQuickRoleChange(u, e.target.value as Role)}
                                  className={cn(
                                    "px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider border-2 transition-all cursor-pointer outline-none",
                                    u.role === 'admin' ? "bg-purple-50 text-purple-700 border-purple-200" : 
                                    u.role === 'coach' ? "bg-orange-50 text-orange-700 border-orange-200" : 
                                    "bg-blue-50 text-blue-700 border-blue-200"
                                  )}
                                >
                                  <option value="athlete">ATHLETE</option>
                                  <option value="coach">COACH</option>
                                  <option value="admin">ADMIN</option>
                                </select>
                            ) : (
                                <span className={cn(
                                    "inline-flex px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider",
                                    u.role === 'admin' ? "bg-purple-100 text-purple-700" : 
                                    u.role === 'coach' ? "bg-orange-100 text-orange-700" : 
                                    "bg-blue-100 text-blue-700"
                                )}>{u.role}</span>
                            )}
                        </td>
                        <td className="py-6 px-6">
                            <div className="flex items-center gap-4">
                               <img 
                                  src={u.profileImageURL || `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${u.firstName}`} 
                                  alt="Avatar" 
                                  className="w-12 h-12 rounded-2xl object-cover border-2 border-white shadow-sm"
                                  referrerPolicy="no-referrer"
                               />
                               <div>
                                    <div className="text-base font-black text-slate-800 leading-tight">
                                      {u.title}{u.firstName} {u.lastName}
                                    </div>
                                    <div className="text-[11px] text-slate-400 font-medium mt-0.5">{u.email || "No email provided"}</div>
                               </div>
                            </div>
                        </td>
                        <td className="py-6 px-6">
                          <div className="flex flex-col">
                            <span className="font-mono text-xs font-bold text-blue-500">@{u.username}</span>
                            <span className="text-[9px] text-slate-300 font-mono mt-1">ID: {u.userID}</span>
                          </div>
                        </td>
                        <td className="py-6 px-8 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {canManage && (
                              <button 
                                onClick={() => setViewingUser(u)} 
                                className="p-3 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-2xl transition-all"
                                title="ดูรายละเอียดสมาชืก"
                              >
                                <Eye size={20} />
                              </button>
                            )}
                            {canManage && (
                              <button 
                                onClick={() => setEditingUser(u)} 
                                className="p-3 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-2xl transition-all"
                                title="Edit User"
                              >
                                <Edit2 size={20} />
                              </button>
                            )}
                            {isFullAdmin && (
                              <button 
                                onClick={() => handleDelete(u.userID, `${u.firstName} ${u.lastName}`)} 
                                disabled={u.role === 'admin' && user.username !== 'admin'} 
                                className="p-3 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-2xl disabled:opacity-20 transition-all pointer-events-auto"
                                title="Delete User"
                              >
                                <Trash2 size={20} />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="space-y-6">
            <div className="bento-card !p-8 bg-slate-900 border-none relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full -mr-32 -mt-32 blur-3xl group-hover:bg-blue-500/20 transition-all duration-700"></div>
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                    <div>
                        <h3 className="text-2xl font-black text-white flex items-center gap-3">
                            <History className="text-blue-400" /> ตารางบันทึกกิจกรรมย้อนหลัง
                        </h3>
                        <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2 kanit">Audit Trail of System Events</p>
                    </div>
                    <button 
                        onClick={fetchLogs} 
                        className="bg-white/10 hover:bg-white/20 text-white border border-white/10 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all"
                    >
                        {isLoading ? <Loader2 className="animate-spin" size={16} /> : <Activity size={16} />} Refresh Logs
                    </button>
                </div>
            </div>

            <div className="bento-card !p-0 overflow-hidden shadow-2xl border-slate-200">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-900 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">
                      <th className="py-6 px-8">Timestamp</th>
                      <th className="py-6 px-6">Event</th>
                      <th className="py-6 px-6">Operator</th>
                      <th className="py-6 px-8">Details</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {isLoading ? (
                      <tr><td colSpan={4} className="py-32 text-center text-slate-400">Loading Activity...</td></tr>
                    ) : logs.length === 0 ? (
                      <tr><td colSpan={4} className="py-32 text-center text-slate-400">ยังไม่มีประวัติกิจกรรม</td></tr>
                    ) : (
                      logs.map((log) => {
                        let actionColor = "text-slate-400";
                        if (log.action.includes("register")) actionColor = "text-emerald-500";
                        if (log.action.includes("delete")) actionColor = "text-red-500";
                        if (log.action.includes("saveScore") || log.action.includes("update")) actionColor = "text-blue-500";

                        return (
                          <tr key={log.logID} className="group hover:bg-slate-50 border-b border-slate-100 last:border-0 transition-colors">
                            <td className="py-5 px-8">
                              <div className="text-[10px] font-black text-slate-400 uppercase tracking-tighter tabular-nums">
                                {new Date(log.timestamp).toLocaleString('th-TH', { 
                                  day: '2-digit', month: 'short', year: '2-digit', 
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </div>
                            </td>
                            <td className="py-5 px-6">
                              <span className={cn("text-[10px] font-black uppercase tracking-widest", actionColor)}>
                                {log.action}
                              </span>
                            </td>
                            <td className="py-5 px-6">
                              <div className="flex items-center gap-2">
                                <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-600 uppercase">
                                  {log.username.charAt(0)}
                                </div>
                                <span className="font-bold text-slate-600">{log.username}</span>
                              </div>
                            </td>
                            <td className="py-5 px-8">
                              <div className="text-[11px] text-slate-400 font-mono truncate max-w-xs xl:max-w-md">
                                {log.details}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      )}

      {/* Modal - same as previous but with minor polish */}
      <AnimatePresence>
        {viewingUser && (
          <UserDetailsModal 
            user={viewingUser} 
            onClose={() => setViewingUser(null)} 
            onViewHistory={() => {
              if (onViewHistory) onViewHistory(viewingUser.userID);
              setViewingUser(null);
            }}
          />
        )}
        {canManage && (isAdding || editingUser) && (
          <UserModal 
              onClose={() => { setIsAdding(false); setEditingUser(null); }} 
              onSuccess={(msg: string) => { 
                setIsAdding(false); 
                setEditingUser(null); 
                fetchUsers();
                addNotification(msg);
              }}
              onError={(msg: string) => addNotification(msg, "error")}
              editingUser={editingUser}
              adminUser={user}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

interface UserModalProps {
  onClose: () => void;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
  editingUser: User | null;
  adminUser: User;
}

function UserModal({ onClose, onSuccess, onError, editingUser, adminUser }: UserModalProps) {
    const [data, setData] = useState({
        role: "athlete",
        title: "นาย",
        firstName: "",
        lastName: "",
        username: "",
        password: "",
        phone: "",
        email: "",
        dateOfBirth: "",
        lineID: "",
        profileImageURL: ""
    });
    const [loading, setLoading] = useState(false);
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [statusMsg, setStatusMsg] = useState("");

    useEffect(() => {
        if (editingUser) {
            setData({
                role: editingUser.role,
                title: editingUser.title || "นาย",
                firstName: editingUser.firstName,
                lastName: editingUser.lastName,
                username: editingUser.username,
                password: "",
                phone: editingUser.phone || "",
                email: editingUser.email || "",
                dateOfBirth: editingUser.dateOfBirth || "",
                lineID: editingUser.lineID || "",
                profileImageURL: editingUser.profileImageURL || ""
            });
            setPreviewImage(editingUser.profileImageURL || null);
        }
    }, [editingUser]);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setStatusMsg("กำลังตรวจสอบข้อมูล...");
        try {
            let finalImageUrl = data.profileImageURL;
            if (previewImage && previewImage !== data.profileImageURL) {
                setStatusMsg("กำลังอัปโหลดรูปภาพโปรไฟล์...");
                const imgRes = await saveImage(previewImage, `member_${Date.now()}.jpg`, "", CONFIG.PROFILE_FOLDER_ID);
                if (imgRes.success) {
                    finalImageUrl = imgRes.url;
                }
            }

            setStatusMsg("กำลังบันทึกข้อมูล...");
            let hashedPassword = data.password ? await hashPassword(data.password) : undefined;
            const res = editingUser 
                ? await updateProfile({ 
                    userID: editingUser.userID, 
                    ...data, 
                    profileImageURL: finalImageUrl,
                    password: hashedPassword,
                    PasswordHash: data.password || undefined,
                    currentUserID: adminUser.userID,
                    currentUsername: adminUser.username
                  })
                : await register({
                    ...data, 
                    profileImageURL: finalImageUrl,
                    password: hashedPassword,
                    PasswordHash: data.password,
                    currentUserID: adminUser.userID,
                    currentUsername: adminUser.username
                  });
            
            if (res.success) {
                onSuccess(editingUser ? "อัปเดตข้อมูลสำเร็จ" : "เพิ่มผู้ใช้สำเร็จ");
            } else {
                onError(res.message || "ล้มเหลว");
            }
        } catch (err: any) {
            onError(`Error: ${err.message}`);
        } finally {
            setLoading(false);
            setStatusMsg("");
        }
    };

    return (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[500] flex items-center justify-center p-4 overflow-y-auto">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="bg-white rounded-[2rem] shadow-2xl max-w-2xl w-full p-10 relative">
                <button onClick={onClose} className="absolute right-8 top-8 p-2 text-slate-400 hover:text-slate-800 transition-colors"><X size={24} /></button>
                <h3 className="text-2xl font-black text-slate-900 kanit mb-8">{editingUser ? "แก้ไขข้อมูลสมาชิก" : "เพิ่มสมาชิกใหม่"}</h3>
                <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-6">
                    <div className="col-span-2 flex flex-col items-center mb-4">
                        <div className="relative group">
                            <div className="w-24 h-24 rounded-[2rem] overflow-hidden border-2 border-dashed border-blue-200 bg-blue-50/50 flex items-center justify-center text-blue-300 shadow-inner group-hover:border-blue-400 transition-colors">
                            {previewImage ? (
                                <img src={previewImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                                <Camera size={32} />
                            )}
                            </div>
                            <label className="absolute inset-0 cursor-pointer flex items-center justify-center bg-blue-600/0 hover:bg-blue-600/10 text-transparent hover:text-blue-600 transition-all rounded-[2rem]">
                            <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                            <Upload className="hidden group-hover:block" size={24} />
                            </label>
                        </div>
                        <p className="text-[10px] text-blue-400 font-black uppercase tracking-widest mt-2">{editingUser ? "เปลี่ยนรูปโปรไฟล์" : "อัปโหลดรูปโปรไฟล์"}</p>
                    </div>

                    <div className="col-span-2 md:col-span-1 flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Role / บทบาท</label>
                        <select 
                            value={data.role} 
                            disabled={!adminUser || adminUser.role !== 'admin'}
                            onChange={e => setData({...data, role: e.target.value as Role})} 
                            className={cn(
                                "px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none border-blue-100 italic",
                                adminUser.role !== 'admin' && "opacity-60 cursor-not-allowed"
                            )}
                        >
                            <option value="athlete">Athlete / นักกีฬา</option>
                            <option value="coach">Coach / ผู้ฝึกสอน</option>
                            <option value="admin">Admin / ผู้ดูแลระบบ</option>
                        </select>
                        {adminUser.role !== 'admin' && (
                            <p className="text-[8px] text-amber-500 font-bold uppercase pl-1">* เฉพาะ Admin เท่านั้นที่เปลี่ยนสิทธิ์ได้</p>
                        )}
                    </div>
                    <div className="col-span-2 md:col-span-1 flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Name Title</label>
                        <input type="text" value={data.title} onChange={e => setData({...data, title: e.target.value})} className="px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none" placeholder="e.g. นาย" />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">First Name</label>
                        <input type="text" value={data.firstName} onChange={e => setData({...data, firstName: e.target.value})} className="px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none" required />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Last Name</label>
                        <input type="text" value={data.lastName} onChange={e => setData({...data, lastName: e.target.value})} className="px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none" required />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Username</label>
                        <input type="text" value={data.username} onChange={e => setData({...data, username: e.target.value})} className="px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none" required />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Password</label>
                        <input type="password" value={data.password} onChange={e => setData({...data, password: e.target.value})} className="px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold outline-none" placeholder={editingUser ? "Keep blank to stay same" : "Password"} required={!editingUser} />
                    </div>
                    <div className="col-span-2">
                        <button disabled={loading} className="w-full bg-slate-900 text-white font-black uppercase tracking-[0.2em] py-5 rounded-2xl flex items-center justify-center gap-3 shadow-xl transition-all active:scale-95 disabled:opacity-70">
                            {loading ? (
                                <>
                                    <Loader2 className="animate-spin" />
                                    <span className="text-[10px]">{statusMsg || (editingUser ? "Saving..." : "Creating...")}</span>
                                </>
                            ) : editingUser ? "Save Details" : "Create Member"}
                        </button>
                    </div>
                </form>
            </motion.div>
        </div>
    );
}

interface UserDetailsModalProps {
    user: User;
    onClose: () => void;
    onViewHistory: () => void;
}

function UserDetailsModal({ user, onClose, onViewHistory }: UserDetailsModalProps) {
    return (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[600] flex items-center justify-center p-4">
            <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-white rounded-[2.5rem] shadow-2xl max-w-lg w-full relative overflow-hidden"
            >
                {/* Header/Cover */}
                <div className="h-32 bg-gradient-to-br from-blue-600 to-indigo-800 relative">
                    <button 
                        onClick={onClose} 
                        className="absolute right-6 top-6 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-20"
                    >
                        <X size={20} />
                    </button>
                    <div className="absolute -bottom-12 left-8 p-1 bg-white rounded-3xl shadow-lg">
                        <img 
                            src={user.profileImageURL || `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${user.firstName}&size=200`} 
                            className="w-24 h-24 rounded-[1.25rem] object-cover" 
                            referrerPolicy="no-referrer"
                        />
                    </div>
                </div>

                <div className="pt-16 px-10 pb-10">
                    <div className="flex justify-between items-start mb-8">
                        <div>
                            <h3 className="text-2xl font-black text-slate-900 kanit leading-tight">{user.title}{user.firstName} {user.lastName}</h3>
                            <div className="flex items-center gap-2 mt-1">
                                <span className={cn(
                                    "px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider",
                                    user.role === 'admin' ? "bg-purple-100 text-purple-700" : 
                                    user.role === 'coach' ? "bg-orange-100 text-orange-700" : 
                                    "bg-blue-100 text-blue-700"
                                )}>{user.role}</span>
                                <span className="text-slate-300">•</span>
                                <span className="text-xs font-mono font-bold text-slate-400">@{user.username}</span>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                        <div className="space-y-4">
                            <DetailRow icon={<ShieldAlert size={18} className="text-amber-500" />} label="Member ID" value={user.userID} />
                            <DetailRow icon={<Phone size={18} className="text-blue-500" />} label="Phone Number" value={user.phone || "-"} />
                            <DetailRow icon={<MessageCircle size={18} className="text-emerald-500" />} label="Line ID" value={user.lineID || "-"} />
                            <DetailRow icon={<Calendar size={18} className="text-rose-500" />} label="Date of Birth" value={user.dateOfBirth ? new Date(user.dateOfBirth).toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric' }) : "-"} />
                            <DetailRow icon={<Info size={18} className="text-blue-400" />} label="Email Address" value={user.email || "-"} />
                        </div>
                    </div>

                    <div className="mt-10 pt-8 border-t border-slate-100 grid grid-cols-2 gap-4">
                        <button 
                            onClick={onViewHistory}
                            className="flex items-center justify-center gap-2 bg-slate-50 hover:bg-slate-100 text-slate-800 font-black uppercase tracking-widest text-[10px] py-4 rounded-2xl transition-all"
                        >
                            <History size={16} /> View History
                        </button>
                        <button 
                            onClick={onClose}
                            className="bg-slate-900 text-white font-black uppercase tracking-widest text-[10px] py-4 rounded-2xl shadow-xl shadow-slate-200 transition-all hover:bg-black active:scale-95"
                        >
                            Close
                        </button>
                    </div>
                </div>
            </motion.div>
        </div>
    );
}

function DetailRow({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) {
    return (
        <div className="flex items-center gap-4 bg-slate-50/50 p-4 rounded-2xl border border-slate-100 hover:border-blue-100 transition-colors">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm border border-slate-100 shrink-0">
                {icon}
            </div>
            <div>
                <p className="text-[9px] font-black uppercase tracking-[0.1em] text-slate-400 leading-none mb-1">{label}</p>
                <p className="text-sm font-bold text-slate-700">{value}</p>
            </div>
        </div>
    );
}
