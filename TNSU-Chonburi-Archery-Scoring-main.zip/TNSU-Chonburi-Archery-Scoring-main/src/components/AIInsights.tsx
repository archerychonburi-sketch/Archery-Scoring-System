import { useState } from "react";
import { Sparkles, Loader2, TrendingUp, Target, AlertCircle, CheckCircle2, ChevronRight, Brain, RotateCcw, Plus } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { analyzeScoreHistory, AIPerformanceInsights } from "../services/geminiService";
import { Score, User } from "../types";
import { cn } from "../lib/utils";
import { saveSchedule } from "../services/api";

interface AIInsightsProps {
  scores: Score[];
  user: User;
}

export default function AIInsights({ scores, user }: AIInsightsProps) {
  const [insights, setInsights] = useState<AIPerformanceInsights | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAnalyze = async () => {
    if (!scores || scores.length === 0) return;
    setIsLoading(true);
    setIsModalOpen(true);
    setInsights(null); // Reset previous insights
    try {
      const result = await analyzeScoreHistory(scores);
      setInsights(result);
    } catch (err) {
      console.error("Analysis Failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <button
        onClick={handleAnalyze}
        disabled={scores.length === 0}
        className={cn(
          "w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-black kanit uppercase tracking-widest text-xs transition-all hover:shadow-xl active:scale-95 disabled:opacity-50 disabled:grayscale",
          "shadow-[0_10px_20px_-5px_rgba(37,99,235,0.4)]"
        )}
      >
        {isLoading ? (
          <Loader2 className="animate-spin" size={18} />
        ) : (
          <Sparkles size={18} className="animate-pulse" />
        )}
        {insights ? "อัปเดตการวิเคราะห์" : "วิเคราะห์ด้วย AI"}
      </button>

      {insights && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 border border-white/10 p-5 rounded-3xl backdrop-blur-md space-y-5"
        >
          <div className="space-y-4">
            {/* Consistency */}
            <div>
              <div className="flex items-center justify-between mb-2">
                 <div className="flex items-center gap-2">
                    <TrendingUp size={14} className="text-orange-400" />
                    <label className="text-[10px] font-black text-blue-400 uppercase tracking-widest leading-none">Consistency</label>
                 </div>
                 <span className="text-lg font-black text-white leading-none">{insights.metrics.consistency}%</span>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                 <motion.div 
                   initial={{ width: 0 }}
                   animate={{ width: `${insights.metrics.consistency}%` }}
                   transition={{ duration: 1, ease: "easeOut" }}
                   className="h-full bg-gradient-to-r from-orange-400 to-amber-500 rounded-full"
                 />
              </div>
            </div>

            {/* Precision */}
            <div>
              <div className="flex items-center justify-between mb-2">
                 <div className="flex items-center gap-2">
                    <Target size={14} className="text-emerald-400" />
                    <label className="text-[10px] font-black text-blue-400 uppercase tracking-widest leading-none">Precision</label>
                 </div>
                 <span className="text-lg font-black text-white leading-none">{insights.metrics.precision}%</span>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                 <motion.div 
                   initial={{ width: 0 }}
                   animate={{ width: `${insights.metrics.precision}%` }}
                   transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
                   className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full"
                 />
              </div>
            </div>
          </div>

          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full pt-2 border-t border-white/5 text-[10px] font-black uppercase tracking-widest text-blue-300 hover:text-white transition-colors flex items-center justify-center gap-1"
          >
            เปิดดูรายละเอียด <ChevronRight size={14} />
          </button>
        </motion.div>
      )}

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-blue-950/60 backdrop-blur-xl"
            />
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-4xl max-h-[85vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col border border-white/20"
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-8 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                   <Brain size={160} className="transform rotate-12" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3">
                      <Sparkles className="text-yellow-400" size={24} />
                      <span className="text-[10px] font-black tracking-[0.5em] uppercase opacity-60">AI Performance Insights</span>
                    </div>
                    {insights && (
                      <button 
                        onClick={handleAnalyze}
                        disabled={isLoading}
                        className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition-all active:scale-90 flex items-center gap-2 group"
                        title="Re-analyze data"
                      >
                        <RotateCcw size={14} className={cn(isLoading && "animate-spin")} />
                        <span className="text-[9px] font-black uppercase tracking-widest hidden group-hover:inline opacity-0 group-hover:opacity-100 transition-opacity">Refresh</span>
                      </button>
                    )}
                  </div>
                  <h2 className="kanit text-4xl font-black uppercase tracking-tight">สรุปผลการวิเคราะห์</h2>
                  <p className="text-blue-200/70 text-sm mt-2 max-w-md">ระบบปัญญาประดิษฐ์วิเคราะห์จากประวัติการยิงล่าสุดของคุณเพื่อค้นหาจุดแข็งและโอกาสในการพัฒนา</p>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/50">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center py-20 gap-6">
                    <div className="relative">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="w-24 h-24 border-4 border-blue-100 border-t-blue-600 rounded-full"
                      />
                      <Sparkles className="absolute inset-0 m-auto text-blue-600" size={32} />
                    </div>
                    <div className="text-center">
                      <h3 className="kanit text-xl font-bold text-blue-950">กำลังจินตนาการถึงความสำเร็จของคุณ...</h3>
                      <p className="text-slate-400 text-sm mt-1">AI กำลังรวบรวมข้อมูลและจัดเตรียมคำแนะนำที่เหมาะสม</p>
                    </div>
                  </div>
                ) : insights ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Left Column: Summary & Trends */}
                    <div className="space-y-8">
                       <section className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                          <div className="flex items-center gap-2 mb-4 text-blue-600">
                             <TrendingUp size={20} />
                             <h4 className="kanit font-black text-sm uppercase tracking-widest">ภาพรวมและแนวโน้ม</h4>
                          </div>
                          <div className="space-y-4">
                            <p className="text-slate-900 leading-relaxed text-sm font-black">{insights.summary}</p>
                            <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100/50">
                               <p className="text-blue-900/70 text-xs italic">"{insights.trendAnalysis}"</p>
                            </div>
                          </div>
                       </section>

                       <section className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden relative">
                          <div className="flex items-center gap-2 mb-4 text-indigo-600">
                             <Target size={20} />
                             <h4 className="kanit font-black text-sm uppercase tracking-widest">จุดแข็ง (Strengths)</h4>
                          </div>
                          <ul className="space-y-3">
                            {insights.strengths.map((str, i) => (
                              <motion.li 
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                                key={i} 
                                className="flex items-start gap-3 group"
                              >
                                <div className="mt-0.5 bg-emerald-100 text-emerald-600 p-1 rounded-lg">
                                  <CheckCircle2 size={14} />
                                </div>
                                <span className="text-sm text-slate-600 font-bold group-hover:text-slate-900 transition-colors">{str}</span>
                              </motion.li>
                            ))}
                          </ul>
                       </section>
                    </div>

                    {/* Right Column: Weaknesses & Metrics */}
                    <div className="space-y-8">
                       <section className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                          <div className="flex items-center gap-2 mb-4 text-slate-400">
                             <AlertCircle size={20} />
                             <h4 className="kanit font-black text-sm uppercase tracking-widest">สิ่งที่ควรดูแล (Weaknesses)</h4>
                          </div>
                          <ul className="space-y-3">
                            {insights.weaknesses.map((weak, i) => (
                              <motion.li 
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                                key={i} 
                                className="flex items-start gap-3 group"
                              >
                                <div className="mt-0.5 bg-rose-100 text-rose-600 p-1 rounded-lg">
                                  <AlertCircle size={14} />
                                </div>
                                <span className="text-sm text-slate-600 font-bold group-hover:text-slate-900 transition-colors">{weak}</span>
                              </motion.li>
                            ))}
                          </ul>
                       </section>

                       <section className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
                          <div className="flex items-center gap-2 mb-6 text-cyan-600">
                             <Brain size={20} />
                             <h4 className="kanit font-black text-sm uppercase tracking-widest">ดัชนีชี้วัด (Performance Metrics)</h4>
                          </div>
                          <div className="space-y-6">
                            <MetricBar label="Stamina (ความทนทาน)" value={insights.metrics.stamina} color="from-blue-500 to-indigo-600" />
                            <MetricBar label="Precision (ความแม่นยำ)" value={insights.metrics.precision} color="from-emerald-400 to-teal-500" />
                            <MetricBar label="Consistency (ความคงที่)" value={insights.metrics.consistency} color="from-orange-400 to-amber-500" />
                          </div>
                       </section>

                       <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-1 rounded-[2rem] shadow-xl shadow-blue-500/10">
                          <div className="bg-white p-6 rounded-[calc(2rem-4px)]">
                             <div className="flex items-center justify-between mb-6">
                                <h4 className="kanit font-black text-sm uppercase tracking-[0.2em] text-blue-600">แบบฝึกแนะนำ (Training Drills)</h4>
                                <div className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-black uppercase">Drills</div>
                             </div>
                             <div className="space-y-3">
                                {insights.suggestedDrills.map((drill, i) => (
                                  <motion.div 
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.15 * i }}
                                    key={i} 
                                    className="p-4 bg-slate-50/50 border border-slate-100 rounded-2xl flex items-center gap-4 hover:border-blue-200 hover:bg-blue-50/30 transition-all cursor-default group"
                                  >
                                    <div className="flex-shrink-0 w-6 h-6 rounded-lg bg-white border border-slate-200 flex items-center justify-center shadow-sm group-hover:border-blue-400 group-hover:bg-blue-50 transition-colors">
                                      <CheckCircle2 size={14} className="text-slate-300 group-hover:text-blue-600 transition-colors" />
                                    </div>
                                    <span className="text-sm text-slate-600 font-bold leading-tight flex-1 group-hover:text-slate-900 transition-colors">{drill}</span>
                                    <button 
                                      onClick={async () => {
                                        const date = prompt("ระบุวันที่ต้องการฝึกซ้อม (เช่น 25/04/2026):", new Date().toLocaleDateString());
                                        if (date) {
                                          try {
                                            const res = await saveSchedule({
                                              drill,
                                              date,
                                              coachID: user.userID,
                                              completed: false
                                            });
                                            if (res.success) {
                                              alert("เพิ่มลงในตารางฝึกซ้อมแล้ว!");
                                              window.dispatchEvent(new Event('practiceScheduleUpdated'));
                                            }
                                          } catch (err) {
                                            console.error(err);
                                            alert("ไม่สามารถบันทึกข้อมูลได้");
                                          }
                                        }
                                      }}
                                      className="p-1 px-2 bg-blue-100 text-blue-600 rounded-lg opacity-0 group-hover:opacity-100 transition-all hover:bg-blue-600 hover:text-white"
                                      title="Add to Schedule"
                                    >
                                      <Plus size={12} />
                                    </button>
                                  </motion.div>
                                ))}
                             </div>
                          </div>
                       </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-20">
                    <div className="max-w-md mx-auto text-slate-400">
                      <AlertCircle size={64} className="mx-auto mb-6 text-rose-500 animate-bounce" />
                      <h3 className="kanit font-black text-2xl text-slate-800 mb-2">ไม่สามารถวิเคราะห์ข้อมูลได้</h3>
                      <p className="text-sm leading-relaxed mb-8">
                        สาเหตุอาจเกิดจากยังไม่ได้ตั้งค่า <code className="bg-slate-100 px-2 py-0.5 rounded text-blue-600">GEMINI_API_KEY</code> ในเมนู Secrets ของ AI Studio หรือข้อมูลประวัติการยิงของคุณยังไม่เพียงพอต่อการวิเคราะห์
                      </p>
                      <button 
                        onClick={handleAnalyze} 
                        className="px-8 py-3 bg-blue-600 text-white rounded-2xl text-sm font-black uppercase tracking-widest hover:bg-blue-700 transition-all shadow-lg active:scale-95"
                      >
                        ลองวิเคราะห์ใหม่อีกครั้ง
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-8 border-t border-slate-100 bg-white flex justify-between items-center">
                 <div className="flex items-center gap-2 text-[10px] text-slate-300 font-bold uppercase tracking-widest">
                    <Brain size={14} /> Powered by Gemini AI
                 </div>
                 <button
                   onClick={() => setIsModalOpen(false)}
                   className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black kanit uppercase tracking-widest text-sm transition-all hover:bg-black active:scale-95"
                 >
                   ขอบคุณสำหรับคำแนะนำ
                 </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MetricBar({ label, value, color }: { label: string, value: number, color: string }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden shadow-inner">
         <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.5 }}
          className={cn("h-full rounded-full bg-gradient-to-r shadow-sm", color)}
        />
      </div>
    </div>
  );
}
