import React, { useState, useEffect, useMemo } from "react";
import { Calendar, CheckCircle2, Circle, Trash2, Clock, PlusCircle, Loader2, User as UserIcon, ArrowUpDown, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";
import { PracticePlan, User } from "../types";
import { getSchedules, saveSchedule, deleteSchedule } from "../services/api";

interface PracticeScheduleProps {
  user: User;
}

type SortKey = "drill" | "date" | "coach";
type SortOrder = "asc" | "desc";

export default function PracticeSchedule({ user }: PracticeScheduleProps) {
  const [schedule, setSchedule] = useState<PracticePlan[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [newDrill, setNewDrill] = useState("");
  const [newDate, setNewDate] = useState(new Date().toLocaleDateString());
  const [isSaving, setIsSaving] = useState(false);

  const [sortBy, setSortBy] = useState<SortKey>("date");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  const canManage = user.role === 'admin' || user.role === 'coach';

  useEffect(() => {
    fetchSchedules();
    window.addEventListener('practiceScheduleUpdated', fetchSchedules);
    return () => window.removeEventListener('practiceScheduleUpdated', fetchSchedules);
  }, []);

  const fetchSchedules = async () => {
    setIsLoading(true);
    try {
      const res = await getSchedules();
      if (res.success) {
        setSchedule(res.schedules || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleComplete = async (item: PracticePlan) => {
    try {
      const updated = { ...item, completed: !item.completed };
      const res = await saveSchedule(updated);
      if (res.success) {
        setSchedule(prev => prev.map(p => p.scheduleID === item.scheduleID ? updated : p));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteItem = async (id: string) => {
    if (!window.confirm("ต้องการลบรายการนี้ใช่หรือไม่?")) return;
    try {
      const res = await deleteSchedule(id);
      if (res.success) {
        setSchedule(prev => prev.filter(p => p.scheduleID !== id));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDrill || !newDate) return;
    
    setIsSaving(true);
    try {
      const res = await saveSchedule({
        drill: newDrill,
        date: newDate,
        coachID: user.userID,
        completed: false
      });
      
      if (res.success) {
        fetchSchedules();
        setNewDrill("");
        setIsAdding(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSort = (key: SortKey) => {
    if (sortBy === key) {
      setSortOrder(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortBy(key);
      setSortOrder("asc");
    }
  };

  const sortedSchedule = useMemo(() => {
    return [...schedule].sort((a, b) => {
      let valA: string | number = "";
      let valB: string | number = "";

      if (sortBy === "drill") {
        valA = a.drill.toLowerCase();
        valB = b.drill.toLowerCase();
      } else if (sortBy === "date") {
        // Basic date string comparison, slightly fragile but works for DD/MM/YYYY if format is consistent
        // For better sorting, we should parse these to Date objects
        const parseDate = (d: string) => {
          const parts = d.split('/');
          if (parts.length === 3) {
            return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0])).getTime();
          }
          return new Date(d).getTime();
        };
        valA = parseDate(a.date);
        valB = parseDate(b.date);
      } else if (sortBy === "coach") {
        valA = a.coachID || "";
        valB = b.coachID || "";
      }

      if (valA < valB) return sortOrder === "asc" ? -1 : 1;
      if (valA > valB) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [schedule, sortBy, sortOrder]);

  const SortButton = ({ label, sortKey, icon: Icon }: { label: string, sortKey: SortKey, icon?: React.ElementType }) => (
    <button 
      onClick={() => handleSort(sortKey)}
      className={cn(
        "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
        sortBy === sortKey ? "bg-slate-900 text-white shadow-md" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
      )}
    >
      {Icon && <Icon size={12} />}
      {label}
      {sortBy === sortKey && (
        sortOrder === "asc" ? <ChevronUp size={12} className="ml-1" /> : <ChevronDown size={12} className="ml-1" />
      )}
    </button>
  );

  return (
    <div className="bento-card overflow-hidden h-full flex flex-col">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white shrink-0">
        <div className="flex items-center gap-3">
           <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600 shadow-sm border border-emerald-200">
             <Calendar size={18} />
           </div>
           <div>
              <h3 className="kanit font-black text-slate-800 uppercase tracking-widest text-sm">Practice Schedule</h3>
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">ตารางการฝึกซ้อมส่วนกลาง</p>
           </div>
        </div>
        <div className="flex items-center gap-2">
          {canManage && (
            <button 
              onClick={() => setIsAdding(!isAdding)}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-all border border-transparent hover:border-blue-100"
            >
              <PlusCircle size={20} />
            </button>
          )}
        </div>
      </div>

      <div className="px-6 py-3 border-b border-slate-50 bg-slate-50/30 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[9px] font-black text-slate-300 uppercase tracking-[0.2em] mr-2">Sort by:</span>
        <SortButton label="Date" sortKey="date" icon={Clock} />
        <SortButton label="Drill" sortKey="drill" icon={ArrowUpDown} />
        <SortButton label="Coach" sortKey="coach" icon={UserIcon} />
      </div>

      <div className="p-6 flex-grow overflow-y-auto custom-scrollbar">
        <AnimatePresence>
          {canManage && isAdding && (
            <motion.form 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              onSubmit={handleAddSchedule}
              className="mb-6 overflow-hidden space-y-3 p-4 bg-blue-50/50 rounded-3xl border border-blue-100"
            >
              <div className="grid grid-cols-1 gap-3">
                <div>
                   <label className="text-[9px] font-black text-blue-900 uppercase ml-1 mb-1 block">ชื่อแบบฝึกหัด</label>
                   <input 
                    type="text" 
                    placeholder="เช่น ยิงสะสมระยะ 18M..." 
                    value={newDrill}
                    onChange={e => setNewDrill(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-blue-200 rounded-xl text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none"
                    required
                  />
                </div>
                <div>
                   <label className="text-[9px] font-black text-blue-900 uppercase ml-1 mb-1 block">วันที่กำหนด</label>
                   <input 
                    type="text" 
                    placeholder="วว/ดด/ปปปป" 
                    value={newDate}
                    onChange={e => setNewDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-blue-200 rounded-xl text-sm font-bold"
                    required
                  />
                </div>
              </div>
              <button disabled={isSaving} type="submit" className="w-full py-3 bg-blue-600 text-white rounded-xl font-black uppercase text-xs tracking-widest hover:bg-blue-700 transition-all flex items-center justify-center gap-2">
                {isSaving ? <Loader2 className="animate-spin" size={14} /> : null}
                บันทึกตารางฝึก
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="space-y-3">
          {isLoading ? (
            <div className="py-20 flex flex-col items-center justify-center text-slate-300">
               <Loader2 className="animate-spin mb-2" size={32} />
               <span className="text-[10px] font-black uppercase tracking-widest">กำลังดึงข้อมูล...</span>
            </div>
          ) : sortedSchedule.length === 0 ? (
            <div className="py-10 text-center text-slate-400">
               <Clock className="mx-auto mb-2 opacity-20" size={32} />
               <p className="text-[10px] font-black uppercase tracking-widest">ยังไม่มีตารางซ้อมประจำวันนี้</p>
               <p className="text-[9px] mt-1 italic">Coach ยังไม่ได้กำหนดตารางการฝึกซ้อม</p>
            </div>
          ) : (
            sortedSchedule.map((item) => (
              <motion.div 
                layout
                key={item.scheduleID}
                className={cn(
                  "p-4 rounded-2xl border transition-all flex items-center gap-4 group",
                  item.completed ? "bg-slate-50 border-slate-100 opacity-60 grayscale-[0.5]" : "bg-white border-slate-100 hover:border-blue-200 hover:shadow-lg hover:shadow-blue-500/5 shadow-sm"
                )}
              >
                <button 
                  onClick={() => toggleComplete(item)}
                  className={cn(
                    "flex-shrink-0 transition-colors",
                    item.completed ? "text-blue-500" : "text-slate-200 hover:text-blue-400"
                  )}
                >
                  {item.completed ? <CheckCircle2 size={22} /> : <Circle size={22} />}
                </button>
                
                <div className="flex-grow min-w-0">
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "text-sm font-bold leading-tight truncate",
                      item.completed ? "text-slate-400 line-through" : "text-slate-700"
                    )}>
                      {item.drill}
                    </div>
                    {item.completed && (
                      <span className="bg-blue-100 text-blue-700 text-[8px] font-black uppercase px-2 py-0.5 rounded-full shrink-0">Done</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">
                      {item.date}
                    </span>
                    {item.coachID && (
                      <span className="flex items-center gap-1 text-[8px] text-slate-300 font-bold uppercase">
                        <UserIcon size={10} /> Certified by Coach
                      </span>
                    )}
                  </div>
                </div>

                {canManage && (
                  <button 
                    onClick={() => deleteItem(item.scheduleID)}
                    className="p-2 text-slate-200 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
