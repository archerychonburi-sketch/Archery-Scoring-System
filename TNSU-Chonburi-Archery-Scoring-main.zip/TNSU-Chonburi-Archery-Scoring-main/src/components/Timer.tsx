import { useState, useEffect, useRef } from "react";
import { Timer as TimerIcon, Play, Pause, RotateCcw, SkipForward, Settings2, Bell, BellOff, Maximize, Minimize, Plus, Minus, Coffee, Music, Upload, X, Volume2 } from "lucide-react";
import { cn } from "../lib/utils";

type TimerPhase = "idle" | "prep" | "shooting" | "rest" | "finished" | "shootoff";
type SoundAction = "prep" | "start" | "end" | "warning" | "transition";

interface SoundConfig {
  type: 'synth' | 'custom';
  variant?: 'standard' | 'high' | 'electronic';
  customUrl?: string;
}

export default function Timer() {
  const [totalSeconds, setTotalSeconds] = useState(180);
  const [restSeconds, setRestSeconds] = useState(120);
  const [timeLeft, setTimeLeft] = useState(180);
  const [totalEnds, setTotalEnds] = useState(6);
  const [currentEnd, setCurrentEnd] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [phase, setPhase] = useState<TimerPhase>("idle");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isMaximized, setIsMaximized] = useState(false);
  const [isABCD, setIsABCD] = useState(false);
  const [isShootOffMode, setIsShootOffMode] = useState(false);
  const [isAlternating, setIsAlternating] = useState(false);
  const [targetGroup, setTargetGroup] = useState<"AB" | "CD" | "A" | "B">("AB");
  const [countInEnd, setCountInEnd] = useState(0);

  // Sound settings
  const [soundSettings, setSoundSettings] = useState<Record<SoundAction, SoundConfig>>({
    prep: { type: 'synth', variant: 'standard' },
    start: { type: 'synth', variant: 'standard' },
    end: { type: 'synth', variant: 'standard' },
    warning: { type: 'synth', variant: 'standard' },
    transition: { type: 'synth', variant: 'standard' }
  });

  // Input states for custom settings
  const [inputSeconds, setInputSeconds] = useState("180");
  const [inputEnds, setInputEnds] = useState("6");
  const [inputRestMin, setInputRestMin] = useState("2");
  const [inputRestSec, setInputRestSec] = useState("0");

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const audioCache = useRef<Record<string, HTMLAudioElement>>({});

  // Load settings from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("timerSettings");
    if (saved) {
      try {
        const config = JSON.parse(saved);
        setTotalSeconds(config.totalSeconds || 180);
        setTotalEnds(config.totalEnds || 6);
        setRestSeconds(config.restSeconds || 120);
        setIsABCD(config.isABCD || false);
        setIsAlternating(config.isAlternating || false);
        setIsShootOffMode(config.isShootOffMode || false);
        setTimeLeft(config.totalSeconds || 180);
        
        if (config.soundSettings) {
          setSoundSettings(config.soundSettings);
        }

        setInputSeconds((config.totalSeconds || 180).toString());
        setInputEnds((config.totalEnds || 6).toString());
        setInputRestMin(Math.floor((config.restSeconds || 120) / 60).toString());
        setInputRestSec(((config.restSeconds || 120) % 60).toString());
      } catch (e) {
        console.error("Failed to load timer settings", e);
      }
    }
  }, []);

  const saveToLocal = (overrides = {}) => {
    const config = {
      totalSeconds,
      totalEnds,
      restSeconds,
      isABCD,
      isAlternating,
      isShootOffMode,
      soundSettings,
      ...overrides
    };
    localStorage.setItem("timerSettings", JSON.stringify(config));
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
        containerRef.current?.requestFullscreen().catch(err => {
            console.error(`Error attempting to enable full-screen mode: ${err.message}`);
        });
        setIsMaximized(true);
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        }
        setIsMaximized(false);
    }
  };

  // Listen for escape key or other ways fullscreen exits
  useEffect(() => {
    const handleFullscreenChange = () => {
        setIsMaximized(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      if (phase === "prep") {
        setPhase(isShootOffMode ? "shootoff" : "shooting");
        setTimeLeft(totalSeconds);
        playBeep("start");
      } else if (phase === "shooting" || phase === "shootoff") {
        // Handle Alternating Mode (A -> B -> A -> B -> A -> B)
        if (isAlternating && countInEnd < (isShootOffMode ? 1 : 5)) {
            setCountInEnd(prev => prev + 1);
            setTargetGroup(prev => prev === "A" ? "B" : "A");
            setPhase("idle"); // Wait for manual start
            setTimeLeft(timeLeft); // Stay at 0 or show prep? Let's show idle
            setIsRunning(false);
            playBeep("transition"); // Signal end of turn, prepare for next archer
        }
        // Handle AB-CD Logic (Only if not in alternating or shoot-off)
        else if (!isShootOffMode && !isAlternating && isABCD && countInEnd === 0) {
            setCountInEnd(1);
            setTargetGroup("CD");
            setPhase("idle"); // Wait for manual start
            setIsRunning(false);
            playBeep("transition"); // Signal end of AB, prepare for CD
        } else {
            // End of shooting cycle
            setCountInEnd(0);
            setIsRunning(false);
            
            if (currentEnd < totalEnds) {
                // Return to idle state, ready for next set
                setCurrentEnd(prev => prev + 1);
                setPhase("idle");
                setTimeLeft(totalSeconds);
            } else {
                // Entire competition finished
                setPhase("finished");
            }
            playBeep("end");
        }
      } else if (phase === "rest") {
          setIsRunning(false);
          setPhase("finished");
          playBeep("prep"); // Signal that rest is over
      }
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isRunning, timeLeft, phase, totalSeconds, restSeconds, currentEnd, totalEnds, isABCD, countInEnd]);

  const handleStart = () => {
    if (phase === "idle" || phase === "finished") {
      setPhase("prep");
      setTimeLeft(10);
      
      // Reset logic for fresh start
      if (currentEnd === 0 || phase === "finished") {
        setCurrentEnd(currentEnd === 0 ? 1 : currentEnd);
        setCountInEnd(0);
        if (isAlternating) {
            setTargetGroup("A");
        } else {
            setTargetGroup("AB");
        }
      }
      
      playBeep("prep");
    }
    setIsRunning(true);
  };

  const handlePause = () => setIsRunning(false);

  const handleStartRest = () => {
    setCountInEnd(0);
    setPhase("rest");
    setTimeLeft(restSeconds);
    playBeep("prep");
    setIsRunning(true);
  };

  const handleReset = () => {
    setIsRunning(false);
    setPhase("idle");
    setTimeLeft(totalSeconds);
    setCurrentEnd(0);
  };

  const handleNextSet = () => {
    if (currentEnd < totalEnds) {
      setCurrentEnd(prev => prev + 1);
      setCountInEnd(0);
      if (isAlternating) {
          setTargetGroup("A");
      } else {
          setTargetGroup("AB");
      }
      setIsRunning(false);
      setPhase("idle");
      setTimeLeft(totalSeconds);
    }
  };

  const applySettings = () => {
    const s = parseInt(inputSeconds) || 0;
    const e = parseInt(inputEnds) || 0;
    const rMin = parseInt(inputRestMin) || 0;
    const rSec = parseInt(inputRestSec) || 0;
    const rTotal = (rMin * 60) + rSec;
    
    setTotalSeconds(s);
    setTotalEnds(e);
    setRestSeconds(rTotal);
    setTimeLeft(s);
    setPhase("idle");
    setIsRunning(false);
    setCurrentEnd(0);

    // Save to localStorage
    localStorage.setItem("timerSettings", JSON.stringify({
      totalSeconds: s,
      totalEnds: e,
      restSeconds: rTotal,
      isABCD,
      isAlternating,
      isShootOffMode
    }));
  };

  const playBeep = (action: SoundAction) => {
    if (!soundEnabled) return;
    const config = soundSettings[action];

    if (config.type === 'custom' && config.customUrl) {
      if (!audioCache.current[action]) {
        audioCache.current[action] = new Audio(config.customUrl);
      }
      audioCache.current[action].currentTime = 0;
      audioCache.current[action].play().catch(e => console.error("Custom audio error", e));
      return;
    }

    try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const isShootOff = phase === "shootoff" || isShootOffMode;
        
        let baseFreq = isShootOff ? 1100 : 880; 
        let oscType: OscillatorType = "triangle";

        // Adjust based on variant
        if (config.variant === 'high') baseFreq *= 1.5;
        if (config.variant === 'electronic') oscType = "square";
        
        const playTone = (freq: number, duration: number, startTime: number, type: OscillatorType = oscType) => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            
            osc.type = type; 
            osc.frequency.setValueAtTime(freq, startTime);
            
            gain.gain.setValueAtTime(0, startTime);
            gain.gain.linearRampToValueAtTime(0.4, startTime + 0.05);
            gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
            
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            
            osc.start(startTime);
            osc.stop(startTime + duration);
        };

        const now = audioCtx.currentTime;

        switch (action) {
            case "prep": 
                playTone(baseFreq, 0.4, now);
                playTone(baseFreq, 0.4, now + 0.5);
                break;
            case "start":
                playTone(baseFreq, 1.0, now);
                break;
            case "end":
                playTone(baseFreq, 0.4, now);
                playTone(baseFreq, 0.4, now + 0.5);
                playTone(baseFreq, 0.4, now + 1.0);
                break;
            case "transition":
                playTone(baseFreq, 0.3, now);
                playTone(baseFreq, 0.3, now + 0.4);
                playTone(baseFreq, 0.3, now + 0.8);
                playTone(baseFreq * 1.25, 0.6, now + 1.3, "sine");
                break;
            case "warning":
                playTone(baseFreq * 1.5, 0.15, now);
                break;
        }
    } catch (e) {
        console.error("Audio error", e);
    }
  };

  const formatDisplayTime = (s: number) => {
    if (phase === "shooting" || phase === "prep" || phase === "idle" || phase === "shootoff") {
      return s.toString();
    }
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    if (mins > 0) return `${mins}:${secs.toString().padStart(2, '0')}`;
    return s.toString();
  };

  const getPhaseColors = () => {
    if (phase === "prep") return "bg-[#8B0000]"; // Dark Red
    if (phase === "shootoff") {
        if (timeLeft <= 5) return "bg-purple-600 animate-pulse"; // Intense pulsing purple for last 5s
        return "bg-purple-900"; // Distinct purple for Shoot-off
    }
    if (phase === "shooting") {
        if (timeLeft <= 30) return "bg-[#FFD700]"; // Yellow
        return "bg-[#006400]"; // Dark Green
    }
    if (phase === "rest") return "bg-blue-900"; // Blue for Rest
    if (phase === "finished") return "bg-[#FF0000]"; // Bright Red
    return "bg-sky-600"; // Idle / READY - Light Blue
  };

  const getGroupLabel = () => {
    if (isShootOffMode) return "SHOOT OFF";
    if (isAlternating) return `นักกีฬา ${targetGroup}`;
    if (isABCD) return `กลุ่ม ${targetGroup}`;
    return "โหมดปกติ";
  };

  const progress = (timeLeft / (phase === 'prep' ? 10 : phase === 'rest' ? restSeconds : totalSeconds)) * 100;

  return (
    <div className={cn("mx-auto space-y-6 transition-all", isMaximized ? "max-w-none px-4" : "max-w-4xl")}>
      <div className="flex items-center justify-between border-l-4 border-blue-600 pl-4 mb-8">
        <h2 className="bento-title flex items-center gap-2">
          <TimerIcon className="text-blue-600" /> ระบบจับเวลา (World Archery & Rest)
        </h2>
        <div className="flex gap-2">
            <button onClick={toggleFullscreen} title="ขยายเต็มหน้าจอ" className="text-slate-400 hover:text-blue-600 p-3 bg-white shadow-sm border border-slate-100 rounded-2xl transition-all active:scale-90">
                {isMaximized ? <Minimize size={20} /> : <Maximize size={20} />}
            </button>
            <button onClick={() => setSoundEnabled(!soundEnabled)} className="text-slate-400 hover:text-blue-600 p-3 bg-white shadow-sm border border-slate-100 rounded-2xl transition-all active:scale-90">
                {soundEnabled ? <Bell size={20} /> : <BellOff size={20} />}
            </button>
        </div>
      </div>

      <div 
        ref={containerRef}
        className={cn(
          "relative rounded-[3rem] shadow-2xl flex flex-col items-center transition-all duration-700 overflow-hidden",
          getPhaseColors(),
          isMaximized ? "fixed inset-0 z-[500] rounded-none justify-center" : "min-h-[500px] justify-center p-6"
      )}>
        {isMaximized ? (
          <div className="fixed inset-0 flex flex-col items-center justify-center p-12 transition-all duration-700">
            {/* Pure Numerical Display */}
            <div 
              className={cn(
                "font-mono font-black select-none text-black transition-all duration-500 z-10",
                phase === "shootoff" && timeLeft <= 5 && "animate-bounce scale-110 text-rose-900"
              )}
              style={{ 
                  fontSize: 'clamp(10rem, 65vmin, 90rem)',
                  lineHeight: '1'
              }}
            >
               {formatDisplayTime(timeLeft)}
            </div>

            {/* Competition Minimal Info Overlay - Always visible but subtle */}
            <div className="absolute inset-0 flex flex-col justify-between p-12 pointer-events-none">
                <div className="flex justify-between items-start">
                   <div className="flex flex-col gap-4">
                      {/* Visual Group Indicator */}
                      {(isABCD || isAlternating) && !isShootOffMode && (
                        <div className="flex gap-4 mb-2">
                             {isABCD ? (
                                <>
                                    <div className={cn(
                                        "px-8 py-3 rounded-2xl font-black text-4xl transition-all border-4",
                                        targetGroup === "AB" 
                                            ? "bg-white text-slate-900 border-white shadow-2xl scale-110" 
                                            : "bg-white/5 text-white/10 border-white/5"
                                    )}>AB</div>
                                    <div className={cn(
                                        "px-8 py-3 rounded-2xl font-black text-4xl transition-all border-4",
                                        targetGroup === "CD" 
                                            ? "bg-white text-slate-900 border-white shadow-2xl scale-110" 
                                            : "bg-white/5 text-white/10 border-white/5"
                                    )}>CD</div>
                                </>
                            ) : (
                                <>
                                    <div className={cn(
                                        "px-8 py-3 rounded-2xl font-black text-4xl transition-all border-4",
                                        targetGroup === "A" 
                                            ? "bg-white text-slate-900 border-white shadow-2xl scale-110" 
                                            : "bg-white/5 text-white/10 border-white/5"
                                    )}>A</div>
                                    <div className={cn(
                                        "px-8 py-3 rounded-2xl font-black text-4xl transition-all border-4",
                                        targetGroup === "B" 
                                            ? "bg-white text-slate-900 border-white shadow-2xl scale-110" 
                                            : "bg-white/5 text-white/10 border-white/5"
                                    )}>B</div>
                                </>
                            )}
                        </div>
                      )}
                      <div className="text-white/40 font-black text-xl uppercase tracking-[0.4em] font-sans drop-shadow-md">
                        {getGroupLabel()}
                      </div>
                      <div className="text-white/80 font-black text-2xl uppercase tracking-[0.2em] bg-white/5 py-2 px-6 rounded-xl backdrop-blur-md w-fit border border-white/10 shadow-xl">
                        {phase.toUpperCase()}
                      </div>
                   </div>
                   {/* Persistent SET Counter - Scoreboard Style */}
                   <div className="text-white bg-black/30 py-6 px-10 rounded-[2.5rem] backdrop-blur-xl border border-white/10 flex flex-col items-center shadow-2xl relative overflow-hidden group">
                     {/* Decorative gradient background */}
                     <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
                     
                     <span className="text-xs font-black tracking-[0.5em] mb-3 text-white/40 kanit uppercase relative z-10">SET / END</span>
                     <div className="flex items-center gap-4 relative z-10">
                       <span className="text-8xl font-black leading-none tabular-nums drop-shadow-[0_4px_12px_rgba(0,0,0,0.3)]">{currentEnd}</span>
                       <div className="flex flex-col items-center">
                          <div className="w-1 h-12 bg-white/20 rounded-full mb-1" />
                          <span className="text-3xl font-black opacity-30">OF</span>
                          <div className="w-1 h-4 bg-white/10 rounded-full mt-1" />
                       </div>
                       <span className="text-5xl font-black opacity-60 tabular-nums">{totalEnds}</span>
                     </div>
                   </div>
                </div>
                
                {(isABCD || isAlternating) && !isShootOffMode && (phase === "shooting" || phase === "prep") && (
                    <div className="absolute inset-0 flex items-center justify-center opacity-[0.08] pointer-events-none">
                        <div className="text-white font-black text-[60rem] leading-none select-none animate-pulse">{targetGroup}</div>
                    </div>
                )}

                <div className="flex items-center justify-center gap-10 pointer-events-auto opacity-40 hover:opacity-100 transition-all duration-75 transform translate-y-1 hover:translate-y-0">
                    <button onClick={handleReset} title="รีเซ็ต" className="w-20 h-20 rounded-3xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition-all hover:scale-110 active:scale-90 border border-white/10">
                        <RotateCcw size={32} />
                    </button>
                    <button onClick={isRunning ? handlePause : handleStart} className={cn("w-32 h-32 rounded-full flex items-center justify-center transition-all shadow-2xl border-4 transition-all hover:scale-110 active:scale-95", isRunning ? "bg-white text-slate-900 border-white" : "bg-cyan-400 text-slate-900 border-cyan-400")}>
                        {isRunning ? <Pause size={56} fill="currentColor" /> : <Play size={56} className="ml-2" fill="currentColor" />}
                    </button>
                    <button 
                        onClick={handleStartRest} 
                        title="เริ่มเวลาพัก"
                        className={cn("w-20 h-20 rounded-3xl flex items-center justify-center transition-all hover:scale-110 active:scale-90 border", phase === "rest" ? "bg-cyan-400 text-slate-900 border-cyan-400" : "bg-white/5 hover:bg-white/10 text-white border-white/10")}
                    >
                        <Coffee size={32} />
                    </button>
                    <button onClick={handleNextSet} title="ชุดถัดไป" className="w-20 h-20 rounded-3xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition-all hover:scale-110 active:scale-90 border border-white/10">
                        <SkipForward size={32} />
                    </button>
                    <button onClick={toggleFullscreen} title="ลดขนาด" className="w-20 h-20 rounded-3xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition-all hover:scale-110 active:scale-90 border border-white/10">
                        <Minimize size={32} />
                    </button>
                </div>
            </div>
          </div>
        ) : (
          <div className="relative z-10 text-center flex flex-col items-center justify-center gap-8 w-full max-w-7xl">
            {/* Mode/Group Indicator Bar */}
            {(isABCD || isAlternating) && !isShootOffMode && (
                <div className="flex gap-4 mb-4">
                    {isABCD ? (
                        <>
                            <div className={cn(
                                "px-8 py-3 rounded-2xl font-black text-3xl transition-all border-2",
                                targetGroup === "AB" 
                                    ? "bg-white text-slate-900 border-white shadow-xl scale-110" 
                                    : "bg-black/20 text-white/20 border-white/10"
                            )}>AB</div>
                            <div className={cn(
                                "px-8 py-3 rounded-2xl font-black text-3xl transition-all border-2",
                                targetGroup === "CD" 
                                    ? "bg-white text-slate-900 border-white shadow-xl scale-110" 
                                    : "bg-black/20 text-white/20 border-white/10"
                            )}>CD</div>
                        </>
                    ) : (
                        <>
                            <div className={cn(
                                "px-8 py-3 rounded-2xl font-black text-3xl transition-all border-2",
                                targetGroup === "A" 
                                    ? "bg-white text-slate-900 border-white shadow-xl scale-110" 
                                    : "bg-black/20 text-white/20 border-white/10"
                            )}>ARCHER A</div>
                            <div className={cn(
                                "px-8 py-3 rounded-2xl font-black text-3xl transition-all border-2",
                                targetGroup === "B" 
                                    ? "bg-white text-slate-900 border-white shadow-xl scale-110" 
                                    : "bg-black/20 text-white/20 border-white/10"
                            )}>ARCHER B</div>
                        </>
                    )}
                </div>
            )}

            {/* Minimalist Info */}
            <div className="flex flex-col items-center gap-2">
                {isShootOffMode && (phase === "shootoff" || phase === "prep") && (
                    <div className="text-purple-300 font-black text-3xl md:text-5xl mb-2 animate-pulse uppercase tracking-widest">SHOOT OFF</div>
                )}
                {(isABCD || isAlternating) && !isShootOffMode && (phase === "shooting" || phase === "prep") && (
                    <div className="flex flex-col items-center gap-1">
                        <div className="text-white/60 font-black text-xl uppercase tracking-[0.3em] font-sans">{getGroupLabel()}</div>
                        <div className="text-white font-black text-[8rem] md:text-[10rem] animate-pulse drop-shadow-2xl">{targetGroup}</div>
                    </div>
                )}
                <div className="text-white font-black text-2xl uppercase tracking-[0.4em] opacity-40">
                {phase === "prep" && "READYING"}
                {phase === "shootoff" && "SHOOT-OFF!"}
                {phase === "shooting" && (timeLeft <= 30 ? "WARNING" : "SHOUTING")}
                {phase === "rest" && "RESTING / SCORING"}
                {phase === "finished" && "DONE"}
                {phase === "idle" && "READY"}
                </div>
            </div>

            {/* Purified Main Display (No symbols, no deco) */}
            <div className={cn(
                "font-mono text-[12rem] md:text-[18rem] font-black leading-none select-none text-black transition-all",
                phase === "shootoff" && timeLeft <= 5 && "animate-bounce scale-110 text-rose-900"
            )}>
               {formatDisplayTime(timeLeft)}
            </div>

            {/* Pure Info Row */}
            <div className="kanit text-4xl text-white font-black uppercase tracking-widest opacity-60">
              SET {currentEnd} <span className="mx-2 text-white/20 opacity-50">OF</span> {totalEnds}
            </div>

            {/* Clean Controls */}
            <div className="flex items-center justify-center gap-6 mt-4">
               <button onClick={handleReset} title="รีเซ็ต" className="w-14 h-14 rounded-2xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition-all">
                 <RotateCcw size={24} />
               </button>
               <button onClick={isRunning ? handlePause : handleStart} className={cn("w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-2xl", isRunning ? "bg-white text-slate-900" : "bg-cyan-400 text-slate-900")}>
                 {isRunning ? <Pause size={40} fill="currentColor" /> : <Play size={40} fill="currentColor" className="ml-2" />}
               </button>
               <button 
                onClick={handleStartRest} 
                title="เริ่มเวลาพักระหว่างเซต"
                className={cn("w-14 h-14 rounded-2xl flex items-center justify-center transition-all", phase === "rest" ? "bg-cyan-400 text-slate-900" : "bg-white/5 hover:bg-white/10 text-white")}
               >
                 <Coffee size={24} />
               </button>
               <button onClick={handleNextSet} title="ชุดถัดไป" className="w-14 h-14 rounded-2xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition-all">
                 <SkipForward size={24} />
               </button>
            </div>
          </div>
        )}
      </div>

      <div className="bento-card relative">
        <div className="flex items-center gap-3 mb-8 border-b border-slate-100 pb-5">
          <Settings2 className="text-blue-600" />
          <h3 className="kanit font-black text-slate-800 uppercase tracking-[0.2em] text-sm">Timer & Rest Settings</h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="space-y-6">
                <div className="space-y-4">
                    <label className="bento-label">เวลาต่อชุด (Shoot Time)</label>
                    <div className="flex items-center gap-4">
                        <input 
                            type="number" 
                            value={inputSeconds}
                            onChange={(e) => setInputSeconds(e.target.value)}
                            className="w-32 bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 text-2xl font-mono font-black text-slate-800 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all"
                        />
                        <span className="text-slate-400 font-bold">วินาที</span>
                    </div>
                </div>

                <div className="space-y-4">
                    <label className="bento-label">ระยะยิงมาตรฐาน</label>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => { setInputSeconds("90"); setInputEnds("10"); }}
                            className={cn("p-4 rounded-2xl border-2 text-left transition-all", totalSeconds === 90 ? "bg-slate-900 border-slate-900 text-white" : "bg-white border-slate-100")}
                        >
                            <div className="font-black text-xs">18M INDOOR</div>
                            <div className="text-[10px] opacity-70">3 ลูก / 90 วิ</div>
                        </button>
                        <button 
                            onClick={() => { setInputSeconds("180"); setInputEnds("6"); }}
                            className={cn("p-4 rounded-2xl border-2 text-left transition-all", totalSeconds === 180 ? "bg-slate-900 border-slate-900 text-white" : "bg-white border-slate-100")}
                        >
                            <div className="font-black text-xs">OUTDOOR</div>
                            <div className="text-[10px] opacity-70">6 ลูก / 180 วิ</div>
                        </button>
                    </div>
                </div>

                <div className="space-y-4">
                    <label className="bento-label">รูปแบบการยิง (Shooting Style)</label>
                    <div className="flex flex-wrap items-center gap-2 p-1 bg-slate-100 rounded-2xl w-fit">
                        <button 
                            onClick={() => { setIsABCD(false); setIsAlternating(false); }}
                            className={cn("px-6 py-2 rounded-xl text-xs font-black transition-all", !isABCD && !isAlternating ? "bg-white text-slate-900 shadow-sm" : "text-slate-400")}
                        >SINGLE</button>
                        <button 
                            onClick={() => { setIsABCD(true); setIsAlternating(false); }}
                            className={cn("px-6 py-2 rounded-xl text-xs font-black transition-all", isABCD ? "bg-white text-slate-900 shadow-sm" : "text-slate-400")}
                        >AB - CD</button>
                        <button 
                            onClick={() => { 
                                setIsAlternating(true); 
                                setIsABCD(false);
                                setInputSeconds("20");
                            }}
                            className={cn("px-6 py-2 rounded-xl text-xs font-black transition-all", isAlternating ? "bg-white text-slate-900 shadow-sm" : "text-slate-400")}
                        >A - B (Alternating)</button>
                    </div>
                </div>

                <div className="space-y-4">
                    <label className="bento-label">โหมดตัดสิน (Shoot-off Mode)</label>
                    <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl w-fit">
                        <button 
                            onClick={() => { setIsShootOffMode(false); }}
                            className={cn("px-6 py-2 rounded-xl text-xs font-black transition-all", !isShootOffMode ? "bg-white text-slate-900 shadow-sm" : "text-slate-400")}
                        >NORMAL</button>
                        <button 
                            onClick={() => { 
                                setIsShootOffMode(true); 
                                setInputSeconds("20");
                                setInputEnds("1");
                                setIsABCD(false);
                            }}
                            className={cn("px-6 py-2 rounded-xl text-xs font-black transition-all", isShootOffMode ? "bg-purple-600 text-white shadow-sm" : "text-slate-400")}
                        >SHOOT-OFF</button>
                    </div>
                </div>
            </div>

            <div className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                    <div className="space-y-4">
                        <label className="bento-label">เวลาพัก (Rest Time)</label>
                        <div className="flex items-center gap-2">
                            <input 
                                type="number" 
                                placeholder="Min"
                                value={inputRestMin}
                                onChange={(e) => setInputRestMin(e.target.value)}
                                className="w-20 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 text-xl font-mono font-black text-slate-800 text-center"
                            />
                            <span className="text-slate-300">:</span>
                            <input 
                                type="number" 
                                placeholder="Sec"
                                value={inputRestSec}
                                onChange={(e) => setInputRestSec(e.target.value)}
                                className="w-20 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-4 text-xl font-mono font-black text-slate-800 text-center"
                            />
                        </div>
                    </div>

                    <div className="space-y-4">
                        <label className="bento-label">จำนวนชุด (Ends)</label>
                        <div className="flex items-center gap-3">
                            <button onClick={() => setInputEnds(prev => Math.max(1, parseInt(prev) - 1).toString())} className="p-3 bg-slate-100 rounded-xl"><Minus size={18} /></button>
                            <input 
                                type="number" 
                                value={inputEnds}
                                onChange={(e) => setInputEnds(e.target.value)}
                                className="w-20 bg-slate-50 border border-slate-200 rounded-2xl py-4 text-xl font-mono font-black text-slate-800 text-center"
                            />
                            <button onClick={() => setInputEnds(prev => (parseInt(prev) + 1).toString())} className="p-3 bg-slate-100 rounded-xl"><Plus size={18} /></button>
                        </div>
                    </div>
                </div>

                <button 
                    onClick={applySettings}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-[0.2em] py-5 rounded-[2rem] shadow-xl shadow-blue-100 transition-all active:scale-[0.98]"
                >
                    ตกลงและบันทึก / UPDATE SETTINGS
                </button>
            </div>
        </div>

        {/* Sound Customization Section */}
        <div className="mt-12 pt-8 border-t border-slate-100">
            <div className="flex items-center gap-3 mb-6">
                <Music className="text-emerald-500" />
                <h3 className="kanit font-black text-slate-800 uppercase tracking-[0.2em] text-sm">ลิสต์เสียงสัญญาณ / Sound Customization</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {(Object.keys(soundSettings) as Array<SoundAction>).map((action) => (
                    <div key={action} className="p-5 rounded-3xl bg-slate-50 border border-slate-100 space-y-4">
                        <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">{action} phase</span>
                            <button 
                                onClick={() => playBeep(action)}
                                className="p-2 hover:bg-white rounded-xl text-blue-500 transition-colors shadow-sm"
                            >
                                <Volume2 size={14} />
                            </button>
                        </div>
                        
                        <div className="space-y-3">
                            <div className="flex items-center gap-2 p-1 bg-white rounded-xl border border-slate-100">
                                <button 
                                    onClick={() => {
                                        const newSets = { ...soundSettings, [action]: { ...soundSettings[action], type: 'synth' as const } };
                                        setSoundSettings(newSets);
                                        saveToLocal({ soundSettings: newSets });
                                    }}
                                    className={cn(
                                        "flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all",
                                        soundSettings[action].type === 'synth' ? "bg-slate-900 text-white" : "text-slate-400"
                                    )}
                                >Synth</button>
                                <button 
                                    onClick={() => {
                                        const newSets = { ...soundSettings, [action]: { ...soundSettings[action], type: 'custom' as const } };
                                        setSoundSettings(newSets);
                                        saveToLocal({ soundSettings: newSets });
                                    }}
                                    className={cn(
                                        "flex-1 py-2 rounded-lg text-[9px] font-black uppercase transition-all",
                                        soundSettings[action].type === 'custom' ? "bg-slate-900 text-white" : "text-slate-400"
                                    )}
                                >Custom</button>
                            </div>

                            {soundSettings[action].type === 'synth' ? (
                                <select 
                                    value={soundSettings[action].variant}
                                    onChange={(e) => {
                                        const newSets = { ...soundSettings, [action]: { ...soundSettings[action], variant: e.target.value as any } };
                                        setSoundSettings(newSets);
                                        saveToLocal({ soundSettings: newSets });
                                    }}
                                    className="w-full bg-white border border-slate-100 rounded-xl px-3 py-2 text-xs font-bold outline-none"
                                >
                                    <option value="standard">Standard Beep</option>
                                    <option value="high">High Pitch</option>
                                    <option value="electronic">Electronic Square</option>
                                </select>
                            ) : (
                                <div className="space-y-2">
                                    {soundSettings[action].customUrl ? (
                                        <div className="flex items-center justify-between gap-2 bg-emerald-50 p-2 rounded-xl border border-emerald-100 max-w-full overflow-hidden">
                                            <span className="text-[9px] font-bold text-emerald-600 truncate flex-grow">Custom Sound Loaded</span>
                                            <button 
                                                onClick={() => {
                                                    const newSets = { ...soundSettings, [action]: { ...soundSettings[action], customUrl: undefined } };
                                                    setSoundSettings(newSets);
                                                    saveToLocal({ soundSettings: newSets });
                                                    if (audioCache.current[action]) delete audioCache.current[action];
                                                }}
                                                className="p-1.5 hover:bg-emerald-100 rounded-lg text-emerald-600"
                                            >
                                                <X size={12} />
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="relative">
                                            <input 
                                                type="file" 
                                                accept="audio/*"
                                                onChange={(e) => {
                                                    const file = e.target.files?.[0];
                                                    if (file) {
                                                        const reader = new FileReader();
                                                        reader.onload = (re) => {
                                                            const url = re.target?.result as string;
                                                            const newSets = { ...soundSettings, [action]: { ...soundSettings[action], customUrl: url } };
                                                            setSoundSettings(newSets);
                                                            saveToLocal({ soundSettings: newSets });
                                                            audioCache.current[action] = new Audio(url);
                                                        };
                                                        reader.readAsDataURL(file);
                                                    }
                                                }}
                                                className="hidden"
                                                id={`upload-${action}`}
                                            />
                                            <label 
                                                htmlFor={`upload-${action}`}
                                                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white border-2 border-dashed border-slate-200 rounded-xl text-[9px] font-black uppercase text-slate-400 hover:border-blue-300 hover:text-blue-500 cursor-pointer transition-all"
                                            >
                                                <Upload size={12} /> Upload Audio
                                            </label>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <FeatureCard title="30 SEC WARNING" desc="พื้นหลังเปลี่ยนเป็นสีเหลืองเพื่อเตือน 30 วินาทีสุดท้าย" icon={TimerIcon} />
          <FeatureCard title="10 SEC PREP" desc="ช่วงนับถอยหลังก่อนเริ่มชุดพื้นหลังสีแดงเข้ม" icon={Bell} />
          <FeatureCard title="RESETS & SETS" desc="ระบบนับชุดและจัดการเวลาที่เป็นระบบตาม WA Rules" icon={SkipForward} />
      </div>
    </div>
  );
}

function FeatureCard({ title, desc, icon: Icon }: any) {
    return (
        <div className="bento-card p-6 flex gap-4 items-start">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><Icon size={20} /></div>
            <div>
                <h4 className="kanit font-black text-xs uppercase tracking-wider mb-1">{title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
            </div>
        </div>
    )
}

function TimerPreset({ label, sub, active, onClick }: { label: string, sub: string, active: boolean, onClick: () => void }) {
    return (
        <button 
            onClick={onClick}
            className={cn(
                "p-6 rounded-[2rem] border-2 transition-all text-left flex flex-col justify-center",
                active ? "bg-slate-900 border-slate-900 text-white shadow-2xl shadow-slate-200 scale-[1.02]" : "bg-white border-slate-100 text-slate-500 hover:border-slate-300"
            )}
        >
            <div className="font-black kanit text-sm uppercase tracking-wider">{label}</div>
            <div className={cn("text-[9px] font-black uppercase tracking-[0.2em] mt-1", active ? "text-blue-400" : "text-slate-400")}>{sub}</div>
        </button>
    );
}
