import { useState, useEffect } from "react";
import { User } from "./types";
import Auth from "./components/Auth";
import ScoreRecord from "./components/ScoreRecord";
import PracticeSchedule from "./components/PracticeSchedule";
import Dashboard from "./components/Dashboard";
import History from "./components/History";
import Timer from "./components/Timer";
import Profile from "./components/Profile";
import Admin from "./components/Admin";
import { LogOut, User as UserIcon, Settings, LayoutDashboard, Target, History as HistoryIcon, Timer as TimerIcon, ChevronUp, Calendar } from "lucide-react";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activePage, setActivePage] = useState<string>("dashboard");
  const [historyUserId, setHistoryUserId] = useState<string>("all");
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("archeryUser");
    if (saved) {
      try {
        setCurrentUser(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse user", e);
      }
    }
    setIsAuthReady(true);
  }, []);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem("archeryUser", JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("archeryUser");
    setShowLogoutConfirm(false);
  };

  if (!isAuthReady) return null;

  if (!currentUser) {
    return <Auth onLoginSuccess={handleLoginSuccess} />;
  }

  const renderPage = () => {
    switch (activePage) {
      case "record": return <ScoreRecord user={currentUser} />;
      case "schedule": return <PracticeSchedule user={currentUser} />;
      case "dashboard": return <Dashboard user={currentUser} />;
      case "history": return <History user={currentUser} initialFilterUser={historyUserId} />;
      case "timer": return <Timer />;
      case "profile": return <Profile user={currentUser} onUpdate={(u) => setCurrentUser(u)} />;
      case "admin": return <Admin user={currentUser} onViewHistory={(uid) => { setHistoryUserId(uid); setActivePage('history'); }} />;
      default: return <ScoreRecord user={currentUser} />;
    }
  };

  const navItems = [
    { id: "dashboard", label: "แดชบอร์ด", icon: LayoutDashboard },
    { id: "schedule", label: "ตารางการฝึกซ้อมส่วนกลาง", icon: Calendar },
    { id: "record", label: "บันทึกคะแนน", icon: Target },
    { id: "history", label: "ประวัติ", icon: HistoryIcon },
    { id: "timer", label: "จับเวลา", icon: TimerIcon },
    { id: "profile", label: "โปรไฟล์", icon: UserIcon },
  ];

  if (currentUser.role === "admin" || currentUser.role === "coach") {
    navItems.push({ id: "admin", label: "จัดการระบบ", icon: Settings });
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-5 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-700 rounded-2xl shadow-lg shadow-blue-200 flex items-center justify-center text-white font-black text-2xl transform -rotate-3 group hover:rotate-0 transition-transform">
              T
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-slate-800 uppercase leading-none mb-1">
                TNSU Chonburi
              </h1>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Archery Management System</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button 
              onClick={() => setActivePage("profile")}
              className="flex items-center gap-3 bg-slate-50 border border-slate-200 pl-4 pr-1.5 py-1.5 rounded-2xl hover:bg-white hover:border-blue-200 transition-all active:scale-95 text-left"
            >
              <div className="text-right">
                <p className="text-sm font-black text-slate-800 leading-none">{currentUser.firstName} {currentUser.lastName}</p>
                <p className="text-[10px] text-blue-600 font-bold uppercase tracking-wider mt-0.5">{currentUser.role}</p>
              </div>
              <div className="w-10 h-10 rounded-full border-2 border-blue-100 p-0.5 shadow-sm overflow-hidden">
                <img 
                  src={currentUser.profileImageURL || `https://ui-avatars.com/api/?background=E2E8F0&color=475569&name=${currentUser.firstName}&size=80`} 
                  alt="Avatar" 
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
              </div>
            </button>
            <button 
              onClick={() => setShowLogoutConfirm(true)}
              className="p-3 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all active:scale-90 group relative"
              title="ออกจากระบบ"
            >
              <LogOut size={22} />
              <span className="absolute -bottom-8 right-0 bg-slate-800 text-white text-[10px] font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                ออกจากระบบ
              </span>
            </button>
          </div>
        </div>
      </header>

      <nav className="bg-white/80 backdrop-blur-md border-b border-slate-100 px-4 py-1 sticky top-[93px] sm:top-[88px] z-40">
        <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto no-scrollbar scroll-smooth">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActivePage(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={cn(
                "flex items-center gap-2 px-4 py-3 md:px-5 md:py-4 text-[10px] md:text-xs font-black uppercase tracking-[0.1em] md:tracking-[0.15em] transition-all relative group whitespace-nowrap",
                activePage === item.id 
                  ? "text-blue-700" 
                  : "text-slate-400 hover:text-slate-800"
              )}
            >
              <item.icon size={14} className={cn("md:w-4 md:h-4 transition-transform group-hover:-translate-y-0.5", activePage === item.id && "-translate-y-0.5")} />
              {item.label}
              {activePage === item.id && (
                <div className="absolute bottom-0 left-4 right-4 h-1 bg-blue-600 rounded-t-full shadow-[0_-2px_10px_rgba(37,99,235,0.4)]" />
              )}
            </button>
          ))}
        </div>
      </nav>

      <main className="flex-grow max-w-7xl mx-auto w-full p-6 md:p-10">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          {renderPage()}
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-10">
        <div className="max-w-7xl mx-auto px-10 flex flex-col items-center gap-6">
          <div className="text-[10px] items-center gap-2 flex text-slate-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
            SYSTEM ONLINE & ENCRYPTED
          </div>
          <div className="text-center">
            <p className="text-[11px] font-medium text-slate-400 kanit">
               บันทึกผลคะแนนสำหรับนักกีฬายิงธนู โดย อ.จิรายุทธ ลีลาน้อย
            </p>
            <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-300 mt-2">
              © 2025 TNSU Chonburi Archery Club
            </p>
          </div>
        </div>
      </footer>

      {showScrollTop && (
        <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-8 right-8 z-[100] bg-slate-900 text-white p-4 rounded-2xl shadow-2xl transition-all animate-in fade-in slide-in-from-bottom-5 hover:scale-110 active:scale-95"
        >
            <ChevronUp size={24} />
        </button>
      )}

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2rem] shadow-2xl max-w-sm w-full p-10 text-center animate-in zoom-in-95 duration-200">
            <div className="w-20 h-20 bg-red-100 rounded-[2rem] flex items-center justify-center text-red-600 mx-auto mb-6">
              <LogOut size={32} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 kanit mb-2">ออกจากระบบ?</h3>
            <p className="text-slate-500 font-medium mb-8">คุณแน่ใจหรือไม่ว่าต้องการออกจากระบบบัญชีของคุณในขณะนี้?</p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={handleLogout}
                className="w-full bg-red-600 text-white font-black uppercase tracking-[0.2em] py-5 rounded-2xl shadow-xl shadow-red-100 transition-all hover:bg-red-700 active:scale-95"
              >
                ยืนยันการออก
              </button>
              <button 
                onClick={() => setShowLogoutConfirm(false)}
                className="w-full bg-slate-100 text-slate-600 font-black uppercase tracking-[0.2em] py-5 rounded-2xl transition-all hover:bg-slate-200 active:scale-95"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(" ");
}
